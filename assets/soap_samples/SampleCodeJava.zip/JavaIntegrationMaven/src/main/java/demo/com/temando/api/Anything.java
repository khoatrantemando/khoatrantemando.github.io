
package demo.com.temando.api;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for Anything complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="Anything">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;all>
 *         &lt;element name="class" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}Class" minOccurs="0"/>
 *         &lt;element name="subclass" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}Subclass" minOccurs="0"/>
 *         &lt;element name="mode" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}Mode" minOccurs="0"/>
 *         &lt;element name="tlSubclass" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}TlSubclass" minOccurs="0"/>
 *         &lt;element name="packaging" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}Packaging" minOccurs="0"/>
 *         &lt;element name="packagingOptimisation" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}YesNoOption" minOccurs="0"/>
 *         &lt;element name="palletType" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}PalletType" minOccurs="0"/>
 *         &lt;element name="palletNature" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}PalletNature" minOccurs="0"/>
 *         &lt;element name="containerDimensions" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}ContainerDimensions" minOccurs="0"/>
 *         &lt;element name="containerNature" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}ContainerNature" minOccurs="0"/>
 *         &lt;element name="containerRegistered" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}YesNoOption" minOccurs="0"/>
 *         &lt;element name="qualifierFreightGeneralDangerousGoods" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}YesNoOption" minOccurs="0"/>
 *         &lt;element name="qualifierFreightGeneralFragile" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}YesNoOption" minOccurs="0"/>
 *         &lt;element name="qualifierFreightGeneralRefrigerated" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}YesNoOption" minOccurs="0"/>
 *         &lt;element name="qualifierFreightGeneralFood" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}YesNoOption" minOccurs="0"/>
 *         &lt;element name="qualifierVehicleMake" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}VehicleMake" minOccurs="0"/>
 *         &lt;element name="qualifierVehicleModel" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}VehicleModel" minOccurs="0"/>
 *         &lt;element name="qualifierVehicleDescription" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}VehicleDescription" minOccurs="0"/>
 *         &lt;element name="qualifierVehicleRunning" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}YesNoOption" minOccurs="0"/>
 *         &lt;element name="qualifierVehicleRegistered" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}YesNoOption" minOccurs="0"/>
 *         &lt;element name="qualifierVehicleYear" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}VehicleYear" minOccurs="0"/>
 *         &lt;element name="qualifierVehicleRegistration" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}VehicleRegistration" minOccurs="0"/>
 *         &lt;element name="qualifierBoatMake" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}BoatMake" minOccurs="0"/>
 *         &lt;element name="qualifierBoatModel" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}BoatModel" minOccurs="0"/>
 *         &lt;element name="qualifierBoatSeaworthy" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}YesNoOption" minOccurs="0"/>
 *         &lt;element name="qualifierBoatTrailer" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}YesNoOption" minOccurs="0"/>
 *         &lt;element name="qualifierBoatHullType" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}BoatHullType" minOccurs="0"/>
 *         &lt;element name="qualifierLivestockType" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}LivestockType" minOccurs="0"/>
 *         &lt;element name="qualifierAnimalVaccinated" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}YesNoOption" minOccurs="0"/>
 *         &lt;element name="qualifierAnimalRegistered" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}YesNoOption" minOccurs="0"/>
 *         &lt;element name="qualifierAnimalType" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}AnimalType" minOccurs="0"/>
 *         &lt;element name="qualifierAnimalBreed" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}AnimalBreed" minOccurs="0"/>
 *         &lt;element name="qualifierAnimalSex" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}Sex" minOccurs="0"/>
 *         &lt;element name="qualifierAnimalAge" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}AnimalAge" minOccurs="0"/>
 *         &lt;element name="qualifierAnimalCrate" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}AnimalCrate" minOccurs="0"/>
 *         &lt;element name="distanceMeasurementType" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}DistanceMeasurementType" minOccurs="0"/>
 *         &lt;element name="weightMeasurementType" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}WeightMeasurementType" minOccurs="0"/>
 *         &lt;element name="length" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}Length" minOccurs="0"/>
 *         &lt;element name="width" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}Width" minOccurs="0"/>
 *         &lt;element name="height" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}Height" minOccurs="0"/>
 *         &lt;element name="weight" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}Weight" minOccurs="0"/>
 *         &lt;element name="quantity" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}Quantity"/>
 *         &lt;element name="description" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}ItemDescription" minOccurs="0"/>
 *         &lt;element name="packagingDescription" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}PackagingDescription" minOccurs="0"/>
 *         &lt;element name="item" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}Item" minOccurs="0"/>
 *         &lt;element name="dangerousGoodsPackagingGroup" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}DangerousGoodsPackagingGroup" minOccurs="0"/>
 *         &lt;element name="dangerousGoodsClass" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}DangerousGoodsClass" minOccurs="0"/>
 *         &lt;element name="unNumbers" minOccurs="0">
 *           &lt;complexType>
 *             &lt;complexContent>
 *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                 &lt;sequence>
 *                   &lt;element name="unNumber" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}UnNumber" maxOccurs="unbounded" minOccurs="0"/>
 *                 &lt;/sequence>
 *               &lt;/restriction>
 *             &lt;/complexContent>
 *           &lt;/complexType>
 *         &lt;/element>
 *         &lt;element name="articles" minOccurs="0">
 *           &lt;complexType>
 *             &lt;complexContent>
 *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                 &lt;sequence>
 *                   &lt;element name="article" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}Article" maxOccurs="unbounded" minOccurs="0"/>
 *                 &lt;/sequence>
 *               &lt;/restriction>
 *             &lt;/complexContent>
 *           &lt;/complexType>
 *         &lt;/element>
 *       &lt;/all>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "Anything", namespace = "http://api-demo.temando.com/schema/2009_06/common.xsd", propOrder = {

})
public class Anything {

    @XmlElement(name = "class")
    protected Class clazz;
    protected String subclass;
    protected Mode mode;
    protected Integer tlSubclass;
    protected Packaging packaging;
    protected YesNoOption packagingOptimisation;
    protected PalletType palletType;
    protected PalletNature palletNature;
    protected String containerDimensions;
    protected ContainerNature containerNature;
    protected YesNoOption containerRegistered;
    protected YesNoOption qualifierFreightGeneralDangerousGoods;
    protected YesNoOption qualifierFreightGeneralFragile;
    protected YesNoOption qualifierFreightGeneralRefrigerated;
    protected YesNoOption qualifierFreightGeneralFood;
    protected String qualifierVehicleMake;
    protected String qualifierVehicleModel;
    protected String qualifierVehicleDescription;
    protected YesNoOption qualifierVehicleRunning;
    protected YesNoOption qualifierVehicleRegistered;
    protected Integer qualifierVehicleYear;
    protected String qualifierVehicleRegistration;
    protected String qualifierBoatMake;
    protected String qualifierBoatModel;
    protected YesNoOption qualifierBoatSeaworthy;
    protected YesNoOption qualifierBoatTrailer;
    protected String qualifierBoatHullType;
    protected LivestockType qualifierLivestockType;
    protected YesNoOption qualifierAnimalVaccinated;
    protected YesNoOption qualifierAnimalRegistered;
    protected String qualifierAnimalType;
    protected String qualifierAnimalBreed;
    protected Sex qualifierAnimalSex;
    protected Integer qualifierAnimalAge;
    protected AnimalCrate qualifierAnimalCrate;
    protected DistanceMeasurementType distanceMeasurementType;
    protected WeightMeasurementType weightMeasurementType;
    protected Integer length;
    protected Integer width;
    protected Integer height;
    protected Integer weight;
    protected int quantity;
    protected String description;
    protected String packagingDescription;
    protected Item item;
    protected String dangerousGoodsPackagingGroup;
    protected String dangerousGoodsClass;
    protected Anything.UnNumbers unNumbers;
    protected Anything.Articles articles;

    /**
     * Gets the value of the clazz property.
     * 
     * @return
     *     possible object is
     *     {@link Class }
     *     
     */
    public Class getClazz() {
        return clazz;
    }

    /**
     * Sets the value of the clazz property.
     * 
     * @param value
     *     allowed object is
     *     {@link Class }
     *     
     */
    public void setClazz(Class value) {
        this.clazz = value;
    }

    /**
     * Gets the value of the subclass property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSubclass() {
        return subclass;
    }

    /**
     * Sets the value of the subclass property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSubclass(String value) {
        this.subclass = value;
    }

    /**
     * Gets the value of the mode property.
     * 
     * @return
     *     possible object is
     *     {@link Mode }
     *     
     */
    public Mode getMode() {
        return mode;
    }

    /**
     * Sets the value of the mode property.
     * 
     * @param value
     *     allowed object is
     *     {@link Mode }
     *     
     */
    public void setMode(Mode value) {
        this.mode = value;
    }

    /**
     * Gets the value of the tlSubclass property.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getTlSubclass() {
        return tlSubclass;
    }

    /**
     * Sets the value of the tlSubclass property.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setTlSubclass(Integer value) {
        this.tlSubclass = value;
    }

    /**
     * Gets the value of the packaging property.
     * 
     * @return
     *     possible object is
     *     {@link Packaging }
     *     
     */
    public Packaging getPackaging() {
        return packaging;
    }

    /**
     * Sets the value of the packaging property.
     * 
     * @param value
     *     allowed object is
     *     {@link Packaging }
     *     
     */
    public void setPackaging(Packaging value) {
        this.packaging = value;
    }

    /**
     * Gets the value of the packagingOptimisation property.
     * 
     * @return
     *     possible object is
     *     {@link YesNoOption }
     *     
     */
    public YesNoOption getPackagingOptimisation() {
        return packagingOptimisation;
    }

    /**
     * Sets the value of the packagingOptimisation property.
     * 
     * @param value
     *     allowed object is
     *     {@link YesNoOption }
     *     
     */
    public void setPackagingOptimisation(YesNoOption value) {
        this.packagingOptimisation = value;
    }

    /**
     * Gets the value of the palletType property.
     * 
     * @return
     *     possible object is
     *     {@link PalletType }
     *     
     */
    public PalletType getPalletType() {
        return palletType;
    }

    /**
     * Sets the value of the palletType property.
     * 
     * @param value
     *     allowed object is
     *     {@link PalletType }
     *     
     */
    public void setPalletType(PalletType value) {
        this.palletType = value;
    }

    /**
     * Gets the value of the palletNature property.
     * 
     * @return
     *     possible object is
     *     {@link PalletNature }
     *     
     */
    public PalletNature getPalletNature() {
        return palletNature;
    }

    /**
     * Sets the value of the palletNature property.
     * 
     * @param value
     *     allowed object is
     *     {@link PalletNature }
     *     
     */
    public void setPalletNature(PalletNature value) {
        this.palletNature = value;
    }

    /**
     * Gets the value of the containerDimensions property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getContainerDimensions() {
        return containerDimensions;
    }

    /**
     * Sets the value of the containerDimensions property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setContainerDimensions(String value) {
        this.containerDimensions = value;
    }

    /**
     * Gets the value of the containerNature property.
     * 
     * @return
     *     possible object is
     *     {@link ContainerNature }
     *     
     */
    public ContainerNature getContainerNature() {
        return containerNature;
    }

    /**
     * Sets the value of the containerNature property.
     * 
     * @param value
     *     allowed object is
     *     {@link ContainerNature }
     *     
     */
    public void setContainerNature(ContainerNature value) {
        this.containerNature = value;
    }

    /**
     * Gets the value of the containerRegistered property.
     * 
     * @return
     *     possible object is
     *     {@link YesNoOption }
     *     
     */
    public YesNoOption getContainerRegistered() {
        return containerRegistered;
    }

    /**
     * Sets the value of the containerRegistered property.
     * 
     * @param value
     *     allowed object is
     *     {@link YesNoOption }
     *     
     */
    public void setContainerRegistered(YesNoOption value) {
        this.containerRegistered = value;
    }

    /**
     * Gets the value of the qualifierFreightGeneralDangerousGoods property.
     * 
     * @return
     *     possible object is
     *     {@link YesNoOption }
     *     
     */
    public YesNoOption getQualifierFreightGeneralDangerousGoods() {
        return qualifierFreightGeneralDangerousGoods;
    }

    /**
     * Sets the value of the qualifierFreightGeneralDangerousGoods property.
     * 
     * @param value
     *     allowed object is
     *     {@link YesNoOption }
     *     
     */
    public void setQualifierFreightGeneralDangerousGoods(YesNoOption value) {
        this.qualifierFreightGeneralDangerousGoods = value;
    }

    /**
     * Gets the value of the qualifierFreightGeneralFragile property.
     * 
     * @return
     *     possible object is
     *     {@link YesNoOption }
     *     
     */
    public YesNoOption getQualifierFreightGeneralFragile() {
        return qualifierFreightGeneralFragile;
    }

    /**
     * Sets the value of the qualifierFreightGeneralFragile property.
     * 
     * @param value
     *     allowed object is
     *     {@link YesNoOption }
     *     
     */
    public void setQualifierFreightGeneralFragile(YesNoOption value) {
        this.qualifierFreightGeneralFragile = value;
    }

    /**
     * Gets the value of the qualifierFreightGeneralRefrigerated property.
     * 
     * @return
     *     possible object is
     *     {@link YesNoOption }
     *     
     */
    public YesNoOption getQualifierFreightGeneralRefrigerated() {
        return qualifierFreightGeneralRefrigerated;
    }

    /**
     * Sets the value of the qualifierFreightGeneralRefrigerated property.
     * 
     * @param value
     *     allowed object is
     *     {@link YesNoOption }
     *     
     */
    public void setQualifierFreightGeneralRefrigerated(YesNoOption value) {
        this.qualifierFreightGeneralRefrigerated = value;
    }

    /**
     * Gets the value of the qualifierFreightGeneralFood property.
     * 
     * @return
     *     possible object is
     *     {@link YesNoOption }
     *     
     */
    public YesNoOption getQualifierFreightGeneralFood() {
        return qualifierFreightGeneralFood;
    }

    /**
     * Sets the value of the qualifierFreightGeneralFood property.
     * 
     * @param value
     *     allowed object is
     *     {@link YesNoOption }
     *     
     */
    public void setQualifierFreightGeneralFood(YesNoOption value) {
        this.qualifierFreightGeneralFood = value;
    }

    /**
     * Gets the value of the qualifierVehicleMake property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getQualifierVehicleMake() {
        return qualifierVehicleMake;
    }

    /**
     * Sets the value of the qualifierVehicleMake property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setQualifierVehicleMake(String value) {
        this.qualifierVehicleMake = value;
    }

    /**
     * Gets the value of the qualifierVehicleModel property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getQualifierVehicleModel() {
        return qualifierVehicleModel;
    }

    /**
     * Sets the value of the qualifierVehicleModel property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setQualifierVehicleModel(String value) {
        this.qualifierVehicleModel = value;
    }

    /**
     * Gets the value of the qualifierVehicleDescription property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getQualifierVehicleDescription() {
        return qualifierVehicleDescription;
    }

    /**
     * Sets the value of the qualifierVehicleDescription property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setQualifierVehicleDescription(String value) {
        this.qualifierVehicleDescription = value;
    }

    /**
     * Gets the value of the qualifierVehicleRunning property.
     * 
     * @return
     *     possible object is
     *     {@link YesNoOption }
     *     
     */
    public YesNoOption getQualifierVehicleRunning() {
        return qualifierVehicleRunning;
    }

    /**
     * Sets the value of the qualifierVehicleRunning property.
     * 
     * @param value
     *     allowed object is
     *     {@link YesNoOption }
     *     
     */
    public void setQualifierVehicleRunning(YesNoOption value) {
        this.qualifierVehicleRunning = value;
    }

    /**
     * Gets the value of the qualifierVehicleRegistered property.
     * 
     * @return
     *     possible object is
     *     {@link YesNoOption }
     *     
     */
    public YesNoOption getQualifierVehicleRegistered() {
        return qualifierVehicleRegistered;
    }

    /**
     * Sets the value of the qualifierVehicleRegistered property.
     * 
     * @param value
     *     allowed object is
     *     {@link YesNoOption }
     *     
     */
    public void setQualifierVehicleRegistered(YesNoOption value) {
        this.qualifierVehicleRegistered = value;
    }

    /**
     * Gets the value of the qualifierVehicleYear property.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getQualifierVehicleYear() {
        return qualifierVehicleYear;
    }

    /**
     * Sets the value of the qualifierVehicleYear property.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setQualifierVehicleYear(Integer value) {
        this.qualifierVehicleYear = value;
    }

    /**
     * Gets the value of the qualifierVehicleRegistration property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getQualifierVehicleRegistration() {
        return qualifierVehicleRegistration;
    }

    /**
     * Sets the value of the qualifierVehicleRegistration property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setQualifierVehicleRegistration(String value) {
        this.qualifierVehicleRegistration = value;
    }

    /**
     * Gets the value of the qualifierBoatMake property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getQualifierBoatMake() {
        return qualifierBoatMake;
    }

    /**
     * Sets the value of the qualifierBoatMake property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setQualifierBoatMake(String value) {
        this.qualifierBoatMake = value;
    }

    /**
     * Gets the value of the qualifierBoatModel property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getQualifierBoatModel() {
        return qualifierBoatModel;
    }

    /**
     * Sets the value of the qualifierBoatModel property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setQualifierBoatModel(String value) {
        this.qualifierBoatModel = value;
    }

    /**
     * Gets the value of the qualifierBoatSeaworthy property.
     * 
     * @return
     *     possible object is
     *     {@link YesNoOption }
     *     
     */
    public YesNoOption getQualifierBoatSeaworthy() {
        return qualifierBoatSeaworthy;
    }

    /**
     * Sets the value of the qualifierBoatSeaworthy property.
     * 
     * @param value
     *     allowed object is
     *     {@link YesNoOption }
     *     
     */
    public void setQualifierBoatSeaworthy(YesNoOption value) {
        this.qualifierBoatSeaworthy = value;
    }

    /**
     * Gets the value of the qualifierBoatTrailer property.
     * 
     * @return
     *     possible object is
     *     {@link YesNoOption }
     *     
     */
    public YesNoOption getQualifierBoatTrailer() {
        return qualifierBoatTrailer;
    }

    /**
     * Sets the value of the qualifierBoatTrailer property.
     * 
     * @param value
     *     allowed object is
     *     {@link YesNoOption }
     *     
     */
    public void setQualifierBoatTrailer(YesNoOption value) {
        this.qualifierBoatTrailer = value;
    }

    /**
     * Gets the value of the qualifierBoatHullType property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getQualifierBoatHullType() {
        return qualifierBoatHullType;
    }

    /**
     * Sets the value of the qualifierBoatHullType property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setQualifierBoatHullType(String value) {
        this.qualifierBoatHullType = value;
    }

    /**
     * Gets the value of the qualifierLivestockType property.
     * 
     * @return
     *     possible object is
     *     {@link LivestockType }
     *     
     */
    public LivestockType getQualifierLivestockType() {
        return qualifierLivestockType;
    }

    /**
     * Sets the value of the qualifierLivestockType property.
     * 
     * @param value
     *     allowed object is
     *     {@link LivestockType }
     *     
     */
    public void setQualifierLivestockType(LivestockType value) {
        this.qualifierLivestockType = value;
    }

    /**
     * Gets the value of the qualifierAnimalVaccinated property.
     * 
     * @return
     *     possible object is
     *     {@link YesNoOption }
     *     
     */
    public YesNoOption getQualifierAnimalVaccinated() {
        return qualifierAnimalVaccinated;
    }

    /**
     * Sets the value of the qualifierAnimalVaccinated property.
     * 
     * @param value
     *     allowed object is
     *     {@link YesNoOption }
     *     
     */
    public void setQualifierAnimalVaccinated(YesNoOption value) {
        this.qualifierAnimalVaccinated = value;
    }

    /**
     * Gets the value of the qualifierAnimalRegistered property.
     * 
     * @return
     *     possible object is
     *     {@link YesNoOption }
     *     
     */
    public YesNoOption getQualifierAnimalRegistered() {
        return qualifierAnimalRegistered;
    }

    /**
     * Sets the value of the qualifierAnimalRegistered property.
     * 
     * @param value
     *     allowed object is
     *     {@link YesNoOption }
     *     
     */
    public void setQualifierAnimalRegistered(YesNoOption value) {
        this.qualifierAnimalRegistered = value;
    }

    /**
     * Gets the value of the qualifierAnimalType property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getQualifierAnimalType() {
        return qualifierAnimalType;
    }

    /**
     * Sets the value of the qualifierAnimalType property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setQualifierAnimalType(String value) {
        this.qualifierAnimalType = value;
    }

    /**
     * Gets the value of the qualifierAnimalBreed property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getQualifierAnimalBreed() {
        return qualifierAnimalBreed;
    }

    /**
     * Sets the value of the qualifierAnimalBreed property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setQualifierAnimalBreed(String value) {
        this.qualifierAnimalBreed = value;
    }

    /**
     * Gets the value of the qualifierAnimalSex property.
     * 
     * @return
     *     possible object is
     *     {@link Sex }
     *     
     */
    public Sex getQualifierAnimalSex() {
        return qualifierAnimalSex;
    }

    /**
     * Sets the value of the qualifierAnimalSex property.
     * 
     * @param value
     *     allowed object is
     *     {@link Sex }
     *     
     */
    public void setQualifierAnimalSex(Sex value) {
        this.qualifierAnimalSex = value;
    }

    /**
     * Gets the value of the qualifierAnimalAge property.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getQualifierAnimalAge() {
        return qualifierAnimalAge;
    }

    /**
     * Sets the value of the qualifierAnimalAge property.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setQualifierAnimalAge(Integer value) {
        this.qualifierAnimalAge = value;
    }

    /**
     * Gets the value of the qualifierAnimalCrate property.
     * 
     * @return
     *     possible object is
     *     {@link AnimalCrate }
     *     
     */
    public AnimalCrate getQualifierAnimalCrate() {
        return qualifierAnimalCrate;
    }

    /**
     * Sets the value of the qualifierAnimalCrate property.
     * 
     * @param value
     *     allowed object is
     *     {@link AnimalCrate }
     *     
     */
    public void setQualifierAnimalCrate(AnimalCrate value) {
        this.qualifierAnimalCrate = value;
    }

    /**
     * Gets the value of the distanceMeasurementType property.
     * 
     * @return
     *     possible object is
     *     {@link DistanceMeasurementType }
     *     
     */
    public DistanceMeasurementType getDistanceMeasurementType() {
        return distanceMeasurementType;
    }

    /**
     * Sets the value of the distanceMeasurementType property.
     * 
     * @param value
     *     allowed object is
     *     {@link DistanceMeasurementType }
     *     
     */
    public void setDistanceMeasurementType(DistanceMeasurementType value) {
        this.distanceMeasurementType = value;
    }

    /**
     * Gets the value of the weightMeasurementType property.
     * 
     * @return
     *     possible object is
     *     {@link WeightMeasurementType }
     *     
     */
    public WeightMeasurementType getWeightMeasurementType() {
        return weightMeasurementType;
    }

    /**
     * Sets the value of the weightMeasurementType property.
     * 
     * @param value
     *     allowed object is
     *     {@link WeightMeasurementType }
     *     
     */
    public void setWeightMeasurementType(WeightMeasurementType value) {
        this.weightMeasurementType = value;
    }

    /**
     * Gets the value of the length property.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getLength() {
        return length;
    }

    /**
     * Sets the value of the length property.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setLength(Integer value) {
        this.length = value;
    }

    /**
     * Gets the value of the width property.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getWidth() {
        return width;
    }

    /**
     * Sets the value of the width property.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setWidth(Integer value) {
        this.width = value;
    }

    /**
     * Gets the value of the height property.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getHeight() {
        return height;
    }

    /**
     * Sets the value of the height property.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setHeight(Integer value) {
        this.height = value;
    }

    /**
     * Gets the value of the weight property.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getWeight() {
        return weight;
    }

    /**
     * Sets the value of the weight property.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setWeight(Integer value) {
        this.weight = value;
    }

    /**
     * Gets the value of the quantity property.
     * 
     */
    public int getQuantity() {
        return quantity;
    }

    /**
     * Sets the value of the quantity property.
     * 
     */
    public void setQuantity(int value) {
        this.quantity = value;
    }

    /**
     * Gets the value of the description property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDescription() {
        return description;
    }

    /**
     * Sets the value of the description property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDescription(String value) {
        this.description = value;
    }

    /**
     * Gets the value of the packagingDescription property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPackagingDescription() {
        return packagingDescription;
    }

    /**
     * Sets the value of the packagingDescription property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPackagingDescription(String value) {
        this.packagingDescription = value;
    }

    /**
     * Gets the value of the item property.
     * 
     * @return
     *     possible object is
     *     {@link Item }
     *     
     */
    public Item getItem() {
        return item;
    }

    /**
     * Sets the value of the item property.
     * 
     * @param value
     *     allowed object is
     *     {@link Item }
     *     
     */
    public void setItem(Item value) {
        this.item = value;
    }

    /**
     * Gets the value of the dangerousGoodsPackagingGroup property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDangerousGoodsPackagingGroup() {
        return dangerousGoodsPackagingGroup;
    }

    /**
     * Sets the value of the dangerousGoodsPackagingGroup property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDangerousGoodsPackagingGroup(String value) {
        this.dangerousGoodsPackagingGroup = value;
    }

    /**
     * Gets the value of the dangerousGoodsClass property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDangerousGoodsClass() {
        return dangerousGoodsClass;
    }

    /**
     * Sets the value of the dangerousGoodsClass property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDangerousGoodsClass(String value) {
        this.dangerousGoodsClass = value;
    }

    /**
     * Gets the value of the unNumbers property.
     * 
     * @return
     *     possible object is
     *     {@link Anything.UnNumbers }
     *     
     */
    public Anything.UnNumbers getUnNumbers() {
        return unNumbers;
    }

    /**
     * Sets the value of the unNumbers property.
     * 
     * @param value
     *     allowed object is
     *     {@link Anything.UnNumbers }
     *     
     */
    public void setUnNumbers(Anything.UnNumbers value) {
        this.unNumbers = value;
    }

    /**
     * Gets the value of the articles property.
     * 
     * @return
     *     possible object is
     *     {@link Anything.Articles }
     *     
     */
    public Anything.Articles getArticles() {
        return articles;
    }

    /**
     * Sets the value of the articles property.
     * 
     * @param value
     *     allowed object is
     *     {@link Anything.Articles }
     *     
     */
    public void setArticles(Anything.Articles value) {
        this.articles = value;
    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType>
     *   &lt;complexContent>
     *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
     *       &lt;sequence>
     *         &lt;element name="article" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}Article" maxOccurs="unbounded" minOccurs="0"/>
     *       &lt;/sequence>
     *     &lt;/restriction>
     *   &lt;/complexContent>
     * &lt;/complexType>
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "article"
    })
    public static class Articles {

        protected List<Article> article;

        /**
         * Gets the value of the article property.
         * 
         * <p>
         * This accessor method returns a reference to the live list,
         * not a snapshot. Therefore any modification you make to the
         * returned list will be present inside the JAXB object.
         * This is why there is not a <CODE>set</CODE> method for the article property.
         * 
         * <p>
         * For example, to add a new item, do as follows:
         * <pre>
         *    getArticle().add(newItem);
         * </pre>
         * 
         * 
         * <p>
         * Objects of the following type(s) are allowed in the list
         * {@link Article }
         * 
         * 
         */
        public List<Article> getArticle() {
            if (article == null) {
                article = new ArrayList<Article>();
            }
            return this.article;
        }

    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType>
     *   &lt;complexContent>
     *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
     *       &lt;sequence>
     *         &lt;element name="unNumber" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}UnNumber" maxOccurs="unbounded" minOccurs="0"/>
     *       &lt;/sequence>
     *     &lt;/restriction>
     *   &lt;/complexContent>
     * &lt;/complexType>
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "unNumber"
    })
    public static class UnNumbers {

        protected List<String> unNumber;

        /**
         * Gets the value of the unNumber property.
         * 
         * <p>
         * This accessor method returns a reference to the live list,
         * not a snapshot. Therefore any modification you make to the
         * returned list will be present inside the JAXB object.
         * This is why there is not a <CODE>set</CODE> method for the unNumber property.
         * 
         * <p>
         * For example, to add a new item, do as follows:
         * <pre>
         *    getUnNumber().add(newItem);
         * </pre>
         * 
         * 
         * <p>
         * Objects of the following type(s) are allowed in the list
         * {@link String }
         * 
         * 
         */
        public List<String> getUnNumber() {
            if (unNumber == null) {
                unNumber = new ArrayList<String>();
            }
            return this.unNumber;
        }

    }

}
