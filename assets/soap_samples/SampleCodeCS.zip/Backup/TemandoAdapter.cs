﻿using System;

namespace TemandoSample
{
    public abstract class TemandoAdapter {
        protected readonly string _endpointAddress;
        protected readonly string _password;
        protected readonly string _userName;

        protected TemandoAdapter(string endpointAddress, string userName, string password) {
            _endpointAddress = endpointAddress;
            _userName = userName;
            _password = password;

            if (string.IsNullOrEmpty(_endpointAddress))
                throw new Exception("EndpointAddress is missing!");
            if (string.IsNullOrEmpty(_userName))
                throw new Exception("UserName is missing!");
            if (_password == null)
                _password = string.Empty;
        }
    }
}