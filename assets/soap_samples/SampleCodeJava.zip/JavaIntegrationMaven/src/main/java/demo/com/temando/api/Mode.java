
package demo.com.temando.api;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for Mode.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * <p>
 * <pre>
 * &lt;simpleType name="Mode">
 *   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *     &lt;enumeration value="Truckload"/>
 *     &lt;enumeration value="Less than load"/>
 *     &lt;enumeration value="Container"/>
 *   &lt;/restriction>
 * &lt;/simpleType>
 * </pre>
 * 
 */
@XmlType(name = "Mode", namespace = "http://api-demo.temando.com/schema/2009_06/common.xsd")
@XmlEnum
public enum Mode {

    @XmlEnumValue("Truckload")
    TRUCKLOAD("Truckload"),
    @XmlEnumValue("Less than load")
    LESS_THAN_LOAD("Less than load"),
    @XmlEnumValue("Container")
    CONTAINER("Container");
    private final String value;

    Mode(String v) {
        value = v;
    }

    public String value() {
        return value;
    }

    public static Mode fromValue(String v) {
        for (Mode c: Mode.values()) {
            if (c.value.equals(v)) {
                return c;
            }
        }
        throw new IllegalArgumentException(v);
    }

}
