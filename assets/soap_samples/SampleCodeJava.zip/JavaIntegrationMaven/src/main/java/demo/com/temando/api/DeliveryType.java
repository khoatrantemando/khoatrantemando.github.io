
package demo.com.temando.api;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for DeliveryType.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * <p>
 * <pre>
 * &lt;simpleType name="DeliveryType">
 *   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *     &lt;enumeration value="Door to Door"/>
 *     &lt;enumeration value="Depot to Depot"/>
 *     &lt;enumeration value="Port to Port"/>
 *   &lt;/restriction>
 * &lt;/simpleType>
 * </pre>
 * 
 */
@XmlType(name = "DeliveryType", namespace = "http://api-demo.temando.com/schema/2009_06/common.xsd")
@XmlEnum
public enum DeliveryType {

    @XmlEnumValue("Door to Door")
    DOOR_TO_DOOR("Door to Door"),
    @XmlEnumValue("Depot to Depot")
    DEPOT_TO_DEPOT("Depot to Depot"),
    @XmlEnumValue("Port to Port")
    PORT_TO_PORT("Port to Port");
    private final String value;

    DeliveryType(String v) {
        value = v;
    }

    public String value() {
        return value;
    }

    public static DeliveryType fromValue(String v) {
        for (DeliveryType c: DeliveryType.values()) {
            if (c.value.equals(v)) {
                return c;
            }
        }
        throw new IllegalArgumentException(v);
    }

}
