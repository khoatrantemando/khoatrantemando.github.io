
package demo.com.temando.api;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for BookingQuote complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="BookingQuote">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;all>
 *         &lt;element name="totalPrice" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}CurrencyAmount"/>
 *         &lt;element name="basePrice" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}CurrencyAmount"/>
 *         &lt;element name="tax" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}CurrencyAmount"/>
 *         &lt;element name="currency" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}CurrencyType"/>
 *         &lt;element name="deliveryMethod" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}DeliveryMethod"/>
 *         &lt;element name="etaFrom" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}Eta"/>
 *         &lt;element name="etaTo" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}Eta"/>
 *         &lt;element name="guaranteedEta" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}YesNoOption"/>
 *         &lt;element name="carrierId" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}CarrierId"/>
 *         &lt;element name="extras" minOccurs="0">
 *           &lt;complexType>
 *             &lt;complexContent>
 *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                 &lt;sequence>
 *                   &lt;element name="extra" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}Extra" maxOccurs="unbounded" minOccurs="0"/>
 *                 &lt;/sequence>
 *               &lt;/restriction>
 *             &lt;/complexContent>
 *           &lt;/complexType>
 *         &lt;/element>
 *       &lt;/all>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "BookingQuote", namespace = "http://api-demo.temando.com/schema/2009_06/common.xsd", propOrder = {

})
public class BookingQuote {

    @XmlElement(required = true)
    protected BigDecimal totalPrice;
    @XmlElement(required = true)
    protected BigDecimal basePrice;
    @XmlElement(required = true)
    protected BigDecimal tax;
    @XmlElement(required = true)
    protected CurrencyType currency;
    @XmlElement(required = true)
    protected String deliveryMethod;
    protected int etaFrom;
    protected int etaTo;
    @XmlElement(required = true)
    protected YesNoOption guaranteedEta;
    protected int carrierId;
    protected BookingQuote.Extras extras;

    /**
     * Gets the value of the totalPrice property.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getTotalPrice() {
        return totalPrice;
    }

    /**
     * Sets the value of the totalPrice property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setTotalPrice(BigDecimal value) {
        this.totalPrice = value;
    }

    /**
     * Gets the value of the basePrice property.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getBasePrice() {
        return basePrice;
    }

    /**
     * Sets the value of the basePrice property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setBasePrice(BigDecimal value) {
        this.basePrice = value;
    }

    /**
     * Gets the value of the tax property.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getTax() {
        return tax;
    }

    /**
     * Sets the value of the tax property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setTax(BigDecimal value) {
        this.tax = value;
    }

    /**
     * Gets the value of the currency property.
     * 
     * @return
     *     possible object is
     *     {@link CurrencyType }
     *     
     */
    public CurrencyType getCurrency() {
        return currency;
    }

    /**
     * Sets the value of the currency property.
     * 
     * @param value
     *     allowed object is
     *     {@link CurrencyType }
     *     
     */
    public void setCurrency(CurrencyType value) {
        this.currency = value;
    }

    /**
     * Gets the value of the deliveryMethod property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDeliveryMethod() {
        return deliveryMethod;
    }

    /**
     * Sets the value of the deliveryMethod property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDeliveryMethod(String value) {
        this.deliveryMethod = value;
    }

    /**
     * Gets the value of the etaFrom property.
     * 
     */
    public int getEtaFrom() {
        return etaFrom;
    }

    /**
     * Sets the value of the etaFrom property.
     * 
     */
    public void setEtaFrom(int value) {
        this.etaFrom = value;
    }

    /**
     * Gets the value of the etaTo property.
     * 
     */
    public int getEtaTo() {
        return etaTo;
    }

    /**
     * Sets the value of the etaTo property.
     * 
     */
    public void setEtaTo(int value) {
        this.etaTo = value;
    }

    /**
     * Gets the value of the guaranteedEta property.
     * 
     * @return
     *     possible object is
     *     {@link YesNoOption }
     *     
     */
    public YesNoOption getGuaranteedEta() {
        return guaranteedEta;
    }

    /**
     * Sets the value of the guaranteedEta property.
     * 
     * @param value
     *     allowed object is
     *     {@link YesNoOption }
     *     
     */
    public void setGuaranteedEta(YesNoOption value) {
        this.guaranteedEta = value;
    }

    /**
     * Gets the value of the carrierId property.
     * 
     */
    public int getCarrierId() {
        return carrierId;
    }

    /**
     * Sets the value of the carrierId property.
     * 
     */
    public void setCarrierId(int value) {
        this.carrierId = value;
    }

    /**
     * Gets the value of the extras property.
     * 
     * @return
     *     possible object is
     *     {@link BookingQuote.Extras }
     *     
     */
    public BookingQuote.Extras getExtras() {
        return extras;
    }

    /**
     * Sets the value of the extras property.
     * 
     * @param value
     *     allowed object is
     *     {@link BookingQuote.Extras }
     *     
     */
    public void setExtras(BookingQuote.Extras value) {
        this.extras = value;
    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType>
     *   &lt;complexContent>
     *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
     *       &lt;sequence>
     *         &lt;element name="extra" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}Extra" maxOccurs="unbounded" minOccurs="0"/>
     *       &lt;/sequence>
     *     &lt;/restriction>
     *   &lt;/complexContent>
     * &lt;/complexType>
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "extra"
    })
    public static class Extras {

        protected List<Extra> extra;

        /**
         * Gets the value of the extra property.
         * 
         * <p>
         * This accessor method returns a reference to the live list,
         * not a snapshot. Therefore any modification you make to the
         * returned list will be present inside the JAXB object.
         * This is why there is not a <CODE>set</CODE> method for the extra property.
         * 
         * <p>
         * For example, to add a new item, do as follows:
         * <pre>
         *    getExtra().add(newItem);
         * </pre>
         * 
         * 
         * <p>
         * Objects of the following type(s) are allowed in the list
         * {@link Extra }
         * 
         * 
         */
        public List<Extra> getExtra() {
            if (extra == null) {
                extra = new ArrayList<Extra>();
            }
            return this.extra;
        }

    }

}
