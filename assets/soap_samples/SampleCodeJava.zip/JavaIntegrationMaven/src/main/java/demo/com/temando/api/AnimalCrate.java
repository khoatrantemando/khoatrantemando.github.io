
package demo.com.temando.api;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for AnimalCrate.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * <p>
 * <pre>
 * &lt;simpleType name="AnimalCrate">
 *   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *     &lt;enumeration value="Hire 1"/>
 *     &lt;enumeration value="Hire 2"/>
 *     &lt;enumeration value="Buy 1"/>
 *     &lt;enumeration value="Buy 2"/>
 *     &lt;enumeration value="I have a crate"/>
 *   &lt;/restriction>
 * &lt;/simpleType>
 * </pre>
 * 
 */
@XmlType(name = "AnimalCrate", namespace = "http://api-demo.temando.com/schema/2009_06/common.xsd")
@XmlEnum
public enum AnimalCrate {

    @XmlEnumValue("Hire 1")
    HIRE_1("Hire 1"),
    @XmlEnumValue("Hire 2")
    HIRE_2("Hire 2"),
    @XmlEnumValue("Buy 1")
    BUY_1("Buy 1"),
    @XmlEnumValue("Buy 2")
    BUY_2("Buy 2"),
    @XmlEnumValue("I have a crate")
    I_HAVE_A_CRATE("I have a crate");
    private final String value;

    AnimalCrate(String v) {
        value = v;
    }

    public String value() {
        return value;
    }

    public static AnimalCrate fromValue(String v) {
        for (AnimalCrate c: AnimalCrate.values()) {
            if (c.value.equals(v)) {
                return c;
            }
        }
        throw new IllegalArgumentException(v);
    }

}
