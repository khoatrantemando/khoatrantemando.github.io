
package demo.com.temando.api;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for PortType.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * <p>
 * <pre>
 * &lt;simpleType name="PortType">
 *   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *     &lt;enumeration value="Sea"/>
 *     &lt;enumeration value="Air"/>
 *     &lt;enumeration value="Any"/>
 *   &lt;/restriction>
 * &lt;/simpleType>
 * </pre>
 * 
 */
@XmlType(name = "PortType", namespace = "http://api-demo.temando.com/schema/2009_06/common.xsd")
@XmlEnum
public enum PortType {

    @XmlEnumValue("Sea")
    SEA("Sea"),
    @XmlEnumValue("Air")
    AIR("Air"),
    @XmlEnumValue("Any")
    ANY("Any");
    private final String value;

    PortType(String v) {
        value = v;
    }

    public String value() {
        return value;
    }

    public static PortType fromValue(String v) {
        for (PortType c: PortType.values()) {
            if (c.value.equals(v)) {
                return c;
            }
        }
        throw new IllegalArgumentException(v);
    }

}
