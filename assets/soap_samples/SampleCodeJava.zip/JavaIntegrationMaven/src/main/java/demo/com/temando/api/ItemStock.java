
package demo.com.temando.api;

import java.math.BigDecimal;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for ItemStock complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="ItemStock">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;all>
 *         &lt;element name="originDescription" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}LocationName"/>
 *         &lt;element name="goodsPrice" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}CurrencyAmount" minOccurs="0"/>
 *         &lt;element name="listPrice" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}CurrencyAmount" minOccurs="0"/>
 *         &lt;element name="salePrice" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}CurrencyAmount" minOccurs="0"/>
 *         &lt;element name="stockStatus" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}StockStatus" minOccurs="0"/>
 *         &lt;element name="stockCount" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}StockCount" minOccurs="0"/>
 *         &lt;element name="priority" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}Priority" minOccurs="0"/>
 *       &lt;/all>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ItemStock", namespace = "http://api-demo.temando.com/schema/2009_06/common.xsd", propOrder = {

})
public class ItemStock {

    @XmlElement(required = true)
    protected String originDescription;
    protected BigDecimal goodsPrice;
    protected BigDecimal listPrice;
    protected BigDecimal salePrice;
    protected StockStatus stockStatus;
    protected Integer stockCount;
    protected Integer priority;

    /**
     * Gets the value of the originDescription property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getOriginDescription() {
        return originDescription;
    }

    /**
     * Sets the value of the originDescription property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setOriginDescription(String value) {
        this.originDescription = value;
    }

    /**
     * Gets the value of the goodsPrice property.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getGoodsPrice() {
        return goodsPrice;
    }

    /**
     * Sets the value of the goodsPrice property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setGoodsPrice(BigDecimal value) {
        this.goodsPrice = value;
    }

    /**
     * Gets the value of the listPrice property.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getListPrice() {
        return listPrice;
    }

    /**
     * Sets the value of the listPrice property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setListPrice(BigDecimal value) {
        this.listPrice = value;
    }

    /**
     * Gets the value of the salePrice property.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getSalePrice() {
        return salePrice;
    }

    /**
     * Sets the value of the salePrice property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setSalePrice(BigDecimal value) {
        this.salePrice = value;
    }

    /**
     * Gets the value of the stockStatus property.
     * 
     * @return
     *     possible object is
     *     {@link StockStatus }
     *     
     */
    public StockStatus getStockStatus() {
        return stockStatus;
    }

    /**
     * Sets the value of the stockStatus property.
     * 
     * @param value
     *     allowed object is
     *     {@link StockStatus }
     *     
     */
    public void setStockStatus(StockStatus value) {
        this.stockStatus = value;
    }

    /**
     * Gets the value of the stockCount property.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getStockCount() {
        return stockCount;
    }

    /**
     * Sets the value of the stockCount property.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setStockCount(Integer value) {
        this.stockCount = value;
    }

    /**
     * Gets the value of the priority property.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getPriority() {
        return priority;
    }

    /**
     * Sets the value of the priority property.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setPriority(Integer value) {
        this.priority = value;
    }

}
