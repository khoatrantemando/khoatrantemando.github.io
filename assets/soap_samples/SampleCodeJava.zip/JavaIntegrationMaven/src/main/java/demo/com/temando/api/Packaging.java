
package demo.com.temando.api;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for Packaging.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * <p>
 * <pre>
 * &lt;simpleType name="Packaging">
 *   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *     &lt;enumeration value="Backpack"/>
 *     &lt;enumeration value="Bale"/>
 *     &lt;enumeration value="Box"/>
 *     &lt;enumeration value="Bunch"/>
 *     &lt;enumeration value="Bundle"/>
 *     &lt;enumeration value="Carton"/>
 *     &lt;enumeration value="Crate"/>
 *     &lt;enumeration value="Cylinder"/>
 *     &lt;enumeration value="Document Envelope"/>
 *     &lt;enumeration value="Drum"/>
 *     &lt;enumeration value="Flat Pack"/>
 *     &lt;enumeration value="Letter"/>
 *     &lt;enumeration value="Pail"/>
 *     &lt;enumeration value="Pallet"/>
 *     &lt;enumeration value="Parcel"/>
 *     &lt;enumeration value="Pipe"/>
 *     &lt;enumeration value="Roll"/>
 *     &lt;enumeration value="Satchel/Bag"/>
 *     &lt;enumeration value="Skid"/>
 *     &lt;enumeration value="Suitcase"/>
 *     &lt;enumeration value="Tube"/>
 *     &lt;enumeration value="Unpackaged or N/A"/>
 *     &lt;enumeration value="Wheel/Tyre"/>
 *   &lt;/restriction>
 * &lt;/simpleType>
 * </pre>
 * 
 */
@XmlType(name = "Packaging", namespace = "http://api-demo.temando.com/schema/2009_06/common.xsd")
@XmlEnum
public enum Packaging {

    @XmlEnumValue("Backpack")
    BACKPACK("Backpack"),
    @XmlEnumValue("Bale")
    BALE("Bale"),
    @XmlEnumValue("Box")
    BOX("Box"),
    @XmlEnumValue("Bunch")
    BUNCH("Bunch"),
    @XmlEnumValue("Bundle")
    BUNDLE("Bundle"),
    @XmlEnumValue("Carton")
    CARTON("Carton"),
    @XmlEnumValue("Crate")
    CRATE("Crate"),
    @XmlEnumValue("Cylinder")
    CYLINDER("Cylinder"),
    @XmlEnumValue("Document Envelope")
    DOCUMENT_ENVELOPE("Document Envelope"),
    @XmlEnumValue("Drum")
    DRUM("Drum"),
    @XmlEnumValue("Flat Pack")
    FLAT_PACK("Flat Pack"),
    @XmlEnumValue("Letter")
    LETTER("Letter"),
    @XmlEnumValue("Pail")
    PAIL("Pail"),
    @XmlEnumValue("Pallet")
    PALLET("Pallet"),
    @XmlEnumValue("Parcel")
    PARCEL("Parcel"),
    @XmlEnumValue("Pipe")
    PIPE("Pipe"),
    @XmlEnumValue("Roll")
    ROLL("Roll"),
    @XmlEnumValue("Satchel/Bag")
    SATCHEL_BAG("Satchel/Bag"),
    @XmlEnumValue("Skid")
    SKID("Skid"),
    @XmlEnumValue("Suitcase")
    SUITCASE("Suitcase"),
    @XmlEnumValue("Tube")
    TUBE("Tube"),
    @XmlEnumValue("Unpackaged or N/A")
    UNPACKAGED_OR_N_A("Unpackaged or N/A"),
    @XmlEnumValue("Wheel/Tyre")
    WHEEL_TYRE("Wheel/Tyre");
    private final String value;

    Packaging(String v) {
        value = v;
    }

    public String value() {
        return value;
    }

    public static Packaging fromValue(String v) {
        for (Packaging c: Packaging.values()) {
            if (c.value.equals(v)) {
                return c;
            }
        }
        throw new IllegalArgumentException(v);
    }

}
