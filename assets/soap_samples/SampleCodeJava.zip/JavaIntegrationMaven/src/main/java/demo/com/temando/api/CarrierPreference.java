
package demo.com.temando.api;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for CarrierPreference complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="CarrierPreference">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;all>
 *         &lt;element name="carrierId" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}CarrierId"/>
 *         &lt;element name="deliveryMethods" minOccurs="0">
 *           &lt;complexType>
 *             &lt;complexContent>
 *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                 &lt;sequence>
 *                   &lt;element name="deliveryMethod" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}DeliveryMethod" maxOccurs="unbounded" minOccurs="0"/>
 *                 &lt;/sequence>
 *               &lt;/restriction>
 *             &lt;/complexContent>
 *           &lt;/complexType>
 *         &lt;/element>
 *       &lt;/all>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "CarrierPreference", namespace = "http://api-demo.temando.com/schema/2009_06/common.xsd", propOrder = {

})
public class CarrierPreference {

    protected int carrierId;
    protected CarrierPreference.DeliveryMethods deliveryMethods;

    /**
     * Gets the value of the carrierId property.
     * 
     */
    public int getCarrierId() {
        return carrierId;
    }

    /**
     * Sets the value of the carrierId property.
     * 
     */
    public void setCarrierId(int value) {
        this.carrierId = value;
    }

    /**
     * Gets the value of the deliveryMethods property.
     * 
     * @return
     *     possible object is
     *     {@link CarrierPreference.DeliveryMethods }
     *     
     */
    public CarrierPreference.DeliveryMethods getDeliveryMethods() {
        return deliveryMethods;
    }

    /**
     * Sets the value of the deliveryMethods property.
     * 
     * @param value
     *     allowed object is
     *     {@link CarrierPreference.DeliveryMethods }
     *     
     */
    public void setDeliveryMethods(CarrierPreference.DeliveryMethods value) {
        this.deliveryMethods = value;
    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType>
     *   &lt;complexContent>
     *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
     *       &lt;sequence>
     *         &lt;element name="deliveryMethod" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}DeliveryMethod" maxOccurs="unbounded" minOccurs="0"/>
     *       &lt;/sequence>
     *     &lt;/restriction>
     *   &lt;/complexContent>
     * &lt;/complexType>
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "deliveryMethod"
    })
    public static class DeliveryMethods {

        protected List<String> deliveryMethod;

        /**
         * Gets the value of the deliveryMethod property.
         * 
         * <p>
         * This accessor method returns a reference to the live list,
         * not a snapshot. Therefore any modification you make to the
         * returned list will be present inside the JAXB object.
         * This is why there is not a <CODE>set</CODE> method for the deliveryMethod property.
         * 
         * <p>
         * For example, to add a new item, do as follows:
         * <pre>
         *    getDeliveryMethod().add(newItem);
         * </pre>
         * 
         * 
         * <p>
         * Objects of the following type(s) are allowed in the list
         * {@link String }
         * 
         * 
         */
        public List<String> getDeliveryMethod() {
            if (deliveryMethod == null) {
                deliveryMethod = new ArrayList<String>();
            }
            return this.deliveryMethod;
        }

    }

}
