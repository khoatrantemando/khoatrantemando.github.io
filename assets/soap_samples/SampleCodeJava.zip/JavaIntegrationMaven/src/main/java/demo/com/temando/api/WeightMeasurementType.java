
package demo.com.temando.api;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for WeightMeasurementType.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * <p>
 * <pre>
 * &lt;simpleType name="WeightMeasurementType">
 *   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *     &lt;enumeration value="Grams"/>
 *     &lt;enumeration value="Kilograms"/>
 *     &lt;enumeration value="Ounces"/>
 *     &lt;enumeration value="Pounds"/>
 *   &lt;/restriction>
 * &lt;/simpleType>
 * </pre>
 * 
 */
@XmlType(name = "WeightMeasurementType", namespace = "http://api-demo.temando.com/schema/2009_06/common.xsd")
@XmlEnum
public enum WeightMeasurementType {

    @XmlEnumValue("Grams")
    GRAMS("Grams"),
    @XmlEnumValue("Kilograms")
    KILOGRAMS("Kilograms"),
    @XmlEnumValue("Ounces")
    OUNCES("Ounces"),
    @XmlEnumValue("Pounds")
    POUNDS("Pounds");
    private final String value;

    WeightMeasurementType(String v) {
        value = v;
    }

    public String value() {
        return value;
    }

    public static WeightMeasurementType fromValue(String v) {
        for (WeightMeasurementType c: WeightMeasurementType.values()) {
            if (c.value.equals(v)) {
                return c;
            }
        }
        throw new IllegalArgumentException(v);
    }

}
