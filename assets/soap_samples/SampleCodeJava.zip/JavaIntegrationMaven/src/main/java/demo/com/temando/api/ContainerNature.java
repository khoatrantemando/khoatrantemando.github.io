
package demo.com.temando.api;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for ContainerNature.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * <p>
 * <pre>
 * &lt;simpleType name="ContainerNature">
 *   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *     &lt;enumeration value="Shipping Container"/>
 *     &lt;enumeration value="Flat Rack"/>
 *     &lt;enumeration value="Open Top Container"/>
 *     &lt;enumeration value="High Cube"/>
 *     &lt;enumeration value="Curtin Sider"/>
 *   &lt;/restriction>
 * &lt;/simpleType>
 * </pre>
 * 
 */
@XmlType(name = "ContainerNature", namespace = "http://api-demo.temando.com/schema/2009_06/common.xsd")
@XmlEnum
public enum ContainerNature {

    @XmlEnumValue("Shipping Container")
    SHIPPING_CONTAINER("Shipping Container"),
    @XmlEnumValue("Flat Rack")
    FLAT_RACK("Flat Rack"),
    @XmlEnumValue("Open Top Container")
    OPEN_TOP_CONTAINER("Open Top Container"),
    @XmlEnumValue("High Cube")
    HIGH_CUBE("High Cube"),
    @XmlEnumValue("Curtin Sider")
    CURTIN_SIDER("Curtin Sider");
    private final String value;

    ContainerNature(String v) {
        value = v;
    }

    public String value() {
        return value;
    }

    public static ContainerNature fromValue(String v) {
        for (ContainerNature c: ContainerNature.values()) {
            if (c.value.equals(v)) {
                return c;
            }
        }
        throw new IllegalArgumentException(v);
    }

}
