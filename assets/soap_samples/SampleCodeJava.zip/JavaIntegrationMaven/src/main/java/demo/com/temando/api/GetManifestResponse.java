
package demo.com.temando.api;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for anonymous complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType>
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;all>
 *         &lt;element name="requests" minOccurs="0">
 *           &lt;complexType>
 *             &lt;complexContent>
 *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                 &lt;sequence>
 *                   &lt;element name="request" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}Request" maxOccurs="unbounded" minOccurs="0"/>
 *                 &lt;/sequence>
 *               &lt;/restriction>
 *             &lt;/complexContent>
 *           &lt;/complexType>
 *         &lt;/element>
 *         &lt;element name="manifestNumber" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}ManifestNumber" minOccurs="0"/>
 *         &lt;element name="manifestDocument" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}ManifestDocument" minOccurs="0"/>
 *         &lt;element name="manifestDocumentType" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}ManifestDocumentType" minOccurs="0"/>
 *         &lt;element name="labelDocument" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}LabelDocument" minOccurs="0"/>
 *         &lt;element name="labelDocumentType" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}LabelDocumentType" minOccurs="0"/>
 *         &lt;element name="labelPrinterType" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}LabelPrinterType" minOccurs="0"/>
 *       &lt;/all>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {

})
@XmlRootElement(name = "getManifestResponse")
public class GetManifestResponse {

    protected GetManifestResponse.Requests requests;
    protected String manifestNumber;
    protected String manifestDocument;
    protected ManifestDocumentType manifestDocumentType;
    protected String labelDocument;
    protected LabelDocumentType labelDocumentType;
    protected LabelPrinterType labelPrinterType;

    /**
     * Gets the value of the requests property.
     * 
     * @return
     *     possible object is
     *     {@link GetManifestResponse.Requests }
     *     
     */
    public GetManifestResponse.Requests getRequests() {
        return requests;
    }

    /**
     * Sets the value of the requests property.
     * 
     * @param value
     *     allowed object is
     *     {@link GetManifestResponse.Requests }
     *     
     */
    public void setRequests(GetManifestResponse.Requests value) {
        this.requests = value;
    }

    /**
     * Gets the value of the manifestNumber property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getManifestNumber() {
        return manifestNumber;
    }

    /**
     * Sets the value of the manifestNumber property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setManifestNumber(String value) {
        this.manifestNumber = value;
    }

    /**
     * Gets the value of the manifestDocument property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getManifestDocument() {
        return manifestDocument;
    }

    /**
     * Sets the value of the manifestDocument property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setManifestDocument(String value) {
        this.manifestDocument = value;
    }

    /**
     * Gets the value of the manifestDocumentType property.
     * 
     * @return
     *     possible object is
     *     {@link ManifestDocumentType }
     *     
     */
    public ManifestDocumentType getManifestDocumentType() {
        return manifestDocumentType;
    }

    /**
     * Sets the value of the manifestDocumentType property.
     * 
     * @param value
     *     allowed object is
     *     {@link ManifestDocumentType }
     *     
     */
    public void setManifestDocumentType(ManifestDocumentType value) {
        this.manifestDocumentType = value;
    }

    /**
     * Gets the value of the labelDocument property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLabelDocument() {
        return labelDocument;
    }

    /**
     * Sets the value of the labelDocument property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLabelDocument(String value) {
        this.labelDocument = value;
    }

    /**
     * Gets the value of the labelDocumentType property.
     * 
     * @return
     *     possible object is
     *     {@link LabelDocumentType }
     *     
     */
    public LabelDocumentType getLabelDocumentType() {
        return labelDocumentType;
    }

    /**
     * Sets the value of the labelDocumentType property.
     * 
     * @param value
     *     allowed object is
     *     {@link LabelDocumentType }
     *     
     */
    public void setLabelDocumentType(LabelDocumentType value) {
        this.labelDocumentType = value;
    }

    /**
     * Gets the value of the labelPrinterType property.
     * 
     * @return
     *     possible object is
     *     {@link LabelPrinterType }
     *     
     */
    public LabelPrinterType getLabelPrinterType() {
        return labelPrinterType;
    }

    /**
     * Sets the value of the labelPrinterType property.
     * 
     * @param value
     *     allowed object is
     *     {@link LabelPrinterType }
     *     
     */
    public void setLabelPrinterType(LabelPrinterType value) {
        this.labelPrinterType = value;
    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType>
     *   &lt;complexContent>
     *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
     *       &lt;sequence>
     *         &lt;element name="request" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}Request" maxOccurs="unbounded" minOccurs="0"/>
     *       &lt;/sequence>
     *     &lt;/restriction>
     *   &lt;/complexContent>
     * &lt;/complexType>
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "request"
    })
    public static class Requests {

        protected List<Request> request;

        /**
         * Gets the value of the request property.
         * 
         * <p>
         * This accessor method returns a reference to the live list,
         * not a snapshot. Therefore any modification you make to the
         * returned list will be present inside the JAXB object.
         * This is why there is not a <CODE>set</CODE> method for the request property.
         * 
         * <p>
         * For example, to add a new item, do as follows:
         * <pre>
         *    getRequest().add(newItem);
         * </pre>
         * 
         * 
         * <p>
         * Objects of the following type(s) are allowed in the list
         * {@link Request }
         * 
         * 
         */
        public List<Request> getRequest() {
            if (request == null) {
                request = new ArrayList<Request>();
            }
            return this.request;
        }

    }

}
