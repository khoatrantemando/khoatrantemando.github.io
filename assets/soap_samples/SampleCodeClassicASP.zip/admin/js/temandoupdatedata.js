function executetemandoupdate()
{
    document.getElementById('updateresult').innerHTML = "<img src='images/ajaxload.gif' border='0'> Processing...";
    var checkingurl="shopa_temandosql_function.asp";
    var pars = 'action='+document.getElementById('updatebutton').value+'&filename='+ escape(document.getElementById('Filename').value) +'';
    var target = 'updateresult';
    var myAjax = new Ajax.Updater(target, checkingurl, {method: 'post',parameters: pars});
	return false;
}

function changedefaultsupplier()
{
    document.getElementById('defaultsupplier').innerHTML = "<img src='images/ajaxload.gif' border='0'> Processing...";
    var checkingurl="shopa_temando_changedefaultsupplier.asp";
    var pars = 'temandodefaultsupplier='+document.getElementById('temandodefaultsupplier').value+'';
    var target = 'defaultsupplier';
    var myAjax = new Ajax.Updater(target, checkingurl, {method: 'post',parameters: pars});
}

function temandotracking(ooid,tid) {
    document.getElementById(ooid).innerHTML = "<img src='images/ajaxload.gif' border='0'>checking...";
    var checkingurl="../temando_tracking_ajax.asp";
    var pars = 'oid='+ooid+'&trackID='+tid+'';
    var target = ''+ooid+'';
    var myAjax = new Ajax.Updater(target, checkingurl, {method: 'post',parameters: pars});
}