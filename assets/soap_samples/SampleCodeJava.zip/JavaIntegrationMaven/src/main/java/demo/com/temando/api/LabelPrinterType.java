
package demo.com.temando.api;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for LabelPrinterType.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * <p>
 * <pre>
 * &lt;simpleType name="LabelPrinterType">
 *   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *     &lt;enumeration value="Thermal"/>
 *     &lt;enumeration value="Standard"/>
 *   &lt;/restriction>
 * &lt;/simpleType>
 * </pre>
 * 
 */
@XmlType(name = "LabelPrinterType", namespace = "http://api-demo.temando.com/schema/2009_06/common.xsd")
@XmlEnum
public enum LabelPrinterType {

    @XmlEnumValue("Thermal")
    THERMAL("Thermal"),
    @XmlEnumValue("Standard")
    STANDARD("Standard");
    private final String value;

    LabelPrinterType(String v) {
        value = v;
    }

    public String value() {
        return value;
    }

    public static LabelPrinterType fromValue(String v) {
        for (LabelPrinterType c: LabelPrinterType.values()) {
            if (c.value.equals(v)) {
                return c;
            }
        }
        throw new IllegalArgumentException(v);
    }

}
