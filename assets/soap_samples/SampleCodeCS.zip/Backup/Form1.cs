﻿using System;
using System.Text;
using System.Windows.Forms;
using TemandoSample.TemandoTrainingService;
//using TemandoSample.TemandoLiveService;

namespace TemandoSample
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnTest_Click(object sender, EventArgs e)
        {
            var adapter = new TemandoTrainingAdapter("http://api-demo.temando.com/soapServer.html", "temandotest", "password");
            //var adapter = new TemandoLiveAdapter("http://api.temando.com/soapServer.html", "yourUserName", "yourPassword");

            quoting_portTypeClient client = adapter.Client;

            var anythingsTest = new[] {
                                          new Anything {
                                                           @class = Class.Freight,
                                                           mode = Mode.Lessthanload,
                                                           modeSpecified = true,
                                                           packaging = Packaging.Carton,
                                                           packagingSpecified = true,
                                                           qualifierFreightGeneralFragile =
                                                               YesNoOption.N,
                                                           qualifierFreightGeneralFragileSpecified
                                                               = true,
                                                           distanceMeasurementType =
                                                               DistanceMeasurementType.
                                                               Centimetres,
                                                           distanceMeasurementTypeSpecified =
                                                               true,
                                                           weightMeasurementType =
                                                               WeightMeasurementType.Kilograms,
                                                           weightMeasurementTypeSpecified = true,
                                                           length = 500,
                                                           lengthSpecified = true,
                                                           height = 500,
                                                           heightSpecified = true,
                                                           width = 500,
                                                           widthSpecified = true,
                                                           weight = 2,
                                                           weightSpecified = true,
                                                           quantity = 1,
                                                           description = "Contains bottle lids."
                                                       }
                                      };

            var anywhereTest = new Anywhere
            {
                itemNature = DeliveryNature.Domestic,
                itemMethod = DeliveryType.DoortoDoor,
                originCountry = "AU",
                originCode = "4000",
                originSuburb = "Brisbane",
                destinationCountry = "AU",
                destinationCode = "2000",
                destinationSuburb = "Sydney",
                destinationIs = LocationType.Business,
                destinationBusNotifyBefore = YesNoOption.N,
                destinationBusNotifyBeforeSpecified = true,
                destinationBusLimitedAccess = YesNoOption.N,
                destinationBusLimitedAccessSpecified = true,
                originIs = LocationType.Business,
                originBusNotifyBefore = YesNoOption.Y,
                originBusNotifyBeforeSpecified = true,
                originBusLimitedAccess = YesNoOption.N,
                originBusLimitedAccessSpecified = true
            };

            var anytimeTest = new Anytime
            {
                //must after current date
                readyDate = DateTime.Today.AddDays(1).ToString("yyyy-MM-dd"),
                readyTime = ReadyTime.AM
            };

            AvailableQuote[] resultQuotes = client.getQuotesByRequest(
                new getQuotesByRequest
                {
                    anythings = anythingsTest,
                    anywhere = anywhereTest,
                    anytime = anytimeTest
                }
                );

            var sbResult = new StringBuilder();
            sbResult.AppendLine();
            sbResult.AppendFormat(
                "================================ getQuotesByRequest results ================================");
            sbResult.AppendLine();

            int quoteNumber = 0;
            foreach (AvailableQuote quote in resultQuotes)
            {
                quoteNumber++;
                sbResult.AppendLine();
                sbResult.AppendLine().AppendFormat("---------------- Quote #{0} ----------------", quoteNumber);
                sbResult.AppendLine();
                //sbResult.AppendLine().AppendFormat("id: {0}", quote.id);
                //sbResult.AppendLine().AppendFormat("bookingNumber: {0}", quote.bookingNumber);
                //sbResult.AppendLine().AppendFormat("generated: {0}", quote.generated);
                //sbResult.AppendLine().AppendFormat("accepted: {0}", quote.accepted);
                //sbResult.AppendLine().AppendFormat("consignmentNumber: {0}", quote.consignmentNumber);
                sbResult.AppendLine().AppendFormat("totalPrice: {0}", quote.totalPrice);
                sbResult.AppendLine().AppendFormat("basePrice: {0}", quote.basePrice);
                sbResult.AppendLine().AppendFormat("tax: {0}", quote.tax);
                sbResult.AppendLine().AppendFormat("currency: {0}", quote.currency);
                //sbResult.AppendLine().AppendFormat("deliveryMethod: {0}", quote.deliveryMethod);
                //sbResult.AppendLine().AppendFormat("usingGeneralRail: {0}", quote.usingGeneralRail);
                //sbResult.AppendLine().AppendFormat("usingGeneralRoad: {0}", quote.usingGeneralRoad);
                //sbResult.AppendLine().AppendFormat("usingGeneralSea: {0}", quote.usingGeneralSea);
                //sbResult.AppendLine().AppendFormat("usingExpressAir: {0}", quote.usingExpressAir);
                //sbResult.AppendLine().AppendFormat("usingExpressRoad: {0}", quote.usingExpressRoad);
                //sbResult.AppendLine().AppendFormat("etaFrom: {0}", quote.etaFrom);
                //sbResult.AppendLine().AppendFormat("etaTo: {0}", quote.etaTo);
                //sbResult.AppendLine().AppendFormat("guaranteedEta: {0}", quote.guaranteedEta);
                //sbResult.AppendLine().AppendFormat("---------------- adjustments:");
                //foreach (Adjustment adjustment in quote.adjustments)
                //{
                //    sbResult.AppendLine().AppendFormat("adjustment description: {0}", adjustment.description);
                //    sbResult.AppendLine().AppendFormat("amount: {0}", adjustment.amount);
                //    sbResult.AppendLine().AppendFormat("tax: {0}", adjustment.tax);
                //    sbResult.AppendLine().AppendFormat("----------------");
                //}

                //sbResult.AppendLine().AppendFormat("---------------- inclusions:");
                //foreach (Inclusion inclusion in quote.inclusions)
                //{
                //    sbResult.AppendLine().AppendFormat("inclusion details: {0}", inclusion.details);
                //    sbResult.AppendLine().AppendFormat("summary: {0}", inclusion.summary);
                //    sbResult.AppendLine().AppendFormat("-----------------");
                //}
                sbResult.AppendLine().AppendFormat("---------------- carrier:");

                if (quote.carrier != null)
                {
                    sbResult.AppendLine().AppendFormat("carrierId: {0}", quote.carrier.id);
                    sbResult.AppendLine().AppendFormat("companyName: {0}", quote.carrier.companyName);
                    sbResult.AppendLine().AppendFormat("companyContact: {0}", quote.carrier.companyContact);
                    sbResult.AppendLine().AppendFormat("streetAddress: {0}", quote.carrier.streetAddress);
                    sbResult.AppendLine().AppendFormat("streetSuburb: {0}", quote.carrier.streetSuburb);
                    sbResult.AppendLine().AppendFormat("streetCity: {0}", quote.carrier.streetCity);
                    sbResult.AppendLine().AppendFormat("streetState: {0}", quote.carrier.streetState);
                    sbResult.AppendLine().AppendFormat("streetCode: {0}", quote.carrier.streetCode);
                    sbResult.AppendLine().AppendFormat("streetCountry: {0}", quote.carrier.streetCountry);
                    sbResult.AppendLine().AppendFormat("postalAddress: {0}", quote.carrier.postalAddress);
                    sbResult.AppendLine().AppendFormat("postalSuburb: {0}", quote.carrier.postalSuburb);
                    sbResult.AppendLine().AppendFormat("postalCity: {0}", quote.carrier.postalCity);
                    sbResult.AppendLine().AppendFormat("postalState: {0}", quote.carrier.postalState);
                    sbResult.AppendLine().AppendFormat("postalCode: {0}", quote.carrier.postalCode);
                    sbResult.AppendLine().AppendFormat("postalCountry: {0}", quote.carrier.postalCountry);
                    sbResult.AppendLine().AppendFormat("phone1: {0}", quote.carrier.phone1);
                    sbResult.AppendLine().AppendFormat("email: {0}", quote.carrier.email);
                    sbResult.AppendLine().AppendFormat("website: {0}", quote.carrier.website);
                }
            }

            sbResult.AppendLine();
            sbResult.AppendLine().AppendFormat(
                "================================ {0} quotes in total ================================", quoteNumber);
            sbResult.AppendLine();


            txtTest.Text = sbResult.ToString();
        }
    }
}
