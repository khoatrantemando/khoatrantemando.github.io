
package demo.com.temando.api;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for anonymous complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType>
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;all>
 *         &lt;element name="anythings">
 *           &lt;complexType>
 *             &lt;complexContent>
 *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                 &lt;sequence>
 *                   &lt;element name="anything" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}Anything" maxOccurs="10"/>
 *                 &lt;/sequence>
 *               &lt;/restriction>
 *             &lt;/complexContent>
 *           &lt;/complexType>
 *         &lt;/element>
 *         &lt;element name="handlingEquipments" minOccurs="0">
 *           &lt;complexType>
 *             &lt;complexContent>
 *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                 &lt;sequence>
 *                   &lt;element name="handlingEquipment" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}HandlingEquipment" maxOccurs="10"/>
 *                 &lt;/sequence>
 *               &lt;/restriction>
 *             &lt;/complexContent>
 *           &lt;/complexType>
 *         &lt;/element>
 *         &lt;element name="anywhere" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}Anywhere"/>
 *         &lt;element name="anytime" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}Anytime" minOccurs="0"/>
 *         &lt;element name="general" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}General" minOccurs="0"/>
 *         &lt;element name="origin" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}Location"/>
 *         &lt;element name="destination" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}Location"/>
 *         &lt;element name="returnto" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}Location" minOccurs="0"/>
 *         &lt;element name="quote" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}BookingQuote" minOccurs="0"/>
 *         &lt;element name="quoteFilter" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}QuoteFilter" minOccurs="0"/>
 *         &lt;element name="payment" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}Payment"/>
 *         &lt;element name="instructions" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}Instructions" minOccurs="0"/>
 *         &lt;element name="comments" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}Comments" minOccurs="0"/>
 *         &lt;element name="reference" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}ClientReference" minOccurs="0"/>
 *         &lt;element name="promotionCode" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}PromotionCode" minOccurs="0"/>
 *         &lt;element name="clientId" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}ClientId" minOccurs="0"/>
 *         &lt;element name="labelPrinterType" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}LabelPrinterType" minOccurs="0"/>
 *         &lt;element name="responseExclusions" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}ResponseExclusions" minOccurs="0"/>
 *       &lt;/all>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {

})
@XmlRootElement(name = "makeBooking")
public class MakeBooking {

    @XmlElement(required = true)
    protected MakeBooking.Anythings anythings;
    protected MakeBooking.HandlingEquipments handlingEquipments;
    @XmlElement(required = true)
    protected Anywhere anywhere;
    protected Anytime anytime;
    protected General general;
    @XmlElement(required = true)
    protected Location origin;
    @XmlElement(required = true)
    protected Location destination;
    protected Location returnto;
    protected BookingQuote quote;
    protected QuoteFilter quoteFilter;
    @XmlElement(required = true)
    protected Payment payment;
    protected String instructions;
    protected String comments;
    protected String reference;
    protected String promotionCode;
    protected Integer clientId;
    protected LabelPrinterType labelPrinterType;
    protected ResponseExclusions responseExclusions;

    /**
     * Gets the value of the anythings property.
     * 
     * @return
     *     possible object is
     *     {@link MakeBooking.Anythings }
     *     
     */
    public MakeBooking.Anythings getAnythings() {
        return anythings;
    }

    /**
     * Sets the value of the anythings property.
     * 
     * @param value
     *     allowed object is
     *     {@link MakeBooking.Anythings }
     *     
     */
    public void setAnythings(MakeBooking.Anythings value) {
        this.anythings = value;
    }

    /**
     * Gets the value of the handlingEquipments property.
     * 
     * @return
     *     possible object is
     *     {@link MakeBooking.HandlingEquipments }
     *     
     */
    public MakeBooking.HandlingEquipments getHandlingEquipments() {
        return handlingEquipments;
    }

    /**
     * Sets the value of the handlingEquipments property.
     * 
     * @param value
     *     allowed object is
     *     {@link MakeBooking.HandlingEquipments }
     *     
     */
    public void setHandlingEquipments(MakeBooking.HandlingEquipments value) {
        this.handlingEquipments = value;
    }

    /**
     * Gets the value of the anywhere property.
     * 
     * @return
     *     possible object is
     *     {@link Anywhere }
     *     
     */
    public Anywhere getAnywhere() {
        return anywhere;
    }

    /**
     * Sets the value of the anywhere property.
     * 
     * @param value
     *     allowed object is
     *     {@link Anywhere }
     *     
     */
    public void setAnywhere(Anywhere value) {
        this.anywhere = value;
    }

    /**
     * Gets the value of the anytime property.
     * 
     * @return
     *     possible object is
     *     {@link Anytime }
     *     
     */
    public Anytime getAnytime() {
        return anytime;
    }

    /**
     * Sets the value of the anytime property.
     * 
     * @param value
     *     allowed object is
     *     {@link Anytime }
     *     
     */
    public void setAnytime(Anytime value) {
        this.anytime = value;
    }

    /**
     * Gets the value of the general property.
     * 
     * @return
     *     possible object is
     *     {@link General }
     *     
     */
    public General getGeneral() {
        return general;
    }

    /**
     * Sets the value of the general property.
     * 
     * @param value
     *     allowed object is
     *     {@link General }
     *     
     */
    public void setGeneral(General value) {
        this.general = value;
    }

    /**
     * Gets the value of the origin property.
     * 
     * @return
     *     possible object is
     *     {@link Location }
     *     
     */
    public Location getOrigin() {
        return origin;
    }

    /**
     * Sets the value of the origin property.
     * 
     * @param value
     *     allowed object is
     *     {@link Location }
     *     
     */
    public void setOrigin(Location value) {
        this.origin = value;
    }

    /**
     * Gets the value of the destination property.
     * 
     * @return
     *     possible object is
     *     {@link Location }
     *     
     */
    public Location getDestination() {
        return destination;
    }

    /**
     * Sets the value of the destination property.
     * 
     * @param value
     *     allowed object is
     *     {@link Location }
     *     
     */
    public void setDestination(Location value) {
        this.destination = value;
    }

    /**
     * Gets the value of the returnto property.
     * 
     * @return
     *     possible object is
     *     {@link Location }
     *     
     */
    public Location getReturnto() {
        return returnto;
    }

    /**
     * Sets the value of the returnto property.
     * 
     * @param value
     *     allowed object is
     *     {@link Location }
     *     
     */
    public void setReturnto(Location value) {
        this.returnto = value;
    }

    /**
     * Gets the value of the quote property.
     * 
     * @return
     *     possible object is
     *     {@link BookingQuote }
     *     
     */
    public BookingQuote getQuote() {
        return quote;
    }

    /**
     * Sets the value of the quote property.
     * 
     * @param value
     *     allowed object is
     *     {@link BookingQuote }
     *     
     */
    public void setQuote(BookingQuote value) {
        this.quote = value;
    }

    /**
     * Gets the value of the quoteFilter property.
     * 
     * @return
     *     possible object is
     *     {@link QuoteFilter }
     *     
     */
    public QuoteFilter getQuoteFilter() {
        return quoteFilter;
    }

    /**
     * Sets the value of the quoteFilter property.
     * 
     * @param value
     *     allowed object is
     *     {@link QuoteFilter }
     *     
     */
    public void setQuoteFilter(QuoteFilter value) {
        this.quoteFilter = value;
    }

    /**
     * Gets the value of the payment property.
     * 
     * @return
     *     possible object is
     *     {@link Payment }
     *     
     */
    public Payment getPayment() {
        return payment;
    }

    /**
     * Sets the value of the payment property.
     * 
     * @param value
     *     allowed object is
     *     {@link Payment }
     *     
     */
    public void setPayment(Payment value) {
        this.payment = value;
    }

    /**
     * Gets the value of the instructions property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getInstructions() {
        return instructions;
    }

    /**
     * Sets the value of the instructions property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setInstructions(String value) {
        this.instructions = value;
    }

    /**
     * Gets the value of the comments property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getComments() {
        return comments;
    }

    /**
     * Sets the value of the comments property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setComments(String value) {
        this.comments = value;
    }

    /**
     * Gets the value of the reference property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getReference() {
        return reference;
    }

    /**
     * Sets the value of the reference property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setReference(String value) {
        this.reference = value;
    }

    /**
     * Gets the value of the promotionCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPromotionCode() {
        return promotionCode;
    }

    /**
     * Sets the value of the promotionCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPromotionCode(String value) {
        this.promotionCode = value;
    }

    /**
     * Gets the value of the clientId property.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getClientId() {
        return clientId;
    }

    /**
     * Sets the value of the clientId property.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setClientId(Integer value) {
        this.clientId = value;
    }

    /**
     * Gets the value of the labelPrinterType property.
     * 
     * @return
     *     possible object is
     *     {@link LabelPrinterType }
     *     
     */
    public LabelPrinterType getLabelPrinterType() {
        return labelPrinterType;
    }

    /**
     * Sets the value of the labelPrinterType property.
     * 
     * @param value
     *     allowed object is
     *     {@link LabelPrinterType }
     *     
     */
    public void setLabelPrinterType(LabelPrinterType value) {
        this.labelPrinterType = value;
    }

    /**
     * Gets the value of the responseExclusions property.
     * 
     * @return
     *     possible object is
     *     {@link ResponseExclusions }
     *     
     */
    public ResponseExclusions getResponseExclusions() {
        return responseExclusions;
    }

    /**
     * Sets the value of the responseExclusions property.
     * 
     * @param value
     *     allowed object is
     *     {@link ResponseExclusions }
     *     
     */
    public void setResponseExclusions(ResponseExclusions value) {
        this.responseExclusions = value;
    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType>
     *   &lt;complexContent>
     *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
     *       &lt;sequence>
     *         &lt;element name="anything" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}Anything" maxOccurs="10"/>
     *       &lt;/sequence>
     *     &lt;/restriction>
     *   &lt;/complexContent>
     * &lt;/complexType>
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "anything"
    })
    public static class Anythings {

        @XmlElement(required = true)
        protected List<Anything> anything;

        /**
         * Gets the value of the anything property.
         * 
         * <p>
         * This accessor method returns a reference to the live list,
         * not a snapshot. Therefore any modification you make to the
         * returned list will be present inside the JAXB object.
         * This is why there is not a <CODE>set</CODE> method for the anything property.
         * 
         * <p>
         * For example, to add a new item, do as follows:
         * <pre>
         *    getAnything().add(newItem);
         * </pre>
         * 
         * 
         * <p>
         * Objects of the following type(s) are allowed in the list
         * {@link Anything }
         * 
         * 
         */
        public List<Anything> getAnything() {
            if (anything == null) {
                anything = new ArrayList<Anything>();
            }
            return this.anything;
        }

    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType>
     *   &lt;complexContent>
     *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
     *       &lt;sequence>
     *         &lt;element name="handlingEquipment" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}HandlingEquipment" maxOccurs="10"/>
     *       &lt;/sequence>
     *     &lt;/restriction>
     *   &lt;/complexContent>
     * &lt;/complexType>
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "handlingEquipment"
    })
    public static class HandlingEquipments {

        @XmlElement(required = true)
        protected List<HandlingEquipment> handlingEquipment;

        /**
         * Gets the value of the handlingEquipment property.
         * 
         * <p>
         * This accessor method returns a reference to the live list,
         * not a snapshot. Therefore any modification you make to the
         * returned list will be present inside the JAXB object.
         * This is why there is not a <CODE>set</CODE> method for the handlingEquipment property.
         * 
         * <p>
         * For example, to add a new item, do as follows:
         * <pre>
         *    getHandlingEquipment().add(newItem);
         * </pre>
         * 
         * 
         * <p>
         * Objects of the following type(s) are allowed in the list
         * {@link HandlingEquipment }
         * 
         * 
         */
        public List<HandlingEquipment> getHandlingEquipment() {
            if (handlingEquipment == null) {
                handlingEquipment = new ArrayList<HandlingEquipment>();
            }
            return this.handlingEquipment;
        }

    }

}
