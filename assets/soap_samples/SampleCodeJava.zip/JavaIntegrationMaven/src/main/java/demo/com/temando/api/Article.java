
package demo.com.temando.api;

import java.math.BigDecimal;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for Article complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="Article">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;all>
 *         &lt;element name="anythingIndex" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}AnythingIndex" minOccurs="0"/>
 *         &lt;element name="articleNumber" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}ArticleNumber" minOccurs="0"/>
 *         &lt;element name="description" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}ItemDescription" minOccurs="0"/>
 *         &lt;element name="sku" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}SKU" minOccurs="0"/>
 *         &lt;element name="sscc" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}SSCC" minOccurs="0"/>
 *         &lt;element name="hs" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}HS" minOccurs="0"/>
 *         &lt;element name="lineItemReference" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}LineItemReference" minOccurs="0"/>
 *         &lt;element name="labelDocument" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}LabelDocument" minOccurs="0"/>
 *         &lt;element name="labelDocumentType" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}LabelDocumentType" minOccurs="0"/>
 *         &lt;element name="countryOfOrigin" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}CountryCode" minOccurs="0"/>
 *         &lt;element name="countryOfManufacture" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}CountryCode" minOccurs="0"/>
 *         &lt;element name="composition" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}Composition" minOccurs="0"/>
 *         &lt;element name="goodsValue" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}CurrencyAmount" minOccurs="0"/>
 *         &lt;element name="goodsCurrency" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}CurrencyType" minOccurs="0"/>
 *       &lt;/all>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "Article", namespace = "http://api-demo.temando.com/schema/2009_06/common.xsd", propOrder = {

})
public class Article {

    protected Integer anythingIndex;
    protected String articleNumber;
    protected String description;
    protected String sku;
    protected String sscc;
    protected String hs;
    protected String lineItemReference;
    protected String labelDocument;
    protected LabelDocumentType labelDocumentType;
    protected String countryOfOrigin;
    protected String countryOfManufacture;
    protected String composition;
    protected BigDecimal goodsValue;
    protected CurrencyType goodsCurrency;

    /**
     * Gets the value of the anythingIndex property.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getAnythingIndex() {
        return anythingIndex;
    }

    /**
     * Sets the value of the anythingIndex property.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setAnythingIndex(Integer value) {
        this.anythingIndex = value;
    }

    /**
     * Gets the value of the articleNumber property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getArticleNumber() {
        return articleNumber;
    }

    /**
     * Sets the value of the articleNumber property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setArticleNumber(String value) {
        this.articleNumber = value;
    }

    /**
     * Gets the value of the description property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDescription() {
        return description;
    }

    /**
     * Sets the value of the description property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDescription(String value) {
        this.description = value;
    }

    /**
     * Gets the value of the sku property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSku() {
        return sku;
    }

    /**
     * Sets the value of the sku property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSku(String value) {
        this.sku = value;
    }

    /**
     * Gets the value of the sscc property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSscc() {
        return sscc;
    }

    /**
     * Sets the value of the sscc property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSscc(String value) {
        this.sscc = value;
    }

    /**
     * Gets the value of the hs property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getHs() {
        return hs;
    }

    /**
     * Sets the value of the hs property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setHs(String value) {
        this.hs = value;
    }

    /**
     * Gets the value of the lineItemReference property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLineItemReference() {
        return lineItemReference;
    }

    /**
     * Sets the value of the lineItemReference property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLineItemReference(String value) {
        this.lineItemReference = value;
    }

    /**
     * Gets the value of the labelDocument property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLabelDocument() {
        return labelDocument;
    }

    /**
     * Sets the value of the labelDocument property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLabelDocument(String value) {
        this.labelDocument = value;
    }

    /**
     * Gets the value of the labelDocumentType property.
     * 
     * @return
     *     possible object is
     *     {@link LabelDocumentType }
     *     
     */
    public LabelDocumentType getLabelDocumentType() {
        return labelDocumentType;
    }

    /**
     * Sets the value of the labelDocumentType property.
     * 
     * @param value
     *     allowed object is
     *     {@link LabelDocumentType }
     *     
     */
    public void setLabelDocumentType(LabelDocumentType value) {
        this.labelDocumentType = value;
    }

    /**
     * Gets the value of the countryOfOrigin property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCountryOfOrigin() {
        return countryOfOrigin;
    }

    /**
     * Sets the value of the countryOfOrigin property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCountryOfOrigin(String value) {
        this.countryOfOrigin = value;
    }

    /**
     * Gets the value of the countryOfManufacture property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCountryOfManufacture() {
        return countryOfManufacture;
    }

    /**
     * Sets the value of the countryOfManufacture property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCountryOfManufacture(String value) {
        this.countryOfManufacture = value;
    }

    /**
     * Gets the value of the composition property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getComposition() {
        return composition;
    }

    /**
     * Sets the value of the composition property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setComposition(String value) {
        this.composition = value;
    }

    /**
     * Gets the value of the goodsValue property.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getGoodsValue() {
        return goodsValue;
    }

    /**
     * Sets the value of the goodsValue property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setGoodsValue(BigDecimal value) {
        this.goodsValue = value;
    }

    /**
     * Gets the value of the goodsCurrency property.
     * 
     * @return
     *     possible object is
     *     {@link CurrencyType }
     *     
     */
    public CurrencyType getGoodsCurrency() {
        return goodsCurrency;
    }

    /**
     * Sets the value of the goodsCurrency property.
     * 
     * @param value
     *     allowed object is
     *     {@link CurrencyType }
     *     
     */
    public void setGoodsCurrency(CurrencyType value) {
        this.goodsCurrency = value;
    }

}
