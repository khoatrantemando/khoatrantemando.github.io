
package demo.com.temando.api;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for ZoneRange complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="ZoneRange">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;all>
 *         &lt;element name="startCode" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}PostalCode"/>
 *         &lt;element name="endCode" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}PostalCode"/>
 *       &lt;/all>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ZoneRange", namespace = "http://api-demo.temando.com/schema/2009_06/common.xsd", propOrder = {

})
public class ZoneRange {

    @XmlElement(required = true)
    protected String startCode;
    @XmlElement(required = true)
    protected String endCode;

    /**
     * Gets the value of the startCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getStartCode() {
        return startCode;
    }

    /**
     * Sets the value of the startCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setStartCode(String value) {
        this.startCode = value;
    }

    /**
     * Gets the value of the endCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getEndCode() {
        return endCode;
    }

    /**
     * Sets the value of the endCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setEndCode(String value) {
        this.endCode = value;
    }

}
