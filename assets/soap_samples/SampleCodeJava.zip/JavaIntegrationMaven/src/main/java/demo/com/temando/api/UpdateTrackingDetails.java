
package demo.com.temando.api;

import java.math.BigInteger;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for anonymous complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType>
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;all>
 *         &lt;element name="requestId" type="{http://www.w3.org/2001/XMLSchema}positiveInteger" minOccurs="0"/>
 *         &lt;element name="bookingNumber" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}BookingNumber" minOccurs="0"/>
 *         &lt;element name="trackingStatus" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}TrackingStatus"/>
 *         &lt;element name="trackingStatusOccurred" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}Datetime"/>
 *         &lt;element name="trackingFurtherDetails" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}TrackingFurtherDetails" minOccurs="0"/>
 *         &lt;element name="trackingDocument" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}TrackingDocument" minOccurs="0"/>
 *         &lt;element name="trackingDocumentType" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}TrackingDocumentType" minOccurs="0"/>
 *       &lt;/all>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {

})
@XmlRootElement(name = "updateTrackingDetails")
public class UpdateTrackingDetails {

    @XmlSchemaType(name = "positiveInteger")
    protected BigInteger requestId;
    protected String bookingNumber;
    @XmlElement(required = true)
    protected TrackingStatus trackingStatus;
    @XmlElement(required = true)
    protected String trackingStatusOccurred;
    protected String trackingFurtherDetails;
    protected String trackingDocument;
    protected TrackingDocumentType trackingDocumentType;

    /**
     * Gets the value of the requestId property.
     * 
     * @return
     *     possible object is
     *     {@link BigInteger }
     *     
     */
    public BigInteger getRequestId() {
        return requestId;
    }

    /**
     * Sets the value of the requestId property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigInteger }
     *     
     */
    public void setRequestId(BigInteger value) {
        this.requestId = value;
    }

    /**
     * Gets the value of the bookingNumber property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getBookingNumber() {
        return bookingNumber;
    }

    /**
     * Sets the value of the bookingNumber property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setBookingNumber(String value) {
        this.bookingNumber = value;
    }

    /**
     * Gets the value of the trackingStatus property.
     * 
     * @return
     *     possible object is
     *     {@link TrackingStatus }
     *     
     */
    public TrackingStatus getTrackingStatus() {
        return trackingStatus;
    }

    /**
     * Sets the value of the trackingStatus property.
     * 
     * @param value
     *     allowed object is
     *     {@link TrackingStatus }
     *     
     */
    public void setTrackingStatus(TrackingStatus value) {
        this.trackingStatus = value;
    }

    /**
     * Gets the value of the trackingStatusOccurred property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTrackingStatusOccurred() {
        return trackingStatusOccurred;
    }

    /**
     * Sets the value of the trackingStatusOccurred property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTrackingStatusOccurred(String value) {
        this.trackingStatusOccurred = value;
    }

    /**
     * Gets the value of the trackingFurtherDetails property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTrackingFurtherDetails() {
        return trackingFurtherDetails;
    }

    /**
     * Sets the value of the trackingFurtherDetails property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTrackingFurtherDetails(String value) {
        this.trackingFurtherDetails = value;
    }

    /**
     * Gets the value of the trackingDocument property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTrackingDocument() {
        return trackingDocument;
    }

    /**
     * Sets the value of the trackingDocument property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTrackingDocument(String value) {
        this.trackingDocument = value;
    }

    /**
     * Gets the value of the trackingDocumentType property.
     * 
     * @return
     *     possible object is
     *     {@link TrackingDocumentType }
     *     
     */
    public TrackingDocumentType getTrackingDocumentType() {
        return trackingDocumentType;
    }

    /**
     * Sets the value of the trackingDocumentType property.
     * 
     * @param value
     *     allowed object is
     *     {@link TrackingDocumentType }
     *     
     */
    public void setTrackingDocumentType(TrackingDocumentType value) {
        this.trackingDocumentType = value;
    }

}
