
package demo.com.temando.api;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for Carrier complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="Carrier">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;all>
 *         &lt;element name="id" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}CarrierId"/>
 *         &lt;element name="companyName" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}CompanyName"/>
 *         &lt;element name="companyContact" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}ContactName"/>
 *         &lt;element name="streetAddress" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}Address" minOccurs="0"/>
 *         &lt;element name="streetSuburb" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}Suburb" minOccurs="0"/>
 *         &lt;element name="streetCity" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}City" minOccurs="0"/>
 *         &lt;element name="streetState" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}State" minOccurs="0"/>
 *         &lt;element name="streetCode" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}PostalCode" minOccurs="0"/>
 *         &lt;element name="streetCountry" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}CountryCode" minOccurs="0"/>
 *         &lt;element name="postalAddress" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}Address" minOccurs="0"/>
 *         &lt;element name="postalSuburb" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}Suburb" minOccurs="0"/>
 *         &lt;element name="postalCity" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}City" minOccurs="0"/>
 *         &lt;element name="postalState" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}State" minOccurs="0"/>
 *         &lt;element name="postalCode" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}PostalCode" minOccurs="0"/>
 *         &lt;element name="postalCountry" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}CountryCode" minOccurs="0"/>
 *         &lt;element name="phone1" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}Phone" minOccurs="0"/>
 *         &lt;element name="phone2" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}Phone" minOccurs="0"/>
 *         &lt;element name="email" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}Email" minOccurs="0"/>
 *         &lt;element name="website" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}Website" minOccurs="0"/>
 *         &lt;element name="conditions" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}CarrierConditions" minOccurs="0"/>
 *       &lt;/all>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "Carrier", namespace = "http://api-demo.temando.com/schema/2009_06/common.xsd", propOrder = {

})
public class Carrier {

    protected int id;
    @XmlElement(required = true)
    protected String companyName;
    @XmlElement(required = true)
    protected String companyContact;
    protected String streetAddress;
    protected String streetSuburb;
    protected String streetCity;
    protected String streetState;
    protected String streetCode;
    protected String streetCountry;
    protected String postalAddress;
    protected String postalSuburb;
    protected String postalCity;
    protected String postalState;
    protected String postalCode;
    protected String postalCountry;
    protected String phone1;
    protected String phone2;
    protected String email;
    protected String website;
    protected String conditions;

    /**
     * Gets the value of the id property.
     * 
     */
    public int getId() {
        return id;
    }

    /**
     * Sets the value of the id property.
     * 
     */
    public void setId(int value) {
        this.id = value;
    }

    /**
     * Gets the value of the companyName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCompanyName() {
        return companyName;
    }

    /**
     * Sets the value of the companyName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCompanyName(String value) {
        this.companyName = value;
    }

    /**
     * Gets the value of the companyContact property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCompanyContact() {
        return companyContact;
    }

    /**
     * Sets the value of the companyContact property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCompanyContact(String value) {
        this.companyContact = value;
    }

    /**
     * Gets the value of the streetAddress property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getStreetAddress() {
        return streetAddress;
    }

    /**
     * Sets the value of the streetAddress property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setStreetAddress(String value) {
        this.streetAddress = value;
    }

    /**
     * Gets the value of the streetSuburb property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getStreetSuburb() {
        return streetSuburb;
    }

    /**
     * Sets the value of the streetSuburb property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setStreetSuburb(String value) {
        this.streetSuburb = value;
    }

    /**
     * Gets the value of the streetCity property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getStreetCity() {
        return streetCity;
    }

    /**
     * Sets the value of the streetCity property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setStreetCity(String value) {
        this.streetCity = value;
    }

    /**
     * Gets the value of the streetState property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getStreetState() {
        return streetState;
    }

    /**
     * Sets the value of the streetState property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setStreetState(String value) {
        this.streetState = value;
    }

    /**
     * Gets the value of the streetCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getStreetCode() {
        return streetCode;
    }

    /**
     * Sets the value of the streetCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setStreetCode(String value) {
        this.streetCode = value;
    }

    /**
     * Gets the value of the streetCountry property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getStreetCountry() {
        return streetCountry;
    }

    /**
     * Sets the value of the streetCountry property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setStreetCountry(String value) {
        this.streetCountry = value;
    }

    /**
     * Gets the value of the postalAddress property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPostalAddress() {
        return postalAddress;
    }

    /**
     * Sets the value of the postalAddress property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPostalAddress(String value) {
        this.postalAddress = value;
    }

    /**
     * Gets the value of the postalSuburb property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPostalSuburb() {
        return postalSuburb;
    }

    /**
     * Sets the value of the postalSuburb property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPostalSuburb(String value) {
        this.postalSuburb = value;
    }

    /**
     * Gets the value of the postalCity property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPostalCity() {
        return postalCity;
    }

    /**
     * Sets the value of the postalCity property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPostalCity(String value) {
        this.postalCity = value;
    }

    /**
     * Gets the value of the postalState property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPostalState() {
        return postalState;
    }

    /**
     * Sets the value of the postalState property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPostalState(String value) {
        this.postalState = value;
    }

    /**
     * Gets the value of the postalCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPostalCode() {
        return postalCode;
    }

    /**
     * Sets the value of the postalCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPostalCode(String value) {
        this.postalCode = value;
    }

    /**
     * Gets the value of the postalCountry property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPostalCountry() {
        return postalCountry;
    }

    /**
     * Sets the value of the postalCountry property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPostalCountry(String value) {
        this.postalCountry = value;
    }

    /**
     * Gets the value of the phone1 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPhone1() {
        return phone1;
    }

    /**
     * Sets the value of the phone1 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPhone1(String value) {
        this.phone1 = value;
    }

    /**
     * Gets the value of the phone2 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPhone2() {
        return phone2;
    }

    /**
     * Sets the value of the phone2 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPhone2(String value) {
        this.phone2 = value;
    }

    /**
     * Gets the value of the email property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getEmail() {
        return email;
    }

    /**
     * Sets the value of the email property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setEmail(String value) {
        this.email = value;
    }

    /**
     * Gets the value of the website property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getWebsite() {
        return website;
    }

    /**
     * Sets the value of the website property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setWebsite(String value) {
        this.website = value;
    }

    /**
     * Gets the value of the conditions property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getConditions() {
        return conditions;
    }

    /**
     * Sets the value of the conditions property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setConditions(String value) {
        this.conditions = value;
    }

}
