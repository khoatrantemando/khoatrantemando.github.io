
package demo.com.temando.api;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for AvailableQuote complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="AvailableQuote">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;all>
 *         &lt;element name="generated" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}GeneratedType" minOccurs="0"/>
 *         &lt;element name="accepted" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}YesNoOption" minOccurs="0"/>
 *         &lt;element name="bookingNumber" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}BookingNumber" minOccurs="0"/>
 *         &lt;element name="consignmentNumber" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}ConsignmentNumber" minOccurs="0"/>
 *         &lt;element name="consignmentDocument" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}ConsignmentDocument" minOccurs="0"/>
 *         &lt;element name="consignmentDocumentType" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}ConsignmentDocumentType" minOccurs="0"/>
 *         &lt;element name="labelDocument" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}LabelDocument" minOccurs="0"/>
 *         &lt;element name="labelDocumentType" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}LabelDocumentType" minOccurs="0"/>
 *         &lt;element name="commercialInvoiceDocument" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}CommercialInvoiceDocument" minOccurs="0"/>
 *         &lt;element name="commercialInvoiceDocumentType" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}CommercialInvoiceDocumentType" minOccurs="0"/>
 *         &lt;element name="manifestNumber" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}ManifestNumber" minOccurs="0"/>
 *         &lt;element name="articles" minOccurs="0">
 *           &lt;complexType>
 *             &lt;complexContent>
 *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                 &lt;sequence>
 *                   &lt;element name="article" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}Article" maxOccurs="unbounded" minOccurs="0"/>
 *                 &lt;/sequence>
 *               &lt;/restriction>
 *             &lt;/complexContent>
 *           &lt;/complexType>
 *         &lt;/element>
 *         &lt;element name="trackingStatus" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}TrackingStatus" minOccurs="0"/>
 *         &lt;element name="trackingStatusOccurred" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}Datetime" minOccurs="0"/>
 *         &lt;element name="trackingLastChecked" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}Datetime" minOccurs="0"/>
 *         &lt;element name="trackingFurtherDetails" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}TrackingFurtherDetails" minOccurs="0"/>
 *         &lt;element name="trackingDocument" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}TrackingDocument" minOccurs="0"/>
 *         &lt;element name="trackingDocumentType" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}TrackingDocumentType" minOccurs="0"/>
 *         &lt;element name="trackingHistories" minOccurs="0">
 *           &lt;complexType>
 *             &lt;complexContent>
 *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                 &lt;sequence>
 *                   &lt;element name="trackingHistory" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}TrackingHistory" maxOccurs="unbounded" minOccurs="0"/>
 *                 &lt;/sequence>
 *               &lt;/restriction>
 *             &lt;/complexContent>
 *           &lt;/complexType>
 *         &lt;/element>
 *         &lt;element name="totalPrice" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}CurrencyAmount" minOccurs="0"/>
 *         &lt;element name="basePrice" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}CurrencyAmount" minOccurs="0"/>
 *         &lt;element name="tax" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}CurrencyAmount" minOccurs="0"/>
 *         &lt;element name="currency" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}CurrencyType" minOccurs="0"/>
 *         &lt;element name="deliveryMethod" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}DeliveryMethod" minOccurs="0"/>
 *         &lt;element name="usingGeneralRail" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}YesNoOption" minOccurs="0"/>
 *         &lt;element name="usingGeneralRoad" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}YesNoOption" minOccurs="0"/>
 *         &lt;element name="usingGeneralSea" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}YesNoOption" minOccurs="0"/>
 *         &lt;element name="usingExpressAir" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}YesNoOption" minOccurs="0"/>
 *         &lt;element name="usingExpressRoad" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}YesNoOption" minOccurs="0"/>
 *         &lt;element name="etaFrom" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}Eta" minOccurs="0"/>
 *         &lt;element name="etaTo" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}Eta" minOccurs="0"/>
 *         &lt;element name="guaranteedEta" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}YesNoOption" minOccurs="0"/>
 *         &lt;element name="adjustments" minOccurs="0">
 *           &lt;complexType>
 *             &lt;complexContent>
 *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                 &lt;sequence>
 *                   &lt;element name="adjustment" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}Adjustment" maxOccurs="unbounded" minOccurs="0"/>
 *                 &lt;/sequence>
 *               &lt;/restriction>
 *             &lt;/complexContent>
 *           &lt;/complexType>
 *         &lt;/element>
 *         &lt;element name="inclusions" minOccurs="0">
 *           &lt;complexType>
 *             &lt;complexContent>
 *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                 &lt;sequence>
 *                   &lt;element name="inclusion" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}Inclusion" maxOccurs="unbounded" minOccurs="0"/>
 *                 &lt;/sequence>
 *               &lt;/restriction>
 *             &lt;/complexContent>
 *           &lt;/complexType>
 *         &lt;/element>
 *         &lt;element name="extras" minOccurs="0">
 *           &lt;complexType>
 *             &lt;complexContent>
 *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                 &lt;sequence>
 *                   &lt;element name="extra" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}Extra" maxOccurs="unbounded" minOccurs="0"/>
 *                 &lt;/sequence>
 *               &lt;/restriction>
 *             &lt;/complexContent>
 *           &lt;/complexType>
 *         &lt;/element>
 *         &lt;element name="carrier" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}Carrier" minOccurs="0"/>
 *         &lt;element name="originatingDepot" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}Depot" minOccurs="0"/>
 *         &lt;element name="destinationDepot" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}Depot" minOccurs="0"/>
 *       &lt;/all>
 *       &lt;attribute name="id" type="{http://www.w3.org/2001/XMLSchema}positiveInteger" />
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "AvailableQuote", namespace = "http://api-demo.temando.com/schema/2009_06/common.xsd", propOrder = {

})
public class AvailableQuote {

    protected GeneratedType generated;
    protected YesNoOption accepted;
    protected String bookingNumber;
    protected String consignmentNumber;
    protected String consignmentDocument;
    protected ConsignmentDocumentType consignmentDocumentType;
    protected String labelDocument;
    protected LabelDocumentType labelDocumentType;
    protected String commercialInvoiceDocument;
    protected CommercialInvoiceDocumentType commercialInvoiceDocumentType;
    protected String manifestNumber;
    protected AvailableQuote.Articles articles;
    protected TrackingStatus trackingStatus;
    protected String trackingStatusOccurred;
    protected String trackingLastChecked;
    protected String trackingFurtherDetails;
    protected String trackingDocument;
    protected TrackingDocumentType trackingDocumentType;
    protected AvailableQuote.TrackingHistories trackingHistories;
    protected BigDecimal totalPrice;
    protected BigDecimal basePrice;
    protected BigDecimal tax;
    protected CurrencyType currency;
    protected String deliveryMethod;
    protected YesNoOption usingGeneralRail;
    protected YesNoOption usingGeneralRoad;
    protected YesNoOption usingGeneralSea;
    protected YesNoOption usingExpressAir;
    protected YesNoOption usingExpressRoad;
    protected Integer etaFrom;
    protected Integer etaTo;
    protected YesNoOption guaranteedEta;
    protected AvailableQuote.Adjustments adjustments;
    protected AvailableQuote.Inclusions inclusions;
    protected AvailableQuote.Extras extras;
    protected Carrier carrier;
    protected Depot originatingDepot;
    protected Depot destinationDepot;
    @XmlAttribute(name = "id")
    @XmlSchemaType(name = "positiveInteger")
    protected BigInteger id;

    /**
     * Gets the value of the generated property.
     * 
     * @return
     *     possible object is
     *     {@link GeneratedType }
     *     
     */
    public GeneratedType getGenerated() {
        return generated;
    }

    /**
     * Sets the value of the generated property.
     * 
     * @param value
     *     allowed object is
     *     {@link GeneratedType }
     *     
     */
    public void setGenerated(GeneratedType value) {
        this.generated = value;
    }

    /**
     * Gets the value of the accepted property.
     * 
     * @return
     *     possible object is
     *     {@link YesNoOption }
     *     
     */
    public YesNoOption getAccepted() {
        return accepted;
    }

    /**
     * Sets the value of the accepted property.
     * 
     * @param value
     *     allowed object is
     *     {@link YesNoOption }
     *     
     */
    public void setAccepted(YesNoOption value) {
        this.accepted = value;
    }

    /**
     * Gets the value of the bookingNumber property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getBookingNumber() {
        return bookingNumber;
    }

    /**
     * Sets the value of the bookingNumber property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setBookingNumber(String value) {
        this.bookingNumber = value;
    }

    /**
     * Gets the value of the consignmentNumber property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getConsignmentNumber() {
        return consignmentNumber;
    }

    /**
     * Sets the value of the consignmentNumber property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setConsignmentNumber(String value) {
        this.consignmentNumber = value;
    }

    /**
     * Gets the value of the consignmentDocument property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getConsignmentDocument() {
        return consignmentDocument;
    }

    /**
     * Sets the value of the consignmentDocument property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setConsignmentDocument(String value) {
        this.consignmentDocument = value;
    }

    /**
     * Gets the value of the consignmentDocumentType property.
     * 
     * @return
     *     possible object is
     *     {@link ConsignmentDocumentType }
     *     
     */
    public ConsignmentDocumentType getConsignmentDocumentType() {
        return consignmentDocumentType;
    }

    /**
     * Sets the value of the consignmentDocumentType property.
     * 
     * @param value
     *     allowed object is
     *     {@link ConsignmentDocumentType }
     *     
     */
    public void setConsignmentDocumentType(ConsignmentDocumentType value) {
        this.consignmentDocumentType = value;
    }

    /**
     * Gets the value of the labelDocument property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLabelDocument() {
        return labelDocument;
    }

    /**
     * Sets the value of the labelDocument property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLabelDocument(String value) {
        this.labelDocument = value;
    }

    /**
     * Gets the value of the labelDocumentType property.
     * 
     * @return
     *     possible object is
     *     {@link LabelDocumentType }
     *     
     */
    public LabelDocumentType getLabelDocumentType() {
        return labelDocumentType;
    }

    /**
     * Sets the value of the labelDocumentType property.
     * 
     * @param value
     *     allowed object is
     *     {@link LabelDocumentType }
     *     
     */
    public void setLabelDocumentType(LabelDocumentType value) {
        this.labelDocumentType = value;
    }

    /**
     * Gets the value of the commercialInvoiceDocument property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCommercialInvoiceDocument() {
        return commercialInvoiceDocument;
    }

    /**
     * Sets the value of the commercialInvoiceDocument property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCommercialInvoiceDocument(String value) {
        this.commercialInvoiceDocument = value;
    }

    /**
     * Gets the value of the commercialInvoiceDocumentType property.
     * 
     * @return
     *     possible object is
     *     {@link CommercialInvoiceDocumentType }
     *     
     */
    public CommercialInvoiceDocumentType getCommercialInvoiceDocumentType() {
        return commercialInvoiceDocumentType;
    }

    /**
     * Sets the value of the commercialInvoiceDocumentType property.
     * 
     * @param value
     *     allowed object is
     *     {@link CommercialInvoiceDocumentType }
     *     
     */
    public void setCommercialInvoiceDocumentType(CommercialInvoiceDocumentType value) {
        this.commercialInvoiceDocumentType = value;
    }

    /**
     * Gets the value of the manifestNumber property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getManifestNumber() {
        return manifestNumber;
    }

    /**
     * Sets the value of the manifestNumber property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setManifestNumber(String value) {
        this.manifestNumber = value;
    }

    /**
     * Gets the value of the articles property.
     * 
     * @return
     *     possible object is
     *     {@link AvailableQuote.Articles }
     *     
     */
    public AvailableQuote.Articles getArticles() {
        return articles;
    }

    /**
     * Sets the value of the articles property.
     * 
     * @param value
     *     allowed object is
     *     {@link AvailableQuote.Articles }
     *     
     */
    public void setArticles(AvailableQuote.Articles value) {
        this.articles = value;
    }

    /**
     * Gets the value of the trackingStatus property.
     * 
     * @return
     *     possible object is
     *     {@link TrackingStatus }
     *     
     */
    public TrackingStatus getTrackingStatus() {
        return trackingStatus;
    }

    /**
     * Sets the value of the trackingStatus property.
     * 
     * @param value
     *     allowed object is
     *     {@link TrackingStatus }
     *     
     */
    public void setTrackingStatus(TrackingStatus value) {
        this.trackingStatus = value;
    }

    /**
     * Gets the value of the trackingStatusOccurred property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTrackingStatusOccurred() {
        return trackingStatusOccurred;
    }

    /**
     * Sets the value of the trackingStatusOccurred property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTrackingStatusOccurred(String value) {
        this.trackingStatusOccurred = value;
    }

    /**
     * Gets the value of the trackingLastChecked property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTrackingLastChecked() {
        return trackingLastChecked;
    }

    /**
     * Sets the value of the trackingLastChecked property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTrackingLastChecked(String value) {
        this.trackingLastChecked = value;
    }

    /**
     * Gets the value of the trackingFurtherDetails property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTrackingFurtherDetails() {
        return trackingFurtherDetails;
    }

    /**
     * Sets the value of the trackingFurtherDetails property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTrackingFurtherDetails(String value) {
        this.trackingFurtherDetails = value;
    }

    /**
     * Gets the value of the trackingDocument property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTrackingDocument() {
        return trackingDocument;
    }

    /**
     * Sets the value of the trackingDocument property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTrackingDocument(String value) {
        this.trackingDocument = value;
    }

    /**
     * Gets the value of the trackingDocumentType property.
     * 
     * @return
     *     possible object is
     *     {@link TrackingDocumentType }
     *     
     */
    public TrackingDocumentType getTrackingDocumentType() {
        return trackingDocumentType;
    }

    /**
     * Sets the value of the trackingDocumentType property.
     * 
     * @param value
     *     allowed object is
     *     {@link TrackingDocumentType }
     *     
     */
    public void setTrackingDocumentType(TrackingDocumentType value) {
        this.trackingDocumentType = value;
    }

    /**
     * Gets the value of the trackingHistories property.
     * 
     * @return
     *     possible object is
     *     {@link AvailableQuote.TrackingHistories }
     *     
     */
    public AvailableQuote.TrackingHistories getTrackingHistories() {
        return trackingHistories;
    }

    /**
     * Sets the value of the trackingHistories property.
     * 
     * @param value
     *     allowed object is
     *     {@link AvailableQuote.TrackingHistories }
     *     
     */
    public void setTrackingHistories(AvailableQuote.TrackingHistories value) {
        this.trackingHistories = value;
    }

    /**
     * Gets the value of the totalPrice property.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getTotalPrice() {
        return totalPrice;
    }

    /**
     * Sets the value of the totalPrice property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setTotalPrice(BigDecimal value) {
        this.totalPrice = value;
    }

    /**
     * Gets the value of the basePrice property.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getBasePrice() {
        return basePrice;
    }

    /**
     * Sets the value of the basePrice property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setBasePrice(BigDecimal value) {
        this.basePrice = value;
    }

    /**
     * Gets the value of the tax property.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getTax() {
        return tax;
    }

    /**
     * Sets the value of the tax property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setTax(BigDecimal value) {
        this.tax = value;
    }

    /**
     * Gets the value of the currency property.
     * 
     * @return
     *     possible object is
     *     {@link CurrencyType }
     *     
     */
    public CurrencyType getCurrency() {
        return currency;
    }

    /**
     * Sets the value of the currency property.
     * 
     * @param value
     *     allowed object is
     *     {@link CurrencyType }
     *     
     */
    public void setCurrency(CurrencyType value) {
        this.currency = value;
    }

    /**
     * Gets the value of the deliveryMethod property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDeliveryMethod() {
        return deliveryMethod;
    }

    /**
     * Sets the value of the deliveryMethod property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDeliveryMethod(String value) {
        this.deliveryMethod = value;
    }

    /**
     * Gets the value of the usingGeneralRail property.
     * 
     * @return
     *     possible object is
     *     {@link YesNoOption }
     *     
     */
    public YesNoOption getUsingGeneralRail() {
        return usingGeneralRail;
    }

    /**
     * Sets the value of the usingGeneralRail property.
     * 
     * @param value
     *     allowed object is
     *     {@link YesNoOption }
     *     
     */
    public void setUsingGeneralRail(YesNoOption value) {
        this.usingGeneralRail = value;
    }

    /**
     * Gets the value of the usingGeneralRoad property.
     * 
     * @return
     *     possible object is
     *     {@link YesNoOption }
     *     
     */
    public YesNoOption getUsingGeneralRoad() {
        return usingGeneralRoad;
    }

    /**
     * Sets the value of the usingGeneralRoad property.
     * 
     * @param value
     *     allowed object is
     *     {@link YesNoOption }
     *     
     */
    public void setUsingGeneralRoad(YesNoOption value) {
        this.usingGeneralRoad = value;
    }

    /**
     * Gets the value of the usingGeneralSea property.
     * 
     * @return
     *     possible object is
     *     {@link YesNoOption }
     *     
     */
    public YesNoOption getUsingGeneralSea() {
        return usingGeneralSea;
    }

    /**
     * Sets the value of the usingGeneralSea property.
     * 
     * @param value
     *     allowed object is
     *     {@link YesNoOption }
     *     
     */
    public void setUsingGeneralSea(YesNoOption value) {
        this.usingGeneralSea = value;
    }

    /**
     * Gets the value of the usingExpressAir property.
     * 
     * @return
     *     possible object is
     *     {@link YesNoOption }
     *     
     */
    public YesNoOption getUsingExpressAir() {
        return usingExpressAir;
    }

    /**
     * Sets the value of the usingExpressAir property.
     * 
     * @param value
     *     allowed object is
     *     {@link YesNoOption }
     *     
     */
    public void setUsingExpressAir(YesNoOption value) {
        this.usingExpressAir = value;
    }

    /**
     * Gets the value of the usingExpressRoad property.
     * 
     * @return
     *     possible object is
     *     {@link YesNoOption }
     *     
     */
    public YesNoOption getUsingExpressRoad() {
        return usingExpressRoad;
    }

    /**
     * Sets the value of the usingExpressRoad property.
     * 
     * @param value
     *     allowed object is
     *     {@link YesNoOption }
     *     
     */
    public void setUsingExpressRoad(YesNoOption value) {
        this.usingExpressRoad = value;
    }

    /**
     * Gets the value of the etaFrom property.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getEtaFrom() {
        return etaFrom;
    }

    /**
     * Sets the value of the etaFrom property.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setEtaFrom(Integer value) {
        this.etaFrom = value;
    }

    /**
     * Gets the value of the etaTo property.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getEtaTo() {
        return etaTo;
    }

    /**
     * Sets the value of the etaTo property.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setEtaTo(Integer value) {
        this.etaTo = value;
    }

    /**
     * Gets the value of the guaranteedEta property.
     * 
     * @return
     *     possible object is
     *     {@link YesNoOption }
     *     
     */
    public YesNoOption getGuaranteedEta() {
        return guaranteedEta;
    }

    /**
     * Sets the value of the guaranteedEta property.
     * 
     * @param value
     *     allowed object is
     *     {@link YesNoOption }
     *     
     */
    public void setGuaranteedEta(YesNoOption value) {
        this.guaranteedEta = value;
    }

    /**
     * Gets the value of the adjustments property.
     * 
     * @return
     *     possible object is
     *     {@link AvailableQuote.Adjustments }
     *     
     */
    public AvailableQuote.Adjustments getAdjustments() {
        return adjustments;
    }

    /**
     * Sets the value of the adjustments property.
     * 
     * @param value
     *     allowed object is
     *     {@link AvailableQuote.Adjustments }
     *     
     */
    public void setAdjustments(AvailableQuote.Adjustments value) {
        this.adjustments = value;
    }

    /**
     * Gets the value of the inclusions property.
     * 
     * @return
     *     possible object is
     *     {@link AvailableQuote.Inclusions }
     *     
     */
    public AvailableQuote.Inclusions getInclusions() {
        return inclusions;
    }

    /**
     * Sets the value of the inclusions property.
     * 
     * @param value
     *     allowed object is
     *     {@link AvailableQuote.Inclusions }
     *     
     */
    public void setInclusions(AvailableQuote.Inclusions value) {
        this.inclusions = value;
    }

    /**
     * Gets the value of the extras property.
     * 
     * @return
     *     possible object is
     *     {@link AvailableQuote.Extras }
     *     
     */
    public AvailableQuote.Extras getExtras() {
        return extras;
    }

    /**
     * Sets the value of the extras property.
     * 
     * @param value
     *     allowed object is
     *     {@link AvailableQuote.Extras }
     *     
     */
    public void setExtras(AvailableQuote.Extras value) {
        this.extras = value;
    }

    /**
     * Gets the value of the carrier property.
     * 
     * @return
     *     possible object is
     *     {@link Carrier }
     *     
     */
    public Carrier getCarrier() {
        return carrier;
    }

    /**
     * Sets the value of the carrier property.
     * 
     * @param value
     *     allowed object is
     *     {@link Carrier }
     *     
     */
    public void setCarrier(Carrier value) {
        this.carrier = value;
    }

    /**
     * Gets the value of the originatingDepot property.
     * 
     * @return
     *     possible object is
     *     {@link Depot }
     *     
     */
    public Depot getOriginatingDepot() {
        return originatingDepot;
    }

    /**
     * Sets the value of the originatingDepot property.
     * 
     * @param value
     *     allowed object is
     *     {@link Depot }
     *     
     */
    public void setOriginatingDepot(Depot value) {
        this.originatingDepot = value;
    }

    /**
     * Gets the value of the destinationDepot property.
     * 
     * @return
     *     possible object is
     *     {@link Depot }
     *     
     */
    public Depot getDestinationDepot() {
        return destinationDepot;
    }

    /**
     * Sets the value of the destinationDepot property.
     * 
     * @param value
     *     allowed object is
     *     {@link Depot }
     *     
     */
    public void setDestinationDepot(Depot value) {
        this.destinationDepot = value;
    }

    /**
     * Gets the value of the id property.
     * 
     * @return
     *     possible object is
     *     {@link BigInteger }
     *     
     */
    public BigInteger getId() {
        return id;
    }

    /**
     * Sets the value of the id property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigInteger }
     *     
     */
    public void setId(BigInteger value) {
        this.id = value;
    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType>
     *   &lt;complexContent>
     *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
     *       &lt;sequence>
     *         &lt;element name="adjustment" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}Adjustment" maxOccurs="unbounded" minOccurs="0"/>
     *       &lt;/sequence>
     *     &lt;/restriction>
     *   &lt;/complexContent>
     * &lt;/complexType>
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "adjustment"
    })
    public static class Adjustments {

        protected List<Adjustment> adjustment;

        /**
         * Gets the value of the adjustment property.
         * 
         * <p>
         * This accessor method returns a reference to the live list,
         * not a snapshot. Therefore any modification you make to the
         * returned list will be present inside the JAXB object.
         * This is why there is not a <CODE>set</CODE> method for the adjustment property.
         * 
         * <p>
         * For example, to add a new item, do as follows:
         * <pre>
         *    getAdjustment().add(newItem);
         * </pre>
         * 
         * 
         * <p>
         * Objects of the following type(s) are allowed in the list
         * {@link Adjustment }
         * 
         * 
         */
        public List<Adjustment> getAdjustment() {
            if (adjustment == null) {
                adjustment = new ArrayList<Adjustment>();
            }
            return this.adjustment;
        }

    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType>
     *   &lt;complexContent>
     *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
     *       &lt;sequence>
     *         &lt;element name="article" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}Article" maxOccurs="unbounded" minOccurs="0"/>
     *       &lt;/sequence>
     *     &lt;/restriction>
     *   &lt;/complexContent>
     * &lt;/complexType>
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "article"
    })
    public static class Articles {

        protected List<Article> article;

        /**
         * Gets the value of the article property.
         * 
         * <p>
         * This accessor method returns a reference to the live list,
         * not a snapshot. Therefore any modification you make to the
         * returned list will be present inside the JAXB object.
         * This is why there is not a <CODE>set</CODE> method for the article property.
         * 
         * <p>
         * For example, to add a new item, do as follows:
         * <pre>
         *    getArticle().add(newItem);
         * </pre>
         * 
         * 
         * <p>
         * Objects of the following type(s) are allowed in the list
         * {@link Article }
         * 
         * 
         */
        public List<Article> getArticle() {
            if (article == null) {
                article = new ArrayList<Article>();
            }
            return this.article;
        }

    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType>
     *   &lt;complexContent>
     *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
     *       &lt;sequence>
     *         &lt;element name="extra" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}Extra" maxOccurs="unbounded" minOccurs="0"/>
     *       &lt;/sequence>
     *     &lt;/restriction>
     *   &lt;/complexContent>
     * &lt;/complexType>
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "extra"
    })
    public static class Extras {

        protected List<Extra> extra;

        /**
         * Gets the value of the extra property.
         * 
         * <p>
         * This accessor method returns a reference to the live list,
         * not a snapshot. Therefore any modification you make to the
         * returned list will be present inside the JAXB object.
         * This is why there is not a <CODE>set</CODE> method for the extra property.
         * 
         * <p>
         * For example, to add a new item, do as follows:
         * <pre>
         *    getExtra().add(newItem);
         * </pre>
         * 
         * 
         * <p>
         * Objects of the following type(s) are allowed in the list
         * {@link Extra }
         * 
         * 
         */
        public List<Extra> getExtra() {
            if (extra == null) {
                extra = new ArrayList<Extra>();
            }
            return this.extra;
        }

    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType>
     *   &lt;complexContent>
     *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
     *       &lt;sequence>
     *         &lt;element name="inclusion" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}Inclusion" maxOccurs="unbounded" minOccurs="0"/>
     *       &lt;/sequence>
     *     &lt;/restriction>
     *   &lt;/complexContent>
     * &lt;/complexType>
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "inclusion"
    })
    public static class Inclusions {

        protected List<Inclusion> inclusion;

        /**
         * Gets the value of the inclusion property.
         * 
         * <p>
         * This accessor method returns a reference to the live list,
         * not a snapshot. Therefore any modification you make to the
         * returned list will be present inside the JAXB object.
         * This is why there is not a <CODE>set</CODE> method for the inclusion property.
         * 
         * <p>
         * For example, to add a new item, do as follows:
         * <pre>
         *    getInclusion().add(newItem);
         * </pre>
         * 
         * 
         * <p>
         * Objects of the following type(s) are allowed in the list
         * {@link Inclusion }
         * 
         * 
         */
        public List<Inclusion> getInclusion() {
            if (inclusion == null) {
                inclusion = new ArrayList<Inclusion>();
            }
            return this.inclusion;
        }

    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType>
     *   &lt;complexContent>
     *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
     *       &lt;sequence>
     *         &lt;element name="trackingHistory" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}TrackingHistory" maxOccurs="unbounded" minOccurs="0"/>
     *       &lt;/sequence>
     *     &lt;/restriction>
     *   &lt;/complexContent>
     * &lt;/complexType>
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "trackingHistory"
    })
    public static class TrackingHistories {

        protected List<TrackingHistory> trackingHistory;

        /**
         * Gets the value of the trackingHistory property.
         * 
         * <p>
         * This accessor method returns a reference to the live list,
         * not a snapshot. Therefore any modification you make to the
         * returned list will be present inside the JAXB object.
         * This is why there is not a <CODE>set</CODE> method for the trackingHistory property.
         * 
         * <p>
         * For example, to add a new item, do as follows:
         * <pre>
         *    getTrackingHistory().add(newItem);
         * </pre>
         * 
         * 
         * <p>
         * Objects of the following type(s) are allowed in the list
         * {@link TrackingHistory }
         * 
         * 
         */
        public List<TrackingHistory> getTrackingHistory() {
            if (trackingHistory == null) {
                trackingHistory = new ArrayList<TrackingHistory>();
            }
            return this.trackingHistory;
        }

    }

}
