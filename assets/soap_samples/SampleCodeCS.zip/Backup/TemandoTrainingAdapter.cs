﻿using System.ServiceModel;
using TemandoSample.TemandoTrainingService;

namespace TemandoSample
{
    public class TemandoTrainingAdapter : TemandoAdapter {
        public TemandoTrainingAdapter(string endpointAddress, string userName, string password)
            : base(endpointAddress, userName, password) {
            var binding = new BasicHttpBinding();
            var remoteAddress = new EndpointAddress(_endpointAddress);
            Client = new quoting_portTypeClient(binding, remoteAddress);
            if (Client.Endpoint.Behaviors.Count == 1) {
                var behavior = new TemandoEndpointBehavior {UserName = _userName, Password = _password};
                Client.Endpoint.Behaviors[0] = behavior;
            }
        }

        public quoting_portTypeClient Client { get; set; }
    }
}