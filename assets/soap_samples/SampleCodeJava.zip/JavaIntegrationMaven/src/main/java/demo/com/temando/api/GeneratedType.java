
package demo.com.temando.api;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for GeneratedType.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * <p>
 * <pre>
 * &lt;simpleType name="GeneratedType">
 *   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *     &lt;enumeration value="Manually"/>
 *     &lt;enumeration value="Automatically"/>
 *   &lt;/restriction>
 * &lt;/simpleType>
 * </pre>
 * 
 */
@XmlType(name = "GeneratedType", namespace = "http://api-demo.temando.com/schema/2009_06/common.xsd")
@XmlEnum
public enum GeneratedType {

    @XmlEnumValue("Manually")
    MANUALLY("Manually"),
    @XmlEnumValue("Automatically")
    AUTOMATICALLY("Automatically");
    private final String value;

    GeneratedType(String v) {
        value = v;
    }

    public String value() {
        return value;
    }

    public static GeneratedType fromValue(String v) {
        for (GeneratedType c: GeneratedType.values()) {
            if (c.value.equals(v)) {
                return c;
            }
        }
        throw new IllegalArgumentException(v);
    }

}
