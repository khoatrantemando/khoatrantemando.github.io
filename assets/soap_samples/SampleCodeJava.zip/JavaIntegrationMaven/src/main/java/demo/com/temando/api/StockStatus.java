
package demo.com.temando.api;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for StockStatus.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * <p>
 * <pre>
 * &lt;simpleType name="StockStatus">
 *   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *     &lt;enumeration value="IN_STOCK"/>
 *     &lt;enumeration value="LIMITED"/>
 *     &lt;enumeration value="OUT_OF_STOCK"/>
 *     &lt;enumeration value="NEVER"/>
 *     &lt;enumeration value="CALL"/>
 *   &lt;/restriction>
 * &lt;/simpleType>
 * </pre>
 * 
 */
@XmlType(name = "StockStatus", namespace = "http://api-demo.temando.com/schema/2009_06/common.xsd")
@XmlEnum
public enum StockStatus {

    IN_STOCK,
    LIMITED,
    OUT_OF_STOCK,
    NEVER,
    CALL;

    public String value() {
        return name();
    }

    public static StockStatus fromValue(String v) {
        return valueOf(v);
    }

}
