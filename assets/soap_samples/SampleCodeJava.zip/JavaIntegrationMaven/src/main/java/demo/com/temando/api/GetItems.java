
package demo.com.temando.api;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for anonymous complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType>
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;all>
 *         &lt;element name="clientId" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}ClientId" minOccurs="0"/>
 *         &lt;element name="description" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}ItemDescription" minOccurs="0"/>
 *         &lt;element name="sku" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}SKU" minOccurs="0"/>
 *         &lt;element name="sscc" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}SSCC" minOccurs="0"/>
 *         &lt;element name="hs" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}HS" minOccurs="0"/>
 *         &lt;element name="upc" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}UPC" minOccurs="0"/>
 *         &lt;element name="ean" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}EAN" minOccurs="0"/>
 *         &lt;element name="isbn" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}ISBN" minOccurs="0"/>
 *         &lt;element name="asin" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}ASIN" minOccurs="0"/>
 *         &lt;element name="mpn" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}MPN" minOccurs="0"/>
 *         &lt;element name="originDescription" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}LocationName" minOccurs="0"/>
 *       &lt;/all>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {

})
@XmlRootElement(name = "getItems")
public class GetItems {

    protected Integer clientId;
    protected String description;
    protected String sku;
    protected String sscc;
    protected String hs;
    protected String upc;
    protected String ean;
    protected String isbn;
    protected String asin;
    protected String mpn;
    protected String originDescription;

    /**
     * Gets the value of the clientId property.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getClientId() {
        return clientId;
    }

    /**
     * Sets the value of the clientId property.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setClientId(Integer value) {
        this.clientId = value;
    }

    /**
     * Gets the value of the description property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDescription() {
        return description;
    }

    /**
     * Sets the value of the description property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDescription(String value) {
        this.description = value;
    }

    /**
     * Gets the value of the sku property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSku() {
        return sku;
    }

    /**
     * Sets the value of the sku property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSku(String value) {
        this.sku = value;
    }

    /**
     * Gets the value of the sscc property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSscc() {
        return sscc;
    }

    /**
     * Sets the value of the sscc property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSscc(String value) {
        this.sscc = value;
    }

    /**
     * Gets the value of the hs property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getHs() {
        return hs;
    }

    /**
     * Sets the value of the hs property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setHs(String value) {
        this.hs = value;
    }

    /**
     * Gets the value of the upc property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getUpc() {
        return upc;
    }

    /**
     * Sets the value of the upc property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setUpc(String value) {
        this.upc = value;
    }

    /**
     * Gets the value of the ean property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getEan() {
        return ean;
    }

    /**
     * Sets the value of the ean property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setEan(String value) {
        this.ean = value;
    }

    /**
     * Gets the value of the isbn property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getIsbn() {
        return isbn;
    }

    /**
     * Sets the value of the isbn property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setIsbn(String value) {
        this.isbn = value;
    }

    /**
     * Gets the value of the asin property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAsin() {
        return asin;
    }

    /**
     * Sets the value of the asin property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAsin(String value) {
        this.asin = value;
    }

    /**
     * Gets the value of the mpn property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMpn() {
        return mpn;
    }

    /**
     * Sets the value of the mpn property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMpn(String value) {
        this.mpn = value;
    }

    /**
     * Gets the value of the originDescription property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getOriginDescription() {
        return originDescription;
    }

    /**
     * Sets the value of the originDescription property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setOriginDescription(String value) {
        this.originDescription = value;
    }

}
