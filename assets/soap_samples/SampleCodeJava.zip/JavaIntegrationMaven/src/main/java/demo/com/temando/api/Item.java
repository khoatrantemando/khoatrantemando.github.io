
package demo.com.temando.api;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for Item complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="Item">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;all>
 *         &lt;element name="description" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}ItemDescription" minOccurs="0"/>
 *         &lt;element name="class" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}Class" minOccurs="0"/>
 *         &lt;element name="subclass" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}Subclass" minOccurs="0"/>
 *         &lt;element name="mode" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}Mode" minOccurs="0"/>
 *         &lt;element name="tlSubclass" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}TlSubclass" minOccurs="0"/>
 *         &lt;element name="packaging" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}Packaging" minOccurs="0"/>
 *         &lt;element name="palletType" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}PalletType" minOccurs="0"/>
 *         &lt;element name="palletNature" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}PalletNature" minOccurs="0"/>
 *         &lt;element name="containerDimensions" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}ContainerDimensions" minOccurs="0"/>
 *         &lt;element name="containerNature" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}ContainerNature" minOccurs="0"/>
 *         &lt;element name="containerRegistered" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}YesNoOption" minOccurs="0"/>
 *         &lt;element name="qualifierFreightGeneralDangerousGoods" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}YesNoOption" minOccurs="0"/>
 *         &lt;element name="qualifierFreightGeneralFragile" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}YesNoOption" minOccurs="0"/>
 *         &lt;element name="qualifierFreightGeneralRefrigerated" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}YesNoOption" minOccurs="0"/>
 *         &lt;element name="qualifierVehicleMake" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}VehicleMake" minOccurs="0"/>
 *         &lt;element name="qualifierVehicleModel" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}VehicleModel" minOccurs="0"/>
 *         &lt;element name="qualifierVehicleDescription" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}VehicleDescription" minOccurs="0"/>
 *         &lt;element name="qualifierVehicleRunning" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}YesNoOption" minOccurs="0"/>
 *         &lt;element name="qualifierVehicleRegistered" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}YesNoOption" minOccurs="0"/>
 *         &lt;element name="qualifierVehicleYear" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}VehicleYear" minOccurs="0"/>
 *         &lt;element name="qualifierVehicleRegistration" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}VehicleRegistration" minOccurs="0"/>
 *         &lt;element name="qualifierBoatMake" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}BoatMake" minOccurs="0"/>
 *         &lt;element name="qualifierBoatModel" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}BoatModel" minOccurs="0"/>
 *         &lt;element name="qualifierBoatSeaworthy" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}YesNoOption" minOccurs="0"/>
 *         &lt;element name="qualifierBoatTrailer" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}YesNoOption" minOccurs="0"/>
 *         &lt;element name="qualifierBoatHullType" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}BoatHullType" minOccurs="0"/>
 *         &lt;element name="qualifierLivestockType" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}LivestockType" minOccurs="0"/>
 *         &lt;element name="qualifierAnimalVaccinated" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}YesNoOption" minOccurs="0"/>
 *         &lt;element name="qualifierAnimalRegistered" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}YesNoOption" minOccurs="0"/>
 *         &lt;element name="qualifierAnimalType" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}AnimalType" minOccurs="0"/>
 *         &lt;element name="qualifierAnimalBreed" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}AnimalBreed" minOccurs="0"/>
 *         &lt;element name="qualifierAnimalSex" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}Sex" minOccurs="0"/>
 *         &lt;element name="qualifierAnimalAge" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}AnimalAge" minOccurs="0"/>
 *         &lt;element name="qualifierAnimalCrate" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}AnimalCrate" minOccurs="0"/>
 *         &lt;element name="distanceMeasurementType" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}DistanceMeasurementType" minOccurs="0"/>
 *         &lt;element name="weightMeasurementType" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}WeightMeasurementType" minOccurs="0"/>
 *         &lt;element name="length" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}Length" minOccurs="0"/>
 *         &lt;element name="width" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}Width" minOccurs="0"/>
 *         &lt;element name="height" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}Height" minOccurs="0"/>
 *         &lt;element name="weight" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}Weight" minOccurs="0"/>
 *         &lt;element name="sku" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}SKU" minOccurs="0"/>
 *         &lt;element name="sscc" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}SSCC" minOccurs="0"/>
 *         &lt;element name="hs" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}HS" minOccurs="0"/>
 *         &lt;element name="upc" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}UPC" minOccurs="0"/>
 *         &lt;element name="ean" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}EAN" minOccurs="0"/>
 *         &lt;element name="isbn" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}ISBN" minOccurs="0"/>
 *         &lt;element name="asin" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}ASIN" minOccurs="0"/>
 *         &lt;element name="mpn" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}MPN" minOccurs="0"/>
 *         &lt;element name="goodsPrice" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}CurrencyAmount" minOccurs="0"/>
 *         &lt;element name="listPrice" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}CurrencyAmount" minOccurs="0"/>
 *         &lt;element name="salePrice" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}CurrencyAmount" minOccurs="0"/>
 *         &lt;element name="modelNumber" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}ModelNumber" minOccurs="0"/>
 *         &lt;element name="styleNumber" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}StyleNumber" minOccurs="0"/>
 *         &lt;element name="locationSelection" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}LocationSelection" minOccurs="0"/>
 *         &lt;element name="itemStocks" minOccurs="0">
 *           &lt;complexType>
 *             &lt;complexContent>
 *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                 &lt;sequence>
 *                   &lt;element name="itemStock" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}ItemStock" maxOccurs="50"/>
 *                 &lt;/sequence>
 *               &lt;/restriction>
 *             &lt;/complexContent>
 *           &lt;/complexType>
 *         &lt;/element>
 *       &lt;/all>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "Item", namespace = "http://api-demo.temando.com/schema/2009_06/common.xsd", propOrder = {

})
public class Item {

    protected String description;
    @XmlElement(name = "class")
    protected Class clazz;
    protected String subclass;
    protected Mode mode;
    protected Integer tlSubclass;
    protected Packaging packaging;
    protected PalletType palletType;
    protected PalletNature palletNature;
    protected String containerDimensions;
    protected ContainerNature containerNature;
    protected YesNoOption containerRegistered;
    protected YesNoOption qualifierFreightGeneralDangerousGoods;
    protected YesNoOption qualifierFreightGeneralFragile;
    protected YesNoOption qualifierFreightGeneralRefrigerated;
    protected String qualifierVehicleMake;
    protected String qualifierVehicleModel;
    protected String qualifierVehicleDescription;
    protected YesNoOption qualifierVehicleRunning;
    protected YesNoOption qualifierVehicleRegistered;
    protected Integer qualifierVehicleYear;
    protected String qualifierVehicleRegistration;
    protected String qualifierBoatMake;
    protected String qualifierBoatModel;
    protected YesNoOption qualifierBoatSeaworthy;
    protected YesNoOption qualifierBoatTrailer;
    protected String qualifierBoatHullType;
    protected LivestockType qualifierLivestockType;
    protected YesNoOption qualifierAnimalVaccinated;
    protected YesNoOption qualifierAnimalRegistered;
    protected String qualifierAnimalType;
    protected String qualifierAnimalBreed;
    protected Sex qualifierAnimalSex;
    protected Integer qualifierAnimalAge;
    protected AnimalCrate qualifierAnimalCrate;
    protected DistanceMeasurementType distanceMeasurementType;
    protected WeightMeasurementType weightMeasurementType;
    protected Integer length;
    protected Integer width;
    protected Integer height;
    protected Integer weight;
    protected String sku;
    protected String sscc;
    protected String hs;
    protected String upc;
    protected String ean;
    protected String isbn;
    protected String asin;
    protected String mpn;
    protected BigDecimal goodsPrice;
    protected BigDecimal listPrice;
    protected BigDecimal salePrice;
    protected String modelNumber;
    protected String styleNumber;
    protected LocationSelection locationSelection;
    protected Item.ItemStocks itemStocks;

    /**
     * Gets the value of the description property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDescription() {
        return description;
    }

    /**
     * Sets the value of the description property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDescription(String value) {
        this.description = value;
    }

    /**
     * Gets the value of the clazz property.
     * 
     * @return
     *     possible object is
     *     {@link Class }
     *     
     */
    public Class getClazz() {
        return clazz;
    }

    /**
     * Sets the value of the clazz property.
     * 
     * @param value
     *     allowed object is
     *     {@link Class }
     *     
     */
    public void setClazz(Class value) {
        this.clazz = value;
    }

    /**
     * Gets the value of the subclass property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSubclass() {
        return subclass;
    }

    /**
     * Sets the value of the subclass property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSubclass(String value) {
        this.subclass = value;
    }

    /**
     * Gets the value of the mode property.
     * 
     * @return
     *     possible object is
     *     {@link Mode }
     *     
     */
    public Mode getMode() {
        return mode;
    }

    /**
     * Sets the value of the mode property.
     * 
     * @param value
     *     allowed object is
     *     {@link Mode }
     *     
     */
    public void setMode(Mode value) {
        this.mode = value;
    }

    /**
     * Gets the value of the tlSubclass property.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getTlSubclass() {
        return tlSubclass;
    }

    /**
     * Sets the value of the tlSubclass property.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setTlSubclass(Integer value) {
        this.tlSubclass = value;
    }

    /**
     * Gets the value of the packaging property.
     * 
     * @return
     *     possible object is
     *     {@link Packaging }
     *     
     */
    public Packaging getPackaging() {
        return packaging;
    }

    /**
     * Sets the value of the packaging property.
     * 
     * @param value
     *     allowed object is
     *     {@link Packaging }
     *     
     */
    public void setPackaging(Packaging value) {
        this.packaging = value;
    }

    /**
     * Gets the value of the palletType property.
     * 
     * @return
     *     possible object is
     *     {@link PalletType }
     *     
     */
    public PalletType getPalletType() {
        return palletType;
    }

    /**
     * Sets the value of the palletType property.
     * 
     * @param value
     *     allowed object is
     *     {@link PalletType }
     *     
     */
    public void setPalletType(PalletType value) {
        this.palletType = value;
    }

    /**
     * Gets the value of the palletNature property.
     * 
     * @return
     *     possible object is
     *     {@link PalletNature }
     *     
     */
    public PalletNature getPalletNature() {
        return palletNature;
    }

    /**
     * Sets the value of the palletNature property.
     * 
     * @param value
     *     allowed object is
     *     {@link PalletNature }
     *     
     */
    public void setPalletNature(PalletNature value) {
        this.palletNature = value;
    }

    /**
     * Gets the value of the containerDimensions property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getContainerDimensions() {
        return containerDimensions;
    }

    /**
     * Sets the value of the containerDimensions property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setContainerDimensions(String value) {
        this.containerDimensions = value;
    }

    /**
     * Gets the value of the containerNature property.
     * 
     * @return
     *     possible object is
     *     {@link ContainerNature }
     *     
     */
    public ContainerNature getContainerNature() {
        return containerNature;
    }

    /**
     * Sets the value of the containerNature property.
     * 
     * @param value
     *     allowed object is
     *     {@link ContainerNature }
     *     
     */
    public void setContainerNature(ContainerNature value) {
        this.containerNature = value;
    }

    /**
     * Gets the value of the containerRegistered property.
     * 
     * @return
     *     possible object is
     *     {@link YesNoOption }
     *     
     */
    public YesNoOption getContainerRegistered() {
        return containerRegistered;
    }

    /**
     * Sets the value of the containerRegistered property.
     * 
     * @param value
     *     allowed object is
     *     {@link YesNoOption }
     *     
     */
    public void setContainerRegistered(YesNoOption value) {
        this.containerRegistered = value;
    }

    /**
     * Gets the value of the qualifierFreightGeneralDangerousGoods property.
     * 
     * @return
     *     possible object is
     *     {@link YesNoOption }
     *     
     */
    public YesNoOption getQualifierFreightGeneralDangerousGoods() {
        return qualifierFreightGeneralDangerousGoods;
    }

    /**
     * Sets the value of the qualifierFreightGeneralDangerousGoods property.
     * 
     * @param value
     *     allowed object is
     *     {@link YesNoOption }
     *     
     */
    public void setQualifierFreightGeneralDangerousGoods(YesNoOption value) {
        this.qualifierFreightGeneralDangerousGoods = value;
    }

    /**
     * Gets the value of the qualifierFreightGeneralFragile property.
     * 
     * @return
     *     possible object is
     *     {@link YesNoOption }
     *     
     */
    public YesNoOption getQualifierFreightGeneralFragile() {
        return qualifierFreightGeneralFragile;
    }

    /**
     * Sets the value of the qualifierFreightGeneralFragile property.
     * 
     * @param value
     *     allowed object is
     *     {@link YesNoOption }
     *     
     */
    public void setQualifierFreightGeneralFragile(YesNoOption value) {
        this.qualifierFreightGeneralFragile = value;
    }

    /**
     * Gets the value of the qualifierFreightGeneralRefrigerated property.
     * 
     * @return
     *     possible object is
     *     {@link YesNoOption }
     *     
     */
    public YesNoOption getQualifierFreightGeneralRefrigerated() {
        return qualifierFreightGeneralRefrigerated;
    }

    /**
     * Sets the value of the qualifierFreightGeneralRefrigerated property.
     * 
     * @param value
     *     allowed object is
     *     {@link YesNoOption }
     *     
     */
    public void setQualifierFreightGeneralRefrigerated(YesNoOption value) {
        this.qualifierFreightGeneralRefrigerated = value;
    }

    /**
     * Gets the value of the qualifierVehicleMake property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getQualifierVehicleMake() {
        return qualifierVehicleMake;
    }

    /**
     * Sets the value of the qualifierVehicleMake property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setQualifierVehicleMake(String value) {
        this.qualifierVehicleMake = value;
    }

    /**
     * Gets the value of the qualifierVehicleModel property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getQualifierVehicleModel() {
        return qualifierVehicleModel;
    }

    /**
     * Sets the value of the qualifierVehicleModel property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setQualifierVehicleModel(String value) {
        this.qualifierVehicleModel = value;
    }

    /**
     * Gets the value of the qualifierVehicleDescription property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getQualifierVehicleDescription() {
        return qualifierVehicleDescription;
    }

    /**
     * Sets the value of the qualifierVehicleDescription property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setQualifierVehicleDescription(String value) {
        this.qualifierVehicleDescription = value;
    }

    /**
     * Gets the value of the qualifierVehicleRunning property.
     * 
     * @return
     *     possible object is
     *     {@link YesNoOption }
     *     
     */
    public YesNoOption getQualifierVehicleRunning() {
        return qualifierVehicleRunning;
    }

    /**
     * Sets the value of the qualifierVehicleRunning property.
     * 
     * @param value
     *     allowed object is
     *     {@link YesNoOption }
     *     
     */
    public void setQualifierVehicleRunning(YesNoOption value) {
        this.qualifierVehicleRunning = value;
    }

    /**
     * Gets the value of the qualifierVehicleRegistered property.
     * 
     * @return
     *     possible object is
     *     {@link YesNoOption }
     *     
     */
    public YesNoOption getQualifierVehicleRegistered() {
        return qualifierVehicleRegistered;
    }

    /**
     * Sets the value of the qualifierVehicleRegistered property.
     * 
     * @param value
     *     allowed object is
     *     {@link YesNoOption }
     *     
     */
    public void setQualifierVehicleRegistered(YesNoOption value) {
        this.qualifierVehicleRegistered = value;
    }

    /**
     * Gets the value of the qualifierVehicleYear property.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getQualifierVehicleYear() {
        return qualifierVehicleYear;
    }

    /**
     * Sets the value of the qualifierVehicleYear property.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setQualifierVehicleYear(Integer value) {
        this.qualifierVehicleYear = value;
    }

    /**
     * Gets the value of the qualifierVehicleRegistration property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getQualifierVehicleRegistration() {
        return qualifierVehicleRegistration;
    }

    /**
     * Sets the value of the qualifierVehicleRegistration property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setQualifierVehicleRegistration(String value) {
        this.qualifierVehicleRegistration = value;
    }

    /**
     * Gets the value of the qualifierBoatMake property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getQualifierBoatMake() {
        return qualifierBoatMake;
    }

    /**
     * Sets the value of the qualifierBoatMake property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setQualifierBoatMake(String value) {
        this.qualifierBoatMake = value;
    }

    /**
     * Gets the value of the qualifierBoatModel property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getQualifierBoatModel() {
        return qualifierBoatModel;
    }

    /**
     * Sets the value of the qualifierBoatModel property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setQualifierBoatModel(String value) {
        this.qualifierBoatModel = value;
    }

    /**
     * Gets the value of the qualifierBoatSeaworthy property.
     * 
     * @return
     *     possible object is
     *     {@link YesNoOption }
     *     
     */
    public YesNoOption getQualifierBoatSeaworthy() {
        return qualifierBoatSeaworthy;
    }

    /**
     * Sets the value of the qualifierBoatSeaworthy property.
     * 
     * @param value
     *     allowed object is
     *     {@link YesNoOption }
     *     
     */
    public void setQualifierBoatSeaworthy(YesNoOption value) {
        this.qualifierBoatSeaworthy = value;
    }

    /**
     * Gets the value of the qualifierBoatTrailer property.
     * 
     * @return
     *     possible object is
     *     {@link YesNoOption }
     *     
     */
    public YesNoOption getQualifierBoatTrailer() {
        return qualifierBoatTrailer;
    }

    /**
     * Sets the value of the qualifierBoatTrailer property.
     * 
     * @param value
     *     allowed object is
     *     {@link YesNoOption }
     *     
     */
    public void setQualifierBoatTrailer(YesNoOption value) {
        this.qualifierBoatTrailer = value;
    }

    /**
     * Gets the value of the qualifierBoatHullType property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getQualifierBoatHullType() {
        return qualifierBoatHullType;
    }

    /**
     * Sets the value of the qualifierBoatHullType property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setQualifierBoatHullType(String value) {
        this.qualifierBoatHullType = value;
    }

    /**
     * Gets the value of the qualifierLivestockType property.
     * 
     * @return
     *     possible object is
     *     {@link LivestockType }
     *     
     */
    public LivestockType getQualifierLivestockType() {
        return qualifierLivestockType;
    }

    /**
     * Sets the value of the qualifierLivestockType property.
     * 
     * @param value
     *     allowed object is
     *     {@link LivestockType }
     *     
     */
    public void setQualifierLivestockType(LivestockType value) {
        this.qualifierLivestockType = value;
    }

    /**
     * Gets the value of the qualifierAnimalVaccinated property.
     * 
     * @return
     *     possible object is
     *     {@link YesNoOption }
     *     
     */
    public YesNoOption getQualifierAnimalVaccinated() {
        return qualifierAnimalVaccinated;
    }

    /**
     * Sets the value of the qualifierAnimalVaccinated property.
     * 
     * @param value
     *     allowed object is
     *     {@link YesNoOption }
     *     
     */
    public void setQualifierAnimalVaccinated(YesNoOption value) {
        this.qualifierAnimalVaccinated = value;
    }

    /**
     * Gets the value of the qualifierAnimalRegistered property.
     * 
     * @return
     *     possible object is
     *     {@link YesNoOption }
     *     
     */
    public YesNoOption getQualifierAnimalRegistered() {
        return qualifierAnimalRegistered;
    }

    /**
     * Sets the value of the qualifierAnimalRegistered property.
     * 
     * @param value
     *     allowed object is
     *     {@link YesNoOption }
     *     
     */
    public void setQualifierAnimalRegistered(YesNoOption value) {
        this.qualifierAnimalRegistered = value;
    }

    /**
     * Gets the value of the qualifierAnimalType property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getQualifierAnimalType() {
        return qualifierAnimalType;
    }

    /**
     * Sets the value of the qualifierAnimalType property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setQualifierAnimalType(String value) {
        this.qualifierAnimalType = value;
    }

    /**
     * Gets the value of the qualifierAnimalBreed property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getQualifierAnimalBreed() {
        return qualifierAnimalBreed;
    }

    /**
     * Sets the value of the qualifierAnimalBreed property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setQualifierAnimalBreed(String value) {
        this.qualifierAnimalBreed = value;
    }

    /**
     * Gets the value of the qualifierAnimalSex property.
     * 
     * @return
     *     possible object is
     *     {@link Sex }
     *     
     */
    public Sex getQualifierAnimalSex() {
        return qualifierAnimalSex;
    }

    /**
     * Sets the value of the qualifierAnimalSex property.
     * 
     * @param value
     *     allowed object is
     *     {@link Sex }
     *     
     */
    public void setQualifierAnimalSex(Sex value) {
        this.qualifierAnimalSex = value;
    }

    /**
     * Gets the value of the qualifierAnimalAge property.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getQualifierAnimalAge() {
        return qualifierAnimalAge;
    }

    /**
     * Sets the value of the qualifierAnimalAge property.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setQualifierAnimalAge(Integer value) {
        this.qualifierAnimalAge = value;
    }

    /**
     * Gets the value of the qualifierAnimalCrate property.
     * 
     * @return
     *     possible object is
     *     {@link AnimalCrate }
     *     
     */
    public AnimalCrate getQualifierAnimalCrate() {
        return qualifierAnimalCrate;
    }

    /**
     * Sets the value of the qualifierAnimalCrate property.
     * 
     * @param value
     *     allowed object is
     *     {@link AnimalCrate }
     *     
     */
    public void setQualifierAnimalCrate(AnimalCrate value) {
        this.qualifierAnimalCrate = value;
    }

    /**
     * Gets the value of the distanceMeasurementType property.
     * 
     * @return
     *     possible object is
     *     {@link DistanceMeasurementType }
     *     
     */
    public DistanceMeasurementType getDistanceMeasurementType() {
        return distanceMeasurementType;
    }

    /**
     * Sets the value of the distanceMeasurementType property.
     * 
     * @param value
     *     allowed object is
     *     {@link DistanceMeasurementType }
     *     
     */
    public void setDistanceMeasurementType(DistanceMeasurementType value) {
        this.distanceMeasurementType = value;
    }

    /**
     * Gets the value of the weightMeasurementType property.
     * 
     * @return
     *     possible object is
     *     {@link WeightMeasurementType }
     *     
     */
    public WeightMeasurementType getWeightMeasurementType() {
        return weightMeasurementType;
    }

    /**
     * Sets the value of the weightMeasurementType property.
     * 
     * @param value
     *     allowed object is
     *     {@link WeightMeasurementType }
     *     
     */
    public void setWeightMeasurementType(WeightMeasurementType value) {
        this.weightMeasurementType = value;
    }

    /**
     * Gets the value of the length property.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getLength() {
        return length;
    }

    /**
     * Sets the value of the length property.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setLength(Integer value) {
        this.length = value;
    }

    /**
     * Gets the value of the width property.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getWidth() {
        return width;
    }

    /**
     * Sets the value of the width property.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setWidth(Integer value) {
        this.width = value;
    }

    /**
     * Gets the value of the height property.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getHeight() {
        return height;
    }

    /**
     * Sets the value of the height property.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setHeight(Integer value) {
        this.height = value;
    }

    /**
     * Gets the value of the weight property.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getWeight() {
        return weight;
    }

    /**
     * Sets the value of the weight property.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setWeight(Integer value) {
        this.weight = value;
    }

    /**
     * Gets the value of the sku property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSku() {
        return sku;
    }

    /**
     * Sets the value of the sku property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSku(String value) {
        this.sku = value;
    }

    /**
     * Gets the value of the sscc property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSscc() {
        return sscc;
    }

    /**
     * Sets the value of the sscc property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSscc(String value) {
        this.sscc = value;
    }

    /**
     * Gets the value of the hs property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getHs() {
        return hs;
    }

    /**
     * Sets the value of the hs property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setHs(String value) {
        this.hs = value;
    }

    /**
     * Gets the value of the upc property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getUpc() {
        return upc;
    }

    /**
     * Sets the value of the upc property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setUpc(String value) {
        this.upc = value;
    }

    /**
     * Gets the value of the ean property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getEan() {
        return ean;
    }

    /**
     * Sets the value of the ean property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setEan(String value) {
        this.ean = value;
    }

    /**
     * Gets the value of the isbn property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getIsbn() {
        return isbn;
    }

    /**
     * Sets the value of the isbn property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setIsbn(String value) {
        this.isbn = value;
    }

    /**
     * Gets the value of the asin property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAsin() {
        return asin;
    }

    /**
     * Sets the value of the asin property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAsin(String value) {
        this.asin = value;
    }

    /**
     * Gets the value of the mpn property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMpn() {
        return mpn;
    }

    /**
     * Sets the value of the mpn property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMpn(String value) {
        this.mpn = value;
    }

    /**
     * Gets the value of the goodsPrice property.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getGoodsPrice() {
        return goodsPrice;
    }

    /**
     * Sets the value of the goodsPrice property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setGoodsPrice(BigDecimal value) {
        this.goodsPrice = value;
    }

    /**
     * Gets the value of the listPrice property.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getListPrice() {
        return listPrice;
    }

    /**
     * Sets the value of the listPrice property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setListPrice(BigDecimal value) {
        this.listPrice = value;
    }

    /**
     * Gets the value of the salePrice property.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getSalePrice() {
        return salePrice;
    }

    /**
     * Sets the value of the salePrice property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setSalePrice(BigDecimal value) {
        this.salePrice = value;
    }

    /**
     * Gets the value of the modelNumber property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getModelNumber() {
        return modelNumber;
    }

    /**
     * Sets the value of the modelNumber property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setModelNumber(String value) {
        this.modelNumber = value;
    }

    /**
     * Gets the value of the styleNumber property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getStyleNumber() {
        return styleNumber;
    }

    /**
     * Sets the value of the styleNumber property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setStyleNumber(String value) {
        this.styleNumber = value;
    }

    /**
     * Gets the value of the locationSelection property.
     * 
     * @return
     *     possible object is
     *     {@link LocationSelection }
     *     
     */
    public LocationSelection getLocationSelection() {
        return locationSelection;
    }

    /**
     * Sets the value of the locationSelection property.
     * 
     * @param value
     *     allowed object is
     *     {@link LocationSelection }
     *     
     */
    public void setLocationSelection(LocationSelection value) {
        this.locationSelection = value;
    }

    /**
     * Gets the value of the itemStocks property.
     * 
     * @return
     *     possible object is
     *     {@link Item.ItemStocks }
     *     
     */
    public Item.ItemStocks getItemStocks() {
        return itemStocks;
    }

    /**
     * Sets the value of the itemStocks property.
     * 
     * @param value
     *     allowed object is
     *     {@link Item.ItemStocks }
     *     
     */
    public void setItemStocks(Item.ItemStocks value) {
        this.itemStocks = value;
    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType>
     *   &lt;complexContent>
     *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
     *       &lt;sequence>
     *         &lt;element name="itemStock" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}ItemStock" maxOccurs="50"/>
     *       &lt;/sequence>
     *     &lt;/restriction>
     *   &lt;/complexContent>
     * &lt;/complexType>
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "itemStock"
    })
    public static class ItemStocks {

        @XmlElement(required = true)
        protected List<ItemStock> itemStock;

        /**
         * Gets the value of the itemStock property.
         * 
         * <p>
         * This accessor method returns a reference to the live list,
         * not a snapshot. Therefore any modification you make to the
         * returned list will be present inside the JAXB object.
         * This is why there is not a <CODE>set</CODE> method for the itemStock property.
         * 
         * <p>
         * For example, to add a new item, do as follows:
         * <pre>
         *    getItemStock().add(newItem);
         * </pre>
         * 
         * 
         * <p>
         * Objects of the following type(s) are allowed in the list
         * {@link ItemStock }
         * 
         * 
         */
        public List<ItemStock> getItemStock() {
            if (itemStock == null) {
                itemStock = new ArrayList<ItemStock>();
            }
            return this.itemStock;
        }

    }

}
