
package demo.com.temando.api;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for Payment complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="Payment">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;all>
 *         &lt;element name="paymentType" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}PaymentType"/>
 *         &lt;element name="cardType" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}CreditCardType" minOccurs="0"/>
 *         &lt;element name="cardExpiryDate" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}CreditCardExpiryDate" minOccurs="0"/>
 *         &lt;element name="cardNumber" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}CreditCardNumber" minOccurs="0"/>
 *         &lt;element name="cardName" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}CreditCardName" minOccurs="0"/>
 *         &lt;element name="cardToken" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}CreditCardToken" minOccurs="0"/>
 *         &lt;element name="paypalPayerId" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}PaypalPayerId" minOccurs="0"/>
 *         &lt;element name="paypalToken" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}PaypalToken" minOccurs="0"/>
 *       &lt;/all>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "Payment", namespace = "http://api-demo.temando.com/schema/2009_06/common.xsd", propOrder = {

})
public class Payment {

    @XmlElement(required = true)
    protected PaymentType paymentType;
    protected CreditCardType cardType;
    protected String cardExpiryDate;
    protected String cardNumber;
    protected String cardName;
    protected String cardToken;
    protected String paypalPayerId;
    protected String paypalToken;

    /**
     * Gets the value of the paymentType property.
     * 
     * @return
     *     possible object is
     *     {@link PaymentType }
     *     
     */
    public PaymentType getPaymentType() {
        return paymentType;
    }

    /**
     * Sets the value of the paymentType property.
     * 
     * @param value
     *     allowed object is
     *     {@link PaymentType }
     *     
     */
    public void setPaymentType(PaymentType value) {
        this.paymentType = value;
    }

    /**
     * Gets the value of the cardType property.
     * 
     * @return
     *     possible object is
     *     {@link CreditCardType }
     *     
     */
    public CreditCardType getCardType() {
        return cardType;
    }

    /**
     * Sets the value of the cardType property.
     * 
     * @param value
     *     allowed object is
     *     {@link CreditCardType }
     *     
     */
    public void setCardType(CreditCardType value) {
        this.cardType = value;
    }

    /**
     * Gets the value of the cardExpiryDate property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCardExpiryDate() {
        return cardExpiryDate;
    }

    /**
     * Sets the value of the cardExpiryDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCardExpiryDate(String value) {
        this.cardExpiryDate = value;
    }

    /**
     * Gets the value of the cardNumber property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCardNumber() {
        return cardNumber;
    }

    /**
     * Sets the value of the cardNumber property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCardNumber(String value) {
        this.cardNumber = value;
    }

    /**
     * Gets the value of the cardName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCardName() {
        return cardName;
    }

    /**
     * Sets the value of the cardName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCardName(String value) {
        this.cardName = value;
    }

    /**
     * Gets the value of the cardToken property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCardToken() {
        return cardToken;
    }

    /**
     * Sets the value of the cardToken property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCardToken(String value) {
        this.cardToken = value;
    }

    /**
     * Gets the value of the paypalPayerId property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPaypalPayerId() {
        return paypalPayerId;
    }

    /**
     * Sets the value of the paypalPayerId property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPaypalPayerId(String value) {
        this.paypalPayerId = value;
    }

    /**
     * Gets the value of the paypalToken property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPaypalToken() {
        return paypalToken;
    }

    /**
     * Sets the value of the paypalToken property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPaypalToken(String value) {
        this.paypalToken = value;
    }

}
