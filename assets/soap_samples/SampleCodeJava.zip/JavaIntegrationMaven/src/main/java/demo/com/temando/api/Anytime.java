
package demo.com.temando.api;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for Anytime complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="Anytime">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;all>
 *         &lt;element name="readyDate" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}Date"/>
 *         &lt;element name="readyTime" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}ReadyTime"/>
 *       &lt;/all>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "Anytime", namespace = "http://api-demo.temando.com/schema/2009_06/common.xsd", propOrder = {

})
public class Anytime {

    @XmlElement(required = true)
    protected String readyDate;
    @XmlElement(required = true)
    protected ReadyTime readyTime;

    /**
     * Gets the value of the readyDate property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getReadyDate() {
        return readyDate;
    }

    /**
     * Sets the value of the readyDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setReadyDate(String value) {
        this.readyDate = value;
    }

    /**
     * Gets the value of the readyTime property.
     * 
     * @return
     *     possible object is
     *     {@link ReadyTime }
     *     
     */
    public ReadyTime getReadyTime() {
        return readyTime;
    }

    /**
     * Sets the value of the readyTime property.
     * 
     * @param value
     *     allowed object is
     *     {@link ReadyTime }
     *     
     */
    public void setReadyTime(ReadyTime value) {
        this.readyTime = value;
    }

}
