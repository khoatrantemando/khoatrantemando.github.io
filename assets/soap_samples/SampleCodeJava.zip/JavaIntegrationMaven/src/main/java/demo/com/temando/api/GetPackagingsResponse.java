
package demo.com.temando.api;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for anonymous complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType>
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;all>
 *         &lt;element name="packagings">
 *           &lt;complexType>
 *             &lt;complexContent>
 *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                 &lt;sequence>
 *                   &lt;element name="packaging" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}PackagingPreference" maxOccurs="unbounded" minOccurs="0"/>
 *                 &lt;/sequence>
 *               &lt;/restriction>
 *             &lt;/complexContent>
 *           &lt;/complexType>
 *         &lt;/element>
 *       &lt;/all>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {

})
@XmlRootElement(name = "getPackagingsResponse")
public class GetPackagingsResponse {

    @XmlElement(required = true)
    protected GetPackagingsResponse.Packagings packagings;

    /**
     * Gets the value of the packagings property.
     * 
     * @return
     *     possible object is
     *     {@link GetPackagingsResponse.Packagings }
     *     
     */
    public GetPackagingsResponse.Packagings getPackagings() {
        return packagings;
    }

    /**
     * Sets the value of the packagings property.
     * 
     * @param value
     *     allowed object is
     *     {@link GetPackagingsResponse.Packagings }
     *     
     */
    public void setPackagings(GetPackagingsResponse.Packagings value) {
        this.packagings = value;
    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType>
     *   &lt;complexContent>
     *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
     *       &lt;sequence>
     *         &lt;element name="packaging" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}PackagingPreference" maxOccurs="unbounded" minOccurs="0"/>
     *       &lt;/sequence>
     *     &lt;/restriction>
     *   &lt;/complexContent>
     * &lt;/complexType>
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "packaging"
    })
    public static class Packagings {

        protected List<PackagingPreference> packaging;

        /**
         * Gets the value of the packaging property.
         * 
         * <p>
         * This accessor method returns a reference to the live list,
         * not a snapshot. Therefore any modification you make to the
         * returned list will be present inside the JAXB object.
         * This is why there is not a <CODE>set</CODE> method for the packaging property.
         * 
         * <p>
         * For example, to add a new item, do as follows:
         * <pre>
         *    getPackaging().add(newItem);
         * </pre>
         * 
         * 
         * <p>
         * Objects of the following type(s) are allowed in the list
         * {@link PackagingPreference }
         * 
         * 
         */
        public List<PackagingPreference> getPackaging() {
            if (packaging == null) {
                packaging = new ArrayList<PackagingPreference>();
            }
            return this.packaging;
        }

    }

}
