
package demo.com.temando.api;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for TermsOfTrade.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * <p>
 * <pre>
 * &lt;simpleType name="TermsOfTrade">
 *   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *     &lt;enumeration value="Delivered Duty Paid"/>
 *     &lt;enumeration value="Delivered Duty Unpaid"/>
 *   &lt;/restriction>
 * &lt;/simpleType>
 * </pre>
 * 
 */
@XmlType(name = "TermsOfTrade", namespace = "http://api-demo.temando.com/schema/2009_06/common.xsd")
@XmlEnum
public enum TermsOfTrade {

    @XmlEnumValue("Delivered Duty Paid")
    DELIVERED_DUTY_PAID("Delivered Duty Paid"),
    @XmlEnumValue("Delivered Duty Unpaid")
    DELIVERED_DUTY_UNPAID("Delivered Duty Unpaid");
    private final String value;

    TermsOfTrade(String v) {
        value = v;
    }

    public String value() {
        return value;
    }

    public static TermsOfTrade fromValue(String v) {
        for (TermsOfTrade c: TermsOfTrade.values()) {
            if (c.value.equals(v)) {
                return c;
            }
        }
        throw new IllegalArgumentException(v);
    }

}
