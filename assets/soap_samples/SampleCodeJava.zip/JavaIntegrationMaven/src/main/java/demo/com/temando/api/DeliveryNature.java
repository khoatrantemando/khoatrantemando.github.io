
package demo.com.temando.api;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for DeliveryNature.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * <p>
 * <pre>
 * &lt;simpleType name="DeliveryNature">
 *   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *     &lt;enumeration value="Domestic"/>
 *     &lt;enumeration value="International"/>
 *   &lt;/restriction>
 * &lt;/simpleType>
 * </pre>
 * 
 */
@XmlType(name = "DeliveryNature", namespace = "http://api-demo.temando.com/schema/2009_06/common.xsd")
@XmlEnum
public enum DeliveryNature {

    @XmlEnumValue("Domestic")
    DOMESTIC("Domestic"),
    @XmlEnumValue("International")
    INTERNATIONAL("International");
    private final String value;

    DeliveryNature(String v) {
        value = v;
    }

    public String value() {
        return value;
    }

    public static DeliveryNature fromValue(String v) {
        for (DeliveryNature c: DeliveryNature.values()) {
            if (c.value.equals(v)) {
                return c;
            }
        }
        throw new IllegalArgumentException(v);
    }

}
