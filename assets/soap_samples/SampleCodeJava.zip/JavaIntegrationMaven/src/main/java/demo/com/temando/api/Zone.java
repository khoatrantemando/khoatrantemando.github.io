
package demo.com.temando.api;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for Zone complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="Zone">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;all>
 *         &lt;element name="name" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}ZoneName"/>
 *         &lt;element name="country" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}CountryCode"/>
 *         &lt;element name="zoneRanges" minOccurs="0">
 *           &lt;complexType>
 *             &lt;complexContent>
 *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                 &lt;sequence>
 *                   &lt;element name="zoneRange" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}ZoneRange" maxOccurs="50"/>
 *                 &lt;/sequence>
 *               &lt;/restriction>
 *             &lt;/complexContent>
 *           &lt;/complexType>
 *         &lt;/element>
 *       &lt;/all>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "Zone", namespace = "http://api-demo.temando.com/schema/2009_06/common.xsd", propOrder = {

})
public class Zone {

    @XmlElement(required = true)
    protected String name;
    @XmlElement(required = true)
    protected String country;
    protected Zone.ZoneRanges zoneRanges;

    /**
     * Gets the value of the name property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getName() {
        return name;
    }

    /**
     * Sets the value of the name property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setName(String value) {
        this.name = value;
    }

    /**
     * Gets the value of the country property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCountry() {
        return country;
    }

    /**
     * Sets the value of the country property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCountry(String value) {
        this.country = value;
    }

    /**
     * Gets the value of the zoneRanges property.
     * 
     * @return
     *     possible object is
     *     {@link Zone.ZoneRanges }
     *     
     */
    public Zone.ZoneRanges getZoneRanges() {
        return zoneRanges;
    }

    /**
     * Sets the value of the zoneRanges property.
     * 
     * @param value
     *     allowed object is
     *     {@link Zone.ZoneRanges }
     *     
     */
    public void setZoneRanges(Zone.ZoneRanges value) {
        this.zoneRanges = value;
    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType>
     *   &lt;complexContent>
     *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
     *       &lt;sequence>
     *         &lt;element name="zoneRange" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}ZoneRange" maxOccurs="50"/>
     *       &lt;/sequence>
     *     &lt;/restriction>
     *   &lt;/complexContent>
     * &lt;/complexType>
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "zoneRange"
    })
    public static class ZoneRanges {

        @XmlElement(required = true)
        protected List<ZoneRange> zoneRange;

        /**
         * Gets the value of the zoneRange property.
         * 
         * <p>
         * This accessor method returns a reference to the live list,
         * not a snapshot. Therefore any modification you make to the
         * returned list will be present inside the JAXB object.
         * This is why there is not a <CODE>set</CODE> method for the zoneRange property.
         * 
         * <p>
         * For example, to add a new item, do as follows:
         * <pre>
         *    getZoneRange().add(newItem);
         * </pre>
         * 
         * 
         * <p>
         * Objects of the following type(s) are allowed in the list
         * {@link ZoneRange }
         * 
         * 
         */
        public List<ZoneRange> getZoneRange() {
            if (zoneRange == null) {
                zoneRange = new ArrayList<ZoneRange>();
            }
            return this.zoneRange;
        }

    }

}
