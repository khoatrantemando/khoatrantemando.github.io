
package demo.com.temando.api;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for anonymous complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType>
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;all>
 *         &lt;element name="type" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}ManifestType" minOccurs="0"/>
 *         &lt;element name="labelPrinterType" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}LabelPrinterType" minOccurs="0"/>
 *         &lt;element name="carrierId" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}CarrierId" minOccurs="0"/>
 *         &lt;element name="clientId" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}ClientId" minOccurs="0"/>
 *         &lt;element name="location" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}LocationName" minOccurs="0"/>
 *         &lt;element name="locationType" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}LocationPosition" minOccurs="0"/>
 *         &lt;element name="state" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}State" minOccurs="0"/>
 *         &lt;element name="startCode" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}PostalCode" minOccurs="0"/>
 *         &lt;element name="endCode" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}PostalCode" minOccurs="0"/>
 *         &lt;element name="readyDate" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}Date" minOccurs="0"/>
 *         &lt;element name="lastConfirmed" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}YesNoOption" minOccurs="0"/>
 *         &lt;element name="listRequests" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}YesNoOption" minOccurs="0"/>
 *       &lt;/all>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {

})
@XmlRootElement(name = "getManifest")
public class GetManifest {

    protected ManifestType type;
    protected LabelPrinterType labelPrinterType;
    protected Integer carrierId;
    protected Integer clientId;
    protected String location;
    protected LocationPosition locationType;
    protected String state;
    protected String startCode;
    protected String endCode;
    protected String readyDate;
    protected YesNoOption lastConfirmed;
    protected YesNoOption listRequests;

    /**
     * Gets the value of the type property.
     * 
     * @return
     *     possible object is
     *     {@link ManifestType }
     *     
     */
    public ManifestType getType() {
        return type;
    }

    /**
     * Sets the value of the type property.
     * 
     * @param value
     *     allowed object is
     *     {@link ManifestType }
     *     
     */
    public void setType(ManifestType value) {
        this.type = value;
    }

    /**
     * Gets the value of the labelPrinterType property.
     * 
     * @return
     *     possible object is
     *     {@link LabelPrinterType }
     *     
     */
    public LabelPrinterType getLabelPrinterType() {
        return labelPrinterType;
    }

    /**
     * Sets the value of the labelPrinterType property.
     * 
     * @param value
     *     allowed object is
     *     {@link LabelPrinterType }
     *     
     */
    public void setLabelPrinterType(LabelPrinterType value) {
        this.labelPrinterType = value;
    }

    /**
     * Gets the value of the carrierId property.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getCarrierId() {
        return carrierId;
    }

    /**
     * Sets the value of the carrierId property.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setCarrierId(Integer value) {
        this.carrierId = value;
    }

    /**
     * Gets the value of the clientId property.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getClientId() {
        return clientId;
    }

    /**
     * Sets the value of the clientId property.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setClientId(Integer value) {
        this.clientId = value;
    }

    /**
     * Gets the value of the location property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLocation() {
        return location;
    }

    /**
     * Sets the value of the location property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLocation(String value) {
        this.location = value;
    }

    /**
     * Gets the value of the locationType property.
     * 
     * @return
     *     possible object is
     *     {@link LocationPosition }
     *     
     */
    public LocationPosition getLocationType() {
        return locationType;
    }

    /**
     * Sets the value of the locationType property.
     * 
     * @param value
     *     allowed object is
     *     {@link LocationPosition }
     *     
     */
    public void setLocationType(LocationPosition value) {
        this.locationType = value;
    }

    /**
     * Gets the value of the state property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getState() {
        return state;
    }

    /**
     * Sets the value of the state property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setState(String value) {
        this.state = value;
    }

    /**
     * Gets the value of the startCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getStartCode() {
        return startCode;
    }

    /**
     * Sets the value of the startCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setStartCode(String value) {
        this.startCode = value;
    }

    /**
     * Gets the value of the endCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getEndCode() {
        return endCode;
    }

    /**
     * Sets the value of the endCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setEndCode(String value) {
        this.endCode = value;
    }

    /**
     * Gets the value of the readyDate property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getReadyDate() {
        return readyDate;
    }

    /**
     * Sets the value of the readyDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setReadyDate(String value) {
        this.readyDate = value;
    }

    /**
     * Gets the value of the lastConfirmed property.
     * 
     * @return
     *     possible object is
     *     {@link YesNoOption }
     *     
     */
    public YesNoOption getLastConfirmed() {
        return lastConfirmed;
    }

    /**
     * Sets the value of the lastConfirmed property.
     * 
     * @param value
     *     allowed object is
     *     {@link YesNoOption }
     *     
     */
    public void setLastConfirmed(YesNoOption value) {
        this.lastConfirmed = value;
    }

    /**
     * Gets the value of the listRequests property.
     * 
     * @return
     *     possible object is
     *     {@link YesNoOption }
     *     
     */
    public YesNoOption getListRequests() {
        return listRequests;
    }

    /**
     * Sets the value of the listRequests property.
     * 
     * @param value
     *     allowed object is
     *     {@link YesNoOption }
     *     
     */
    public void setListRequests(YesNoOption value) {
        this.listRequests = value;
    }

}
