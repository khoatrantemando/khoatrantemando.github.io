
package demo.com.temando.api;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for ManifestType.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * <p>
 * <pre>
 * &lt;simpleType name="ManifestType">
 *   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *     &lt;enumeration value="Awaiting Confirmation"/>
 *     &lt;enumeration value="Confirmed"/>
 *   &lt;/restriction>
 * &lt;/simpleType>
 * </pre>
 * 
 */
@XmlType(name = "ManifestType", namespace = "http://api-demo.temando.com/schema/2009_06/common.xsd")
@XmlEnum
public enum ManifestType {

    @XmlEnumValue("Awaiting Confirmation")
    AWAITING_CONFIRMATION("Awaiting Confirmation"),
    @XmlEnumValue("Confirmed")
    CONFIRMED("Confirmed");
    private final String value;

    ManifestType(String v) {
        value = v;
    }

    public String value() {
        return value;
    }

    public static ManifestType fromValue(String v) {
        for (ManifestType c: ManifestType.values()) {
            if (c.value.equals(v)) {
                return c;
            }
        }
        throw new IllegalArgumentException(v);
    }

}
