
package demo.com.temando.api;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for LocationSelection.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * <p>
 * <pre>
 * &lt;simpleType name="LocationSelection">
 *   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *     &lt;enumeration value="Priority"/>
 *     &lt;enumeration value="Nearest"/>
 *     &lt;enumeration value="Nearest by Priority"/>
 *     &lt;enumeration value="Most Stock"/>
 *   &lt;/restriction>
 * &lt;/simpleType>
 * </pre>
 * 
 */
@XmlType(name = "LocationSelection", namespace = "http://api-demo.temando.com/schema/2009_06/common.xsd")
@XmlEnum
public enum LocationSelection {

    @XmlEnumValue("Priority")
    PRIORITY("Priority"),
    @XmlEnumValue("Nearest")
    NEAREST("Nearest"),
    @XmlEnumValue("Nearest by Priority")
    NEAREST_BY_PRIORITY("Nearest by Priority"),
    @XmlEnumValue("Most Stock")
    MOST_STOCK("Most Stock");
    private final String value;

    LocationSelection(String v) {
        value = v;
    }

    public String value() {
        return value;
    }

    public static LocationSelection fromValue(String v) {
        for (LocationSelection c: LocationSelection.values()) {
            if (c.value.equals(v)) {
                return c;
            }
        }
        throw new IllegalArgumentException(v);
    }

}
