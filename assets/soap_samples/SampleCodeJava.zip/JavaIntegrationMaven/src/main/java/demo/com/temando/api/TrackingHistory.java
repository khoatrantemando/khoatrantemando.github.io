
package demo.com.temando.api;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for TrackingHistory complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="TrackingHistory">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;all>
 *         &lt;element name="trackingStatus" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}HistoryTrackingStatus" minOccurs="0"/>
 *         &lt;element name="trackingStatusOccurred" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}Datetime" minOccurs="0"/>
 *         &lt;element name="trackingLastChecked" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}Datetime" minOccurs="0"/>
 *         &lt;element name="trackingFurtherDetails" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}TrackingFurtherDetails" minOccurs="0"/>
 *       &lt;/all>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "TrackingHistory", namespace = "http://api-demo.temando.com/schema/2009_06/common.xsd", propOrder = {

})
public class TrackingHistory {

    protected String trackingStatus;
    protected String trackingStatusOccurred;
    protected String trackingLastChecked;
    protected String trackingFurtherDetails;

    /**
     * Gets the value of the trackingStatus property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTrackingStatus() {
        return trackingStatus;
    }

    /**
     * Sets the value of the trackingStatus property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTrackingStatus(String value) {
        this.trackingStatus = value;
    }

    /**
     * Gets the value of the trackingStatusOccurred property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTrackingStatusOccurred() {
        return trackingStatusOccurred;
    }

    /**
     * Sets the value of the trackingStatusOccurred property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTrackingStatusOccurred(String value) {
        this.trackingStatusOccurred = value;
    }

    /**
     * Gets the value of the trackingLastChecked property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTrackingLastChecked() {
        return trackingLastChecked;
    }

    /**
     * Sets the value of the trackingLastChecked property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTrackingLastChecked(String value) {
        this.trackingLastChecked = value;
    }

    /**
     * Gets the value of the trackingFurtherDetails property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTrackingFurtherDetails() {
        return trackingFurtherDetails;
    }

    /**
     * Sets the value of the trackingFurtherDetails property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTrackingFurtherDetails(String value) {
        this.trackingFurtherDetails = value;
    }

}
