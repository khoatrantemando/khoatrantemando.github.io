
package demo.com.temando.api;

import java.math.BigInteger;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for anonymous complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType>
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;all>
 *         &lt;element name="requestId" type="{http://www.w3.org/2001/XMLSchema}positiveInteger" minOccurs="0"/>
 *         &lt;element name="bookingNumber" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}BookingNumber" minOccurs="0"/>
 *         &lt;element name="reference" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}ClientReference" minOccurs="0"/>
 *         &lt;element name="detail" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}Detail" minOccurs="0"/>
 *         &lt;element name="labelPrinterType" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}LabelPrinterType" minOccurs="0"/>
 *         &lt;element name="responseExclusions" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}ResponseExclusions" minOccurs="0"/>
 *       &lt;/all>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {

})
@XmlRootElement(name = "getRequest")
public class GetRequest {

    @XmlSchemaType(name = "positiveInteger")
    protected BigInteger requestId;
    protected String bookingNumber;
    protected String reference;
    protected Detail detail;
    protected LabelPrinterType labelPrinterType;
    protected ResponseExclusions responseExclusions;

    /**
     * Gets the value of the requestId property.
     * 
     * @return
     *     possible object is
     *     {@link BigInteger }
     *     
     */
    public BigInteger getRequestId() {
        return requestId;
    }

    /**
     * Sets the value of the requestId property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigInteger }
     *     
     */
    public void setRequestId(BigInteger value) {
        this.requestId = value;
    }

    /**
     * Gets the value of the bookingNumber property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getBookingNumber() {
        return bookingNumber;
    }

    /**
     * Sets the value of the bookingNumber property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setBookingNumber(String value) {
        this.bookingNumber = value;
    }

    /**
     * Gets the value of the reference property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getReference() {
        return reference;
    }

    /**
     * Sets the value of the reference property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setReference(String value) {
        this.reference = value;
    }

    /**
     * Gets the value of the detail property.
     * 
     * @return
     *     possible object is
     *     {@link Detail }
     *     
     */
    public Detail getDetail() {
        return detail;
    }

    /**
     * Sets the value of the detail property.
     * 
     * @param value
     *     allowed object is
     *     {@link Detail }
     *     
     */
    public void setDetail(Detail value) {
        this.detail = value;
    }

    /**
     * Gets the value of the labelPrinterType property.
     * 
     * @return
     *     possible object is
     *     {@link LabelPrinterType }
     *     
     */
    public LabelPrinterType getLabelPrinterType() {
        return labelPrinterType;
    }

    /**
     * Sets the value of the labelPrinterType property.
     * 
     * @param value
     *     allowed object is
     *     {@link LabelPrinterType }
     *     
     */
    public void setLabelPrinterType(LabelPrinterType value) {
        this.labelPrinterType = value;
    }

    /**
     * Gets the value of the responseExclusions property.
     * 
     * @return
     *     possible object is
     *     {@link ResponseExclusions }
     *     
     */
    public ResponseExclusions getResponseExclusions() {
        return responseExclusions;
    }

    /**
     * Sets the value of the responseExclusions property.
     * 
     * @param value
     *     allowed object is
     *     {@link ResponseExclusions }
     *     
     */
    public void setResponseExclusions(ResponseExclusions value) {
        this.responseExclusions = value;
    }

}
