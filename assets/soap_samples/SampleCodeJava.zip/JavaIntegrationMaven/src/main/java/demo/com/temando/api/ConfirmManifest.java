
package demo.com.temando.api;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for anonymous complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType>
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;all>
 *         &lt;element name="carrierId" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}CarrierId" minOccurs="0"/>
 *         &lt;element name="clientId" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}ClientId" minOccurs="0"/>
 *         &lt;element name="location" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}LocationName" minOccurs="0"/>
 *         &lt;element name="locationType" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}LocationPosition" minOccurs="0"/>
 *         &lt;element name="state" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}State" minOccurs="0"/>
 *         &lt;element name="startCode" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}PostalCode" minOccurs="0"/>
 *         &lt;element name="endCode" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}PostalCode" minOccurs="0"/>
 *         &lt;element name="startReadyDate" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}Date" minOccurs="0"/>
 *         &lt;element name="endReadyDate" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}Date" minOccurs="0"/>
 *         &lt;element name="confirmedReadyDate" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}Date" minOccurs="0"/>
 *         &lt;element name="listRequests" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}YesNoOption" minOccurs="0"/>
 *         &lt;element name="labelPrinterType" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}LabelPrinterType" minOccurs="0"/>
 *       &lt;/all>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {

})
@XmlRootElement(name = "confirmManifest")
public class ConfirmManifest {

    protected Integer carrierId;
    protected Integer clientId;
    protected String location;
    protected LocationPosition locationType;
    protected String state;
    protected String startCode;
    protected String endCode;
    protected String startReadyDate;
    protected String endReadyDate;
    protected String confirmedReadyDate;
    protected YesNoOption listRequests;
    protected LabelPrinterType labelPrinterType;

    /**
     * Gets the value of the carrierId property.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getCarrierId() {
        return carrierId;
    }

    /**
     * Sets the value of the carrierId property.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setCarrierId(Integer value) {
        this.carrierId = value;
    }

    /**
     * Gets the value of the clientId property.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getClientId() {
        return clientId;
    }

    /**
     * Sets the value of the clientId property.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setClientId(Integer value) {
        this.clientId = value;
    }

    /**
     * Gets the value of the location property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLocation() {
        return location;
    }

    /**
     * Sets the value of the location property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLocation(String value) {
        this.location = value;
    }

    /**
     * Gets the value of the locationType property.
     * 
     * @return
     *     possible object is
     *     {@link LocationPosition }
     *     
     */
    public LocationPosition getLocationType() {
        return locationType;
    }

    /**
     * Sets the value of the locationType property.
     * 
     * @param value
     *     allowed object is
     *     {@link LocationPosition }
     *     
     */
    public void setLocationType(LocationPosition value) {
        this.locationType = value;
    }

    /**
     * Gets the value of the state property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getState() {
        return state;
    }

    /**
     * Sets the value of the state property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setState(String value) {
        this.state = value;
    }

    /**
     * Gets the value of the startCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getStartCode() {
        return startCode;
    }

    /**
     * Sets the value of the startCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setStartCode(String value) {
        this.startCode = value;
    }

    /**
     * Gets the value of the endCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getEndCode() {
        return endCode;
    }

    /**
     * Sets the value of the endCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setEndCode(String value) {
        this.endCode = value;
    }

    /**
     * Gets the value of the startReadyDate property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getStartReadyDate() {
        return startReadyDate;
    }

    /**
     * Sets the value of the startReadyDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setStartReadyDate(String value) {
        this.startReadyDate = value;
    }

    /**
     * Gets the value of the endReadyDate property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getEndReadyDate() {
        return endReadyDate;
    }

    /**
     * Sets the value of the endReadyDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setEndReadyDate(String value) {
        this.endReadyDate = value;
    }

    /**
     * Gets the value of the confirmedReadyDate property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getConfirmedReadyDate() {
        return confirmedReadyDate;
    }

    /**
     * Sets the value of the confirmedReadyDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setConfirmedReadyDate(String value) {
        this.confirmedReadyDate = value;
    }

    /**
     * Gets the value of the listRequests property.
     * 
     * @return
     *     possible object is
     *     {@link YesNoOption }
     *     
     */
    public YesNoOption getListRequests() {
        return listRequests;
    }

    /**
     * Sets the value of the listRequests property.
     * 
     * @param value
     *     allowed object is
     *     {@link YesNoOption }
     *     
     */
    public void setListRequests(YesNoOption value) {
        this.listRequests = value;
    }

    /**
     * Gets the value of the labelPrinterType property.
     * 
     * @return
     *     possible object is
     *     {@link LabelPrinterType }
     *     
     */
    public LabelPrinterType getLabelPrinterType() {
        return labelPrinterType;
    }

    /**
     * Sets the value of the labelPrinterType property.
     * 
     * @param value
     *     allowed object is
     *     {@link LabelPrinterType }
     *     
     */
    public void setLabelPrinterType(LabelPrinterType value) {
        this.labelPrinterType = value;
    }

}
