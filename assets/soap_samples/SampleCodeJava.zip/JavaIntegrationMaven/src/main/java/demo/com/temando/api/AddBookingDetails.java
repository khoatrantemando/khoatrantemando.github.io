
package demo.com.temando.api;

import java.math.BigInteger;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for anonymous complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType>
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;all>
 *         &lt;element name="requestId" type="{http://www.w3.org/2001/XMLSchema}positiveInteger"/>
 *         &lt;element name="bookingNumber" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}BookingNumber"/>
 *         &lt;element name="consignmentNumber" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}ConsignmentNumber" minOccurs="0"/>
 *         &lt;element name="consignmentDocument" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}ConsignmentDocument" minOccurs="0"/>
 *         &lt;element name="consignmentDocumentType" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}ConsignmentDocumentType" minOccurs="0"/>
 *       &lt;/all>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {

})
@XmlRootElement(name = "addBookingDetails")
public class AddBookingDetails {

    @XmlElement(required = true)
    @XmlSchemaType(name = "positiveInteger")
    protected BigInteger requestId;
    @XmlElement(required = true)
    protected String bookingNumber;
    protected String consignmentNumber;
    protected String consignmentDocument;
    protected ConsignmentDocumentType consignmentDocumentType;

    /**
     * Gets the value of the requestId property.
     * 
     * @return
     *     possible object is
     *     {@link BigInteger }
     *     
     */
    public BigInteger getRequestId() {
        return requestId;
    }

    /**
     * Sets the value of the requestId property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigInteger }
     *     
     */
    public void setRequestId(BigInteger value) {
        this.requestId = value;
    }

    /**
     * Gets the value of the bookingNumber property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getBookingNumber() {
        return bookingNumber;
    }

    /**
     * Sets the value of the bookingNumber property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setBookingNumber(String value) {
        this.bookingNumber = value;
    }

    /**
     * Gets the value of the consignmentNumber property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getConsignmentNumber() {
        return consignmentNumber;
    }

    /**
     * Sets the value of the consignmentNumber property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setConsignmentNumber(String value) {
        this.consignmentNumber = value;
    }

    /**
     * Gets the value of the consignmentDocument property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getConsignmentDocument() {
        return consignmentDocument;
    }

    /**
     * Sets the value of the consignmentDocument property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setConsignmentDocument(String value) {
        this.consignmentDocument = value;
    }

    /**
     * Gets the value of the consignmentDocumentType property.
     * 
     * @return
     *     possible object is
     *     {@link ConsignmentDocumentType }
     *     
     */
    public ConsignmentDocumentType getConsignmentDocumentType() {
        return consignmentDocumentType;
    }

    /**
     * Sets the value of the consignmentDocumentType property.
     * 
     * @param value
     *     allowed object is
     *     {@link ConsignmentDocumentType }
     *     
     */
    public void setConsignmentDocumentType(ConsignmentDocumentType value) {
        this.consignmentDocumentType = value;
    }

}
