
package demo.com.temando.api;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for anonymous complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType>
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;all>
 *         &lt;element name="loginDetails" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}LoginDetails"/>
 *         &lt;element name="client" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}Client"/>
 *         &lt;element name="promotionCode" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}PromotionCode" minOccurs="0"/>
 *         &lt;element name="accountManager" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}AccountManager" minOccurs="0"/>
 *       &lt;/all>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {

})
@XmlRootElement(name = "createClient")
public class CreateClient {

    @XmlElement(required = true)
    protected LoginDetails loginDetails;
    @XmlElement(required = true)
    protected Client client;
    protected String promotionCode;
    protected String accountManager;

    /**
     * Gets the value of the loginDetails property.
     * 
     * @return
     *     possible object is
     *     {@link LoginDetails }
     *     
     */
    public LoginDetails getLoginDetails() {
        return loginDetails;
    }

    /**
     * Sets the value of the loginDetails property.
     * 
     * @param value
     *     allowed object is
     *     {@link LoginDetails }
     *     
     */
    public void setLoginDetails(LoginDetails value) {
        this.loginDetails = value;
    }

    /**
     * Gets the value of the client property.
     * 
     * @return
     *     possible object is
     *     {@link Client }
     *     
     */
    public Client getClient() {
        return client;
    }

    /**
     * Sets the value of the client property.
     * 
     * @param value
     *     allowed object is
     *     {@link Client }
     *     
     */
    public void setClient(Client value) {
        this.client = value;
    }

    /**
     * Gets the value of the promotionCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPromotionCode() {
        return promotionCode;
    }

    /**
     * Sets the value of the promotionCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPromotionCode(String value) {
        this.promotionCode = value;
    }

    /**
     * Gets the value of the accountManager property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAccountManager() {
        return accountManager;
    }

    /**
     * Sets the value of the accountManager property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAccountManager(String value) {
        this.accountManager = value;
    }

}
