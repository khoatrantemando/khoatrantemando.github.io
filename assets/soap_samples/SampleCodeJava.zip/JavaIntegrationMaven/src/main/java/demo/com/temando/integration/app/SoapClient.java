/*
 * This SoapClient class demonstrates how to invoke the getQuotes webservice on Temando API 
 */

package demo.com.temando.integration.app;

import java.math.BigDecimal;
import java.util.HashMap;
import java.util.Map;

import org.apache.cxf.endpoint.Client;
import org.apache.cxf.endpoint.Endpoint;
import org.apache.cxf.frontend.ClientProxy;
import org.apache.cxf.interceptor.LoggingOutInterceptor;
import org.apache.cxf.ws.security.wss4j.WSS4JOutInterceptor;
import org.apache.wss4j.dom.WSConstants;
import org.apache.wss4j.dom.handler.WSHandlerConstants;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import demo.com.temando.api.Anything;
import demo.com.temando.api.Anytime;
import demo.com.temando.api.Anywhere;
import demo.com.temando.api.Class;
import demo.com.temando.api.CurrencyType;
import demo.com.temando.api.DeliveryNature;
import demo.com.temando.api.DeliveryType;
import demo.com.temando.api.DistanceMeasurementType;
import demo.com.temando.api.General;
import demo.com.temando.api.GetQuotes;
import demo.com.temando.api.GetQuotes.Anythings;
import demo.com.temando.api.GetQuotesResponse;
import demo.com.temando.api.LocationType;
import demo.com.temando.api.Packaging;
import demo.com.temando.api.QuotingPortType;
import demo.com.temando.api.QuotingService;
import demo.com.temando.api.ReadyTime;
import demo.com.temando.api.WeightMeasurementType;
import demo.com.temando.api.YesNoOption;
import demo.com.temando.integration.ClientPasswordCallback;
import demo.com.temando.integration.ConfigUtil;

public class SoapClient {
	private static final Logger LOGGER = LoggerFactory
			.getLogger(SoapClient.class);

	public static void main(String[] args) {
		try {
			QuotingService service = new QuotingService();
			QuotingPortType port = service.getQuotingPort();

			// Get endpoint
			Client client = ClientProxy.getClient(port);
			Endpoint cxfEndpoint = client.getEndpoint();

			// Prepare header data
			Map<String, Object> outProps = new HashMap<String, Object>();
			outProps.put(WSHandlerConstants.ACTION,
					WSHandlerConstants.USERNAME_TOKEN);
			outProps.put(WSHandlerConstants.PASSWORD_TYPE, WSConstants.PW_TEXT);
			outProps.put(WSHandlerConstants.USER,
					ConfigUtil.getUsernameTokenUsername());
			outProps.put(WSHandlerConstants.MUST_UNDERSTAND,
					Boolean.toString(false));
			outProps.put(WSHandlerConstants.PW_CALLBACK_CLASS,
					ClientPasswordCallback.class.getName());

			// Attach header data to interceptor, which is then added to
			// endpoint
			WSS4JOutInterceptor wssOut = new WSS4JOutInterceptor(outProps);
			cxfEndpoint.getOutInterceptors().add(wssOut);

			// Setup logging interceptor to log request (for debugging)
			LoggingOutInterceptor loggingOutInterceptor = new LoggingOutInterceptor();
			loggingOutInterceptor.setPrettyLogging(true);
			cxfEndpoint.getOutInterceptors().add(loggingOutInterceptor);

			// Prepare web service body contents
			Anything anything = new Anything();
			anything.setClazz(Class.GENERAL_GOODS);
			anything.setSubclass("Household Goods");
			anything.setPackaging(Packaging.BOX);
			anything.setQualifierFreightGeneralFragile(YesNoOption.N);
			anything.setDistanceMeasurementType(DistanceMeasurementType.CENTIMETRES);
			anything.setWeightMeasurementType(WeightMeasurementType.GRAMS);
			anything.setLength(5);
			anything.setWidth(3);
			anything.setHeight(4);
			anything.setWeight(5000);
			anything.setQuantity(2);

			Anythings anythings = new Anythings();
			anythings.getAnything().add(anything);

			Anywhere anywhere = new Anywhere();
			anywhere.setItemNature(DeliveryNature.DOMESTIC);
			anywhere.setItemMethod(DeliveryType.DOOR_TO_DOOR);
			anywhere.setOriginCountry("AU");
			anywhere.setOriginCode("4069");
			anywhere.setOriginSuburb("KENMORE");
			anywhere.setOriginIs(LocationType.BUSINESS);
			anywhere.setOriginBusUnattended(YesNoOption.N);
			anywhere.setOriginBusDock(YesNoOption.N);
			anywhere.setOriginBusForklift(YesNoOption.N);
			anywhere.setOriginBusLoadingFacilities(YesNoOption.N);
			anywhere.setOriginBusInside(YesNoOption.N);
			anywhere.setOriginBusNotifyBefore(YesNoOption.N);
			anywhere.setOriginBusLimitedAccess(YesNoOption.N);
			anywhere.setOriginBusHeavyLift(YesNoOption.N);
			anywhere.setOriginBusTailgateLifter(YesNoOption.N);
			anywhere.setOriginBusContainerSwingLifter(YesNoOption.N);

			anywhere.setDestinationCountry("AU");
			anywhere.setDestinationCode("4000");
			anywhere.setDestinationSuburb("BRISBANE");
			anywhere.setDestinationIs(LocationType.BUSINESS);
			anywhere.setDestinationBusUnattended(YesNoOption.N);
			anywhere.setDestinationBusDock(YesNoOption.N);
			anywhere.setDestinationBusForklift(YesNoOption.N);
			anywhere.setDestinationBusLoadingFacilities(YesNoOption.N);
			anywhere.setDestinationBusInside(YesNoOption.N);
			anywhere.setDestinationBusNotifyBefore(YesNoOption.N);
			anywhere.setDestinationBusLimitedAccess(YesNoOption.N);
			anywhere.setDestinationBusHeavyLift(YesNoOption.N);
			anywhere.setDestinationBusTailgateLifter(YesNoOption.N);
			anywhere.setDestinationBusContainerSwingLifter(YesNoOption.N);

			Anytime anytime = new Anytime();
			anytime.setReadyDate("2018-12-10");
			anytime.setReadyTime(ReadyTime.PM);

			General general = new General();
			general.setGoodsValue(new BigDecimal(5));
			general.setGoodsCurrency(CurrencyType.AUD);

			GetQuotes getQuotes = new GetQuotes();
			getQuotes.setAnythings(anythings);
			getQuotes.setAnywhere(anywhere);
			getQuotes.setAnytime(anytime);
			getQuotes.setGeneral(general);
			getQuotes.setClientId(20420);

			// Invoke web service
			GetQuotesResponse response = port.getQuotes(getQuotes);
			int numOfQuotes = response.getQuotes().getQuote().size();
			
			LOGGER.info("Found " + numOfQuotes + " quotes");
			LOGGER.info("RESPONSE: [" + response.toString() + "]");			
		} catch (Exception e) {
			LOGGER.error("An exception occurred, exiting", e);
		}
	}
}
