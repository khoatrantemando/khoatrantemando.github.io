
package demo.com.temando.api;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for QuotePreference.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * <p>
 * <pre>
 * &lt;simpleType name="QuotePreference">
 *   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *     &lt;enumeration value="Custom"/>
 *     &lt;enumeration value="Cheapest"/>
 *     &lt;enumeration value="Carriers Only"/>
 *     &lt;enumeration value="Carrier Order"/>
 *   &lt;/restriction>
 * &lt;/simpleType>
 * </pre>
 * 
 */
@XmlType(name = "QuotePreference", namespace = "http://api-demo.temando.com/schema/2009_06/common.xsd")
@XmlEnum
public enum QuotePreference {

    @XmlEnumValue("Custom")
    CUSTOM("Custom"),
    @XmlEnumValue("Cheapest")
    CHEAPEST("Cheapest"),
    @XmlEnumValue("Carriers Only")
    CARRIERS_ONLY("Carriers Only"),
    @XmlEnumValue("Carrier Order")
    CARRIER_ORDER("Carrier Order");
    private final String value;

    QuotePreference(String v) {
        value = v;
    }

    public String value() {
        return value;
    }

    public static QuotePreference fromValue(String v) {
        for (QuotePreference c: QuotePreference.values()) {
            if (c.value.equals(v)) {
                return c;
            }
        }
        throw new IllegalArgumentException(v);
    }

}
