<?php

require_once('temando.php');
$obj_tem = new TemandoWebServices;

$username = 'temandotest';
$password = 'password';
$endpoint = 'http://training-api.temando.com/schema/2009_06/server.wsdl';

$request = array ( 'anythings' => array ( 'anything' => array ( 0 => array ('class' => 'General Goods', 
																			'subclass' => 'Household Goods',
																			'packaging' => 'Box',
																			'qualifierFreightGeneralFragile' => 'N',
																			'weight' => 5000,
																			'length' => 2,
																			'width' => 3,
																			'height' => 4,
																			'distanceMeasurementType' => 'Centimetres',
																			'weightMeasurementType' => 'Grams',
																			'quantity' => '1', ), ), ),
					'anywhere' => array ( 	'itemNature' => 'Domestic',
											'itemMethod' => 'Door to Door',
											'originCountry' => 'AU',
											'originCode' => '4069',
											'originSuburb' => 'KENMORE', 
											'originIs' => 'Business', 
											'originBusDock' => 'N', 
											'originBusUnattended' => 'N', 
											'originBusForklift' => 'N', 
											'originBusLoadingFacilities' => 'N', 
											'originBusInside' => 'N', 
											'originBusNotifyBefore' => 'N',
											'originBusLimitedAccess' => 'N', 
											'originBusHeavyLift' => 'N', 
											'originBusContainerSwingLifter' => 'N', 
											'originBusTailgateLifter' => 'N', 
											'destinationCountry' => 'AU', 
											'destinationCode' => '4000', 
											'destinationSuburb' => 'BRISBANE', 
											'destinationIs' => 'Business', 
											'destinationBusDock' => 'N', 
											'destinationBusPostalBox' => 'N', 
											'destinationBusUnattended' => 'N', 
											'destinationBusForklift' => 'N', 
											'destinationBusLoadingFacilities' => 'N', 
											'destinationBusInside' => 'N', 
											'destinationBusNotifyBefore' => 'N', 
											'destinationBusLimitedAccess' => 'N', 
											'destinationBusHeavyLift' => 'N', 
											'destinationBusContainerSwingLifter' => 'N', 
											'destinationBusTailgateLifter' => 'N', ), 
						'anytime' => array ('readyDate' => '2012-08-29', 
											'readyTime' => 'PM', ),
						'clientId' => '16942', 
						'promotionCode' => 'A0001', 
						'general' => array ( 'goodsValue' => 5,
											 'goodsCurrency' => 'AUD', ), );
				
$response = $obj_tem->getQuotesByRequest($request,$username,$password,$endpoint);

echo '<PRE>';
print_r($response);

?>