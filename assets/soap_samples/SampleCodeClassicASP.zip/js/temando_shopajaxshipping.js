﻿function temandotracking(ooid,tid) {
    document.getElementById(ooid).innerHTML = "<img src='images/ajaxshippingload.gif' border='0'>checking...";
    var checkingurl="temando_tracking_ajax.asp";
	 
    var pars = 'oid='+ooid+'&trackID='+tid+'';
    var target = ''+ooid+'';
    var myAjax = new Ajax.Updater(target, checkingurl, {method: 'post',parameters: pars});
}

function updateshippingmethodtemando(isnew) {
	if (document.getElementById('withinsurance').checked==true)
	{
		var withinsurance='1'
	}
	else
	{
		var withinsurance='0'
	}
	
	
	if (document.getElementById('withcarbon').checked==true)
	{
		var withcarbon='1'
	}
	else
	{
		var withcarbon='0'
	}
	
	  var pars = 'fromcheckbox=Yes&withinsurance='+withinsurance+'&withcarbon='+withcarbon+'&inscar=1&new='+isnew+'';
      document.getElementById("selresultlist").innerHTML="<img src='images/ajaxshippingload.gif' border='0'> checking availability...";
     
	  var checkingurl="shopTemandoshippingajaxupdate.asp";
     
      var target = 'selresultlist';
      var myAjax = new Ajax.Updater(target, checkingurl, {method: 'post',parameters: pars});
}

function updateshippingmethodtemandononajax(isnew) {
	if (document.getElementById('withinsurance').checked==true)
	{
		var withinsurance='1'
	}
	else
	{
		var withinsurance='0'
	}
	
	if (document.getElementById('withcarbon').checked==true)
	{
		var withcarbon='1'
	}
	else
	{
		var withcarbon='0'
	}
 var pars = 'withinsurance='+withinsurance+'&withcarbon='+withcarbon+'&inscar=1&new='+isnew+'';
      document.getElementById("selresultlist").innerHTML="<img src='images/ajaxshippingload.gif' border='0'> checking availability...";
		var checkingurl="shopTemandoshippingupdate.asp";
      var target = 'selresultlist';
      var myAjax = new Ajax.Updater(target, checkingurl, {method: 'post',parameters: pars});

}
function removeestimatedshipping() {
    var browserName=navigator.appName;
	if (browserName=="Microsoft Internet Explorer")
	{
      document.getElementsByTagName("estshippingcost").innerHTML="";
	  document.getElementsByTagName("estshippingcosttotal").innerHTML="";
	}
	else
	{   
      document.getElementById("estshippingcost").innerHTML="";
	  document.getElementById("estshippingcosttotal").innerHTML="";
	}
	
      var checkingurl="shopTemandoshippingupdate.asp";
      var pars = 'removeestshipping=1';
      var url = checkingurl + '?' + pars;
      var target = 'estshippingcost';
      var myAjax = new Ajax.Updater(target, url, {method: 'post',parameters: pars});
	  getestimatedshippingtotal();
}

function getestimatedshipping() {
    //for onepage checkout only
    var browserName=navigator.appName;
	if (browserName=="Microsoft Internet Explorer")
	{
	   if (document.getElementsByTagName("totalafterdiscount")){
	      document.getElementsByTagName("totalafterdiscount").innerHTML="";
	   }
	   if (document.getElementsByTagName("discountresultgiftcert")){
	      document.getElementsByTagName("discountresultgiftcert").innerHTML="";
	   }
		
       settoempty('estshippingcosttotal');
       settoloading('estshippingcost');
	}
	else
	{   
	   if (document.getElementById("totalafterdiscount")){
	      document.getElementById("totalafterdiscount").innerHTML="";
	   }
	   if (document.getElementById("discountresultgiftcert")){
	      document.getElementById("discountresultgiftcert").innerHTML="";
	   }

		document.getElementById("estshippingcosttotal").innerHTML="";
		document.getElementById('estshippingcost').innerHTML ="<td>&nbsp;</td><td>&nbsp;</td><td colspan=3><img src='images/ajaxshippingload.gif' border='0'> checking availability...</td>";
	}

	var pars = 'estimated=1&estshipcountry='+document.getElementById('shipcountry').value+'&estpostcode='+document.getElementById('estpostcode').value+'&withinsurance=1&withcarbon=0&inscar=1';
	var checkingurl="shopTemandoshippingupdate.asp";
	var target = 'estshippingcost';
	var myAjax = new Ajax.Updater(target, checkingurl, {method: 'post',parameters: pars});
	if (document.getElementById('shipcountry').value != '' && document.getElementById('estpostcode').value != '') {setTimeout('getestimatedshippingtotal()',100);}
	
	return false;
}

function getestimatedshippingtotal() {
	var pars = 'ptype=getestimatetotal';
	var checkingurl="shopTemandoshippingupdate.asp";
	var target = 'estshippingcosttotal';
	var myAjax = new Ajax.Updater(target, checkingurl, {method: 'post',parameters: pars});
	
	//onepagecheckout
	if (document.getElementById("discountresultgiftcert")){
	   displayinfo('giftcert','discountresultgiftcert');
	}
}

function settoempty(divid) {
	var pars = 'ptype=settoempty';
	var checkingurl="shopTemandoshippingupdate.asp";
	var target = divid;
	var myAjax = new Ajax.Updater(target, checkingurl, {method: 'post',parameters: pars});
}

function settoloading(divid) {
	var pars = 'ptype=settoloading';
	var checkingurl="shopTemandoshippingupdate.asp";
	var target = divid;
	var myAjax = new Ajax.Updater(target, checkingurl, {method: 'post',parameters: pars});
}

function updatezipcodecountryajax_temando(form,isnew) {
 	  if (form.copy.checked == false) {
      document.getElementById("selresultlist").innerHTML="<img src='images/ajaxshippingload.gif' border='0'> checking availability...";
      document.getElementById('Action').disabled = true;
      var checkingurl="shopajaxshippingzipcodecountry_temando.asp";
      var pars = 'zipcode=' + form.strpostcode.value + '&country=' + form.strcountry.value +'&new='+isnew+'&town='+document.getElementById('strcity').value+'';
	  var url = checkingurl + '?' + pars;
      var target = 'selresultlist';
      var myAjax = new Ajax.Updater(target, checkingurl, {method: 'post',parameters: pars});
      document.getElementById('Action').disabled = false;
   }
}

function updateshipzipcodecountryajax_temando(form,isnew) {
   if (form.shipcountry.value.length != 0) {
   document.getElementById("selresultlist").innerHTML="<img src='images/ajaxshippingload.gif' border='0'> checking availability...";
   document.getElementById('Action').disabled = true;
   var checkingurl="shopajaxshippingzipcodecountry_temando.asp";
   var pars = 'zipcode=' + form.shipzip.value + '&country=' + form.shipcountry.value +'&new='+isnew+'&town='+ encodeURI(escape(form.shiptown.value)) +'';
   var url = checkingurl + '?' + pars;
   var target = 'selresultlist';
   var myAjax = new Ajax.Updater(target, checkingurl, {method: 'post',parameters: pars});
   document.getElementById('Action').disabled = false;
   }
   else {
	   updatezipcodestrcountryajax_temando(form,isnew);
   }
}

function updatezipcodestrcountryajax_temando(form,isnew) {
   if (form.strcountry.value.length != 0) {
      document.getElementById("selresultlist").innerHTML="<img src='images/ajaxshippingload.gif' border='0'> checking availability...";
      document.getElementById('Action').disabled = true;
      var checkingurl="shopajaxshippingzipcodecountry_temando.asp";
      var pars = 'zipcode=' + form.strpostcode.value + '&country=' + form.strcountry.value +'&town=' + encodeURI(escape(form.strcity.value)) +'&new='+isnew+'';
      var url = checkingurl + '?' + pars;
      var target = 'selresultlist';
      var myAjax = new Ajax.Updater(target, checkingurl, {method: 'post',parameters: pars});
      document.getElementById('Action').disabled = false;
   }
}

function getzipinfo(form,formname,divid) {
      var checkingurl="shop_temandopostajax.asp";
	  var postcodetype
	  if (formname =='customerform')
		  {
			  var pars = 'zipcode=' + form.strpostcode.value + '&country=' + form.strcountry.value +'&town=' + encodeURI(escape(form.strcity.value)) +'&state=' + form.strstate.value +'&formname='+formname+'';
		  }
	  else
		  {  
			  var pars = 'zipcode='+document.getElementById('shipzip').value+'&formname='+formname+'';
	      }
	  var target = divid;
	  var url = checkingurl + '?' + pars;

new Ajax.Request(url,
  {
    method:'post',
    onSuccess: function(transport){
		var  pstring = transport.responseText;
		document.getElementById(divid).innerHTML=pstring;
	   if (formname =='customerform') {
		 if (form.copy.checked == false) {
         var isnew = 'Yes';
         document.getElementById("selresultlist").innerHTML="<img src='images/ajaxshippingload.gif' border='0'> checking availability...";
         document.getElementById('Action').disabled = true;
         var checkingurl="shopajaxshippingzipcodecountry_temando.asp";
         var pars = 'zipcode=' + form.strpostcode.value + '&country=' + form.strcountry.value +'&town=' + encodeURI(escape(form.strcity.value)) +'&new='+isnew+''; 
		 var url = checkingurl + '?' + pars;
         var target = 'selresultlist';
         var myAjax = new Ajax.Updater(target, checkingurl, {method: 'post',parameters: pars});
         document.getElementById('Action').disabled = false;
	     }
	}
	else
	{ 
         var isnew = 'Yes';
         document.getElementById("selresultlist").innerHTML="<img src='images/ajaxshippingload.gif' border='0'> checking availability...";
         var checkingurl="shopajaxshippingzipcodecountry_temando.asp";
		 var pars = 'zipcode=' + form.shipzip.value + '&country=' + form.shipcountry.value +'&town=' + encodeURI(escape(form.shiptown.value)) +'&new='+isnew+''; 
		 var url = checkingurl + '?' + pars;
         var target = 'selresultlist';
         var myAjax = new Ajax.Updater(target, checkingurl, {method: 'post',parameters: pars});
	  }
    },
    onFailure: function(){ alert('Something went wrong...') }
  });
}

function updatebilltoshipcitystatecountry(form) {
   if (form.copy.checked) {
      var checkingurl="shop_temandopostajax.asp";
      var pars = 'ptype=billtoship&zipcode=' + form.strpostcode.value + '&country=' + form.strcountry.value +'&town=' + encodeURI(escape(form.strcity.value)) +'&state=' + form.strstate.value +'&formname=shippingform';
      var url = checkingurl + '?' + pars;
      var target = 'temandozipinfoshipping';
      var myAjax = new Ajax.Updater(target, checkingurl, {method: 'post',parameters: pars});
      document.getElementById('Action').disabled = false;
   }
   else {
	   document.getElementById("temandozipinfoshipping").innerHTML="<input type='hidden' name='shiptown' id='shiptown' value=''><input type='hidden' name='shipstate' id='shipstate' value=''><input type='hidden' name='shipcountry' id='shipcountry' value=''>"
   }
}

function EnableShippingOtherFields(form) {
   if (form.copy.checked) {
      document.getElementById('shippingformotherfields').style.display = 'block';
   }
   else {
      document.getElementById('shippingformotherfields').style.display = 'none';
   }
}