
package demo.com.temando.api;

import java.math.BigDecimal;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for General complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="General">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;all>
 *         &lt;element name="goodsValue" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}CurrencyAmount" minOccurs="0"/>
 *         &lt;element name="goodsCurrency" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}CurrencyType" minOccurs="0"/>
 *         &lt;element name="externalInsuranceValue" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}CurrencyAmount" minOccurs="0"/>
 *         &lt;element name="externalInsuranceCurrency" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}CurrencyType" minOccurs="0"/>
 *         &lt;element name="termsOfTrade" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}TermsOfTrade" minOccurs="0"/>
 *       &lt;/all>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "General", namespace = "http://api-demo.temando.com/schema/2009_06/common.xsd", propOrder = {

})
public class General {

    protected BigDecimal goodsValue;
    protected CurrencyType goodsCurrency;
    protected BigDecimal externalInsuranceValue;
    protected CurrencyType externalInsuranceCurrency;
    protected TermsOfTrade termsOfTrade;

    /**
     * Gets the value of the goodsValue property.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getGoodsValue() {
        return goodsValue;
    }

    /**
     * Sets the value of the goodsValue property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setGoodsValue(BigDecimal value) {
        this.goodsValue = value;
    }

    /**
     * Gets the value of the goodsCurrency property.
     * 
     * @return
     *     possible object is
     *     {@link CurrencyType }
     *     
     */
    public CurrencyType getGoodsCurrency() {
        return goodsCurrency;
    }

    /**
     * Sets the value of the goodsCurrency property.
     * 
     * @param value
     *     allowed object is
     *     {@link CurrencyType }
     *     
     */
    public void setGoodsCurrency(CurrencyType value) {
        this.goodsCurrency = value;
    }

    /**
     * Gets the value of the externalInsuranceValue property.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getExternalInsuranceValue() {
        return externalInsuranceValue;
    }

    /**
     * Sets the value of the externalInsuranceValue property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setExternalInsuranceValue(BigDecimal value) {
        this.externalInsuranceValue = value;
    }

    /**
     * Gets the value of the externalInsuranceCurrency property.
     * 
     * @return
     *     possible object is
     *     {@link CurrencyType }
     *     
     */
    public CurrencyType getExternalInsuranceCurrency() {
        return externalInsuranceCurrency;
    }

    /**
     * Sets the value of the externalInsuranceCurrency property.
     * 
     * @param value
     *     allowed object is
     *     {@link CurrencyType }
     *     
     */
    public void setExternalInsuranceCurrency(CurrencyType value) {
        this.externalInsuranceCurrency = value;
    }

    /**
     * Gets the value of the termsOfTrade property.
     * 
     * @return
     *     possible object is
     *     {@link TermsOfTrade }
     *     
     */
    public TermsOfTrade getTermsOfTrade() {
        return termsOfTrade;
    }

    /**
     * Sets the value of the termsOfTrade property.
     * 
     * @param value
     *     allowed object is
     *     {@link TermsOfTrade }
     *     
     */
    public void setTermsOfTrade(TermsOfTrade value) {
        this.termsOfTrade = value;
    }

}
