
package demo.com.temando.api;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for PalletType.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * <p>
 * <pre>
 * &lt;simpleType name="PalletType">
 *   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *     &lt;enumeration value="Chep"/>
 *     &lt;enumeration value="Loscam"/>
 *     &lt;enumeration value="Plain"/>
 *     &lt;enumeration value="Not Required"/>
 *   &lt;/restriction>
 * &lt;/simpleType>
 * </pre>
 * 
 */
@XmlType(name = "PalletType", namespace = "http://api-demo.temando.com/schema/2009_06/common.xsd")
@XmlEnum
public enum PalletType {

    @XmlEnumValue("Chep")
    CHEP("Chep"),
    @XmlEnumValue("Loscam")
    LOSCAM("Loscam"),
    @XmlEnumValue("Plain")
    PLAIN("Plain"),
    @XmlEnumValue("Not Required")
    NOT_REQUIRED("Not Required");
    private final String value;

    PalletType(String v) {
        value = v;
    }

    public String value() {
        return value;
    }

    public static PalletType fromValue(String v) {
        for (PalletType c: PalletType.values()) {
            if (c.value.equals(v)) {
                return c;
            }
        }
        throw new IllegalArgumentException(v);
    }

}
