
package demo.com.temando.api;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlElementDecl;
import javax.xml.bind.annotation.XmlRegistry;
import javax.xml.namespace.QName;


/**
 * This object contains factory methods for each 
 * Java content interface and Java element interface 
 * generated in the com.temando.api package. 
 * <p>An ObjectFactory allows you to programatically 
 * construct new instances of the Java representation 
 * for XML content. The Java representation of XML 
 * content can consist of schema derived interfaces 
 * and classes representing the binding of schema 
 * type definitions, element declarations and model 
 * groups.  Factory methods for each of these are 
 * provided in this class.
 * 
 */
@XmlRegistry
public class ObjectFactory {

    private final static QName _UpdateTrackingDetailsResponse_QNAME = new QName("http://api-demo.temando.com/schema/2009_06/server.xsd", "updateTrackingDetailsResponse");
    private final static QName _UpdateLocationResponse_QNAME = new QName("http://api-demo.temando.com/schema/2009_06/server.xsd", "updateLocationResponse");
    private final static QName _CreateLocationResponse_QNAME = new QName("http://api-demo.temando.com/schema/2009_06/server.xsd", "createLocationResponse");
    private final static QName _CreateItemResponse_QNAME = new QName("http://api-demo.temando.com/schema/2009_06/server.xsd", "createItemResponse");
    private final static QName _CancelRequestResponse_QNAME = new QName("http://api-demo.temando.com/schema/2009_06/server.xsd", "cancelRequestResponse");
    private final static QName _CreateZoneResponse_QNAME = new QName("http://api-demo.temando.com/schema/2009_06/server.xsd", "createZoneResponse");
    private final static QName _UpdateZoneResponse_QNAME = new QName("http://api-demo.temando.com/schema/2009_06/server.xsd", "updateZoneResponse");
    private final static QName _AddBookingDetailsResponse_QNAME = new QName("http://api-demo.temando.com/schema/2009_06/server.xsd", "addBookingDetailsResponse");
    private final static QName _UpdateItemResponse_QNAME = new QName("http://api-demo.temando.com/schema/2009_06/server.xsd", "updateItemResponse");
    private final static QName _GetRequestsRequiringBooking_QNAME = new QName("http://api-demo.temando.com/schema/2009_06/server.xsd", "getRequestsRequiringBooking");
    private final static QName _LodgeDispatchResponse_QNAME = new QName("http://api-demo.temando.com/schema/2009_06/server.xsd", "lodgeDispatchResponse");
    private final static QName _UpdatePackagingResponse_QNAME = new QName("http://api-demo.temando.com/schema/2009_06/server.xsd", "updatePackagingResponse");
    private final static QName _CreatePackagingResponse_QNAME = new QName("http://api-demo.temando.com/schema/2009_06/server.xsd", "createPackagingResponse");
    private final static QName _UpdateClientResponse_QNAME = new QName("http://api-demo.temando.com/schema/2009_06/server.xsd", "updateClientResponse");

    /**
     * Create a new ObjectFactory that can be used to create new instances of schema derived classes for package: com.temando.api
     * 
     */
    public ObjectFactory() {
    }

    /**
     * Create an instance of {@link GetLocationsResponse }
     * 
     */
    public GetLocationsResponse createGetLocationsResponse() {
        return new GetLocationsResponse();
    }

    /**
     * Create an instance of {@link GetCarriersResponse }
     * 
     */
    public GetCarriersResponse createGetCarriersResponse() {
        return new GetCarriersResponse();
    }

    /**
     * Create an instance of {@link ConfirmManifestResponse }
     * 
     */
    public ConfirmManifestResponse createConfirmManifestResponse() {
        return new ConfirmManifestResponse();
    }

    /**
     * Create an instance of {@link GetItemsResponse }
     * 
     */
    public GetItemsResponse createGetItemsResponse() {
        return new GetItemsResponse();
    }

    /**
     * Create an instance of {@link GetQuotesResponse }
     * 
     */
    public GetQuotesResponse createGetQuotesResponse() {
        return new GetQuotesResponse();
    }

    /**
     * Create an instance of {@link MakeBookingByRequest }
     * 
     */
    public MakeBookingByRequest createMakeBookingByRequest() {
        return new MakeBookingByRequest();
    }

    /**
     * Create an instance of {@link MakeBooking }
     * 
     */
    public MakeBooking createMakeBooking() {
        return new MakeBooking();
    }

    /**
     * Create an instance of {@link GetQuotes }
     * 
     */
    public GetQuotes createGetQuotes() {
        return new GetQuotes();
    }

    /**
     * Create an instance of {@link GetPackagingsResponse }
     * 
     */
    public GetPackagingsResponse createGetPackagingsResponse() {
        return new GetPackagingsResponse();
    }

    /**
     * Create an instance of {@link MakeBookingResponse }
     * 
     */
    public MakeBookingResponse createMakeBookingResponse() {
        return new MakeBookingResponse();
    }

    /**
     * Create an instance of {@link MakeBookingByRequestResponse }
     * 
     */
    public MakeBookingByRequestResponse createMakeBookingByRequestResponse() {
        return new MakeBookingByRequestResponse();
    }

    /**
     * Create an instance of {@link GetZonesResponse }
     * 
     */
    public GetZonesResponse createGetZonesResponse() {
        return new GetZonesResponse();
    }

    /**
     * Create an instance of {@link GetMultipleRequests }
     * 
     */
    public GetMultipleRequests createGetMultipleRequests() {
        return new GetMultipleRequests();
    }

    /**
     * Create an instance of {@link UpdateRequest }
     * 
     */
    public UpdateRequest createUpdateRequest() {
        return new UpdateRequest();
    }

    /**
     * Create an instance of {@link GetQuotesByRequest }
     * 
     */
    public GetQuotesByRequest createGetQuotesByRequest() {
        return new GetQuotesByRequest();
    }

    /**
     * Create an instance of {@link GetManifestResponse }
     * 
     */
    public GetManifestResponse createGetManifestResponse() {
        return new GetManifestResponse();
    }

    /**
     * Create an instance of {@link Location }
     * 
     */
    public Location createLocation() {
        return new Location();
    }

    /**
     * Create an instance of {@link Anything }
     * 
     */
    public Anything createAnything() {
        return new Anything();
    }

    /**
     * Create an instance of {@link CarrierPreference }
     * 
     */
    public CarrierPreference createCarrierPreference() {
        return new CarrierPreference();
    }

    /**
     * Create an instance of {@link AvailableQuote }
     * 
     */
    public AvailableQuote createAvailableQuote() {
        return new AvailableQuote();
    }

    /**
     * Create an instance of {@link Request }
     * 
     */
    public Request createRequest() {
        return new Request();
    }

    /**
     * Create an instance of {@link BookingQuote }
     * 
     */
    public BookingQuote createBookingQuote() {
        return new BookingQuote();
    }

    /**
     * Create an instance of {@link QuoteFilter }
     * 
     */
    public QuoteFilter createQuoteFilter() {
        return new QuoteFilter();
    }

    /**
     * Create an instance of {@link Zone }
     * 
     */
    public Zone createZone() {
        return new Zone();
    }

    /**
     * Create an instance of {@link Item }
     * 
     */
    public Item createItem() {
        return new Item();
    }

    /**
     * Create an instance of {@link Extra }
     * 
     */
    public Extra createExtra() {
        return new Extra();
    }

    /**
     * Create an instance of {@link Payment }
     * 
     */
    public Payment createPayment() {
        return new Payment();
    }

    /**
     * Create an instance of {@link Manifest }
     * 
     */
    public Manifest createManifest() {
        return new Manifest();
    }

    /**
     * Create an instance of {@link Adjustment }
     * 
     */
    public Adjustment createAdjustment() {
        return new Adjustment();
    }

    /**
     * Create an instance of {@link Inclusion }
     * 
     */
    public Inclusion createInclusion() {
        return new Inclusion();
    }

    /**
     * Create an instance of {@link LocationZone }
     * 
     */
    public LocationZone createLocationZone() {
        return new LocationZone();
    }

    /**
     * Create an instance of {@link Client }
     * 
     */
    public Client createClient() {
        return new Client();
    }

    /**
     * Create an instance of {@link Anywhere }
     * 
     */
    public Anywhere createAnywhere() {
        return new Anywhere();
    }

    /**
     * Create an instance of {@link Article }
     * 
     */
    public Article createArticle() {
        return new Article();
    }

    /**
     * Create an instance of {@link PackagingPreference }
     * 
     */
    public PackagingPreference createPackagingPreference() {
        return new PackagingPreference();
    }

    /**
     * Create an instance of {@link Depot }
     * 
     */
    public Depot createDepot() {
        return new Depot();
    }

    /**
     * Create an instance of {@link Carrier }
     * 
     */
    public Carrier createCarrier() {
        return new Carrier();
    }

    /**
     * Create an instance of {@link DispatchDetails }
     * 
     */
    public DispatchDetails createDispatchDetails() {
        return new DispatchDetails();
    }

    /**
     * Create an instance of {@link LoginDetails }
     * 
     */
    public LoginDetails createLoginDetails() {
        return new LoginDetails();
    }

    /**
     * Create an instance of {@link General }
     * 
     */
    public General createGeneral() {
        return new General();
    }

    /**
     * Create an instance of {@link ItemStock }
     * 
     */
    public ItemStock createItemStock() {
        return new ItemStock();
    }

    /**
     * Create an instance of {@link TrackingHistory }
     * 
     */
    public TrackingHistory createTrackingHistory() {
        return new TrackingHistory();
    }

    /**
     * Create an instance of {@link ZoneRange }
     * 
     */
    public ZoneRange createZoneRange() {
        return new ZoneRange();
    }

    /**
     * Create an instance of {@link Documents }
     * 
     */
    public Documents createDocuments() {
        return new Documents();
    }

    /**
     * Create an instance of {@link ResponseExclusions }
     * 
     */
    public ResponseExclusions createResponseExclusions() {
        return new ResponseExclusions();
    }

    /**
     * Create an instance of {@link Anytime }
     * 
     */
    public Anytime createAnytime() {
        return new Anytime();
    }

    /**
     * Create an instance of {@link HandlingEquipment }
     * 
     */
    public HandlingEquipment createHandlingEquipment() {
        return new HandlingEquipment();
    }

    /**
     * Create an instance of {@link GetManifest }
     * 
     */
    public GetManifest createGetManifest() {
        return new GetManifest();
    }

    /**
     * Create an instance of {@link ConfirmManifest }
     * 
     */
    public ConfirmManifest createConfirmManifest() {
        return new ConfirmManifest();
    }

    /**
     * Create an instance of {@link CreatePackaging }
     * 
     */
    public CreatePackaging createCreatePackaging() {
        return new CreatePackaging();
    }

    /**
     * Create an instance of {@link UpdateItem }
     * 
     */
    public UpdateItem createUpdateItem() {
        return new UpdateItem();
    }

    /**
     * Create an instance of {@link CreateClientResponse }
     * 
     */
    public CreateClientResponse createCreateClientResponse() {
        return new CreateClientResponse();
    }

    /**
     * Create an instance of {@link GetLocationsResponse.Locations }
     * 
     */
    public GetLocationsResponse.Locations createGetLocationsResponseLocations() {
        return new GetLocationsResponse.Locations();
    }

    /**
     * Create an instance of {@link GetLocations }
     * 
     */
    public GetLocations createGetLocations() {
        return new GetLocations();
    }

    /**
     * Create an instance of {@link GetCarriersResponse.Linked }
     * 
     */
    public GetCarriersResponse.Linked createGetCarriersResponseLinked() {
        return new GetCarriersResponse.Linked();
    }

    /**
     * Create an instance of {@link GetCarriersResponse.Adhoc }
     * 
     */
    public GetCarriersResponse.Adhoc createGetCarriersResponseAdhoc() {
        return new GetCarriersResponse.Adhoc();
    }

    /**
     * Create an instance of {@link ConfirmManifestResponse.Requests }
     * 
     */
    public ConfirmManifestResponse.Requests createConfirmManifestResponseRequests() {
        return new ConfirmManifestResponse.Requests();
    }

    /**
     * Create an instance of {@link ConfirmManifestResponse.Manifests }
     * 
     */
    public ConfirmManifestResponse.Manifests createConfirmManifestResponseManifests() {
        return new ConfirmManifestResponse.Manifests();
    }

    /**
     * Create an instance of {@link GetItemsResponse.Items }
     * 
     */
    public GetItemsResponse.Items createGetItemsResponseItems() {
        return new GetItemsResponse.Items();
    }

    /**
     * Create an instance of {@link GetQuotesResponse.Anythings }
     * 
     */
    public GetQuotesResponse.Anythings createGetQuotesResponseAnythings() {
        return new GetQuotesResponse.Anythings();
    }

    /**
     * Create an instance of {@link GetQuotesResponse.Quotes }
     * 
     */
    public GetQuotesResponse.Quotes createGetQuotesResponseQuotes() {
        return new GetQuotesResponse.Quotes();
    }

    /**
     * Create an instance of {@link MakeBookingByRequest.Anythings }
     * 
     */
    public MakeBookingByRequest.Anythings createMakeBookingByRequestAnythings() {
        return new MakeBookingByRequest.Anythings();
    }

    /**
     * Create an instance of {@link UpdateZone }
     * 
     */
    public UpdateZone createUpdateZone() {
        return new UpdateZone();
    }

    /**
     * Create an instance of {@link GetRequestsRequiringBookingResponse }
     * 
     */
    public GetRequestsRequiringBookingResponse createGetRequestsRequiringBookingResponse() {
        return new GetRequestsRequiringBookingResponse();
    }

    /**
     * Create an instance of {@link MakeBooking.Anythings }
     * 
     */
    public MakeBooking.Anythings createMakeBookingAnythings() {
        return new MakeBooking.Anythings();
    }

    /**
     * Create an instance of {@link MakeBooking.HandlingEquipments }
     * 
     */
    public MakeBooking.HandlingEquipments createMakeBookingHandlingEquipments() {
        return new MakeBooking.HandlingEquipments();
    }

    /**
     * Create an instance of {@link UpdateTrackingDetails }
     * 
     */
    public UpdateTrackingDetails createUpdateTrackingDetails() {
        return new UpdateTrackingDetails();
    }

    /**
     * Create an instance of {@link GetPackagings }
     * 
     */
    public GetPackagings createGetPackagings() {
        return new GetPackagings();
    }

    /**
     * Create an instance of {@link GetClientResponse }
     * 
     */
    public GetClientResponse createGetClientResponse() {
        return new GetClientResponse();
    }

    /**
     * Create an instance of {@link CreateLocation }
     * 
     */
    public CreateLocation createCreateLocation() {
        return new CreateLocation();
    }

    /**
     * Create an instance of {@link AddBookingDetails }
     * 
     */
    public AddBookingDetails createAddBookingDetails() {
        return new AddBookingDetails();
    }

    /**
     * Create an instance of {@link CancelRequest }
     * 
     */
    public CancelRequest createCancelRequest() {
        return new CancelRequest();
    }

    /**
     * Create an instance of {@link GetQuotes.Anythings }
     * 
     */
    public GetQuotes.Anythings createGetQuotesAnythings() {
        return new GetQuotes.Anythings();
    }

    /**
     * Create an instance of {@link LodgeDispatch }
     * 
     */
    public LodgeDispatch createLodgeDispatch() {
        return new LodgeDispatch();
    }

    /**
     * Create an instance of {@link GetPackagingsResponse.Packagings }
     * 
     */
    public GetPackagingsResponse.Packagings createGetPackagingsResponsePackagings() {
        return new GetPackagingsResponse.Packagings();
    }

    /**
     * Create an instance of {@link MakeBookingResponse.Anythings }
     * 
     */
    public MakeBookingResponse.Anythings createMakeBookingResponseAnythings() {
        return new MakeBookingResponse.Anythings();
    }

    /**
     * Create an instance of {@link MakeBookingResponse.Articles }
     * 
     */
    public MakeBookingResponse.Articles createMakeBookingResponseArticles() {
        return new MakeBookingResponse.Articles();
    }

    /**
     * Create an instance of {@link CreateZone }
     * 
     */
    public CreateZone createCreateZone() {
        return new CreateZone();
    }

    /**
     * Create an instance of {@link MakeBookingByRequestResponse.Anythings }
     * 
     */
    public MakeBookingByRequestResponse.Anythings createMakeBookingByRequestResponseAnythings() {
        return new MakeBookingByRequestResponse.Anythings();
    }

    /**
     * Create an instance of {@link MakeBookingByRequestResponse.Articles }
     * 
     */
    public MakeBookingByRequestResponse.Articles createMakeBookingByRequestResponseArticles() {
        return new MakeBookingByRequestResponse.Articles();
    }

    /**
     * Create an instance of {@link GetZonesResponse.Zones }
     * 
     */
    public GetZonesResponse.Zones createGetZonesResponseZones() {
        return new GetZonesResponse.Zones();
    }

    /**
     * Create an instance of {@link GetQuotesByRequestResponse }
     * 
     */
    public GetQuotesByRequestResponse createGetQuotesByRequestResponse() {
        return new GetQuotesByRequestResponse();
    }

    /**
     * Create an instance of {@link GetMultipleRequests.Requests }
     * 
     */
    public GetMultipleRequests.Requests createGetMultipleRequestsRequests() {
        return new GetMultipleRequests.Requests();
    }

    /**
     * Create an instance of {@link UpdateRequest.Anythings }
     * 
     */
    public UpdateRequest.Anythings createUpdateRequestAnythings() {
        return new UpdateRequest.Anythings();
    }

    /**
     * Create an instance of {@link UpdateRequest.Articles }
     * 
     */
    public UpdateRequest.Articles createUpdateRequestArticles() {
        return new UpdateRequest.Articles();
    }

    /**
     * Create an instance of {@link GetClient }
     * 
     */
    public GetClient createGetClient() {
        return new GetClient();
    }

    /**
     * Create an instance of {@link GetRequest }
     * 
     */
    public GetRequest createGetRequest() {
        return new GetRequest();
    }

    /**
     * Create an instance of {@link UpdateLocation }
     * 
     */
    public UpdateLocation createUpdateLocation() {
        return new UpdateLocation();
    }

    /**
     * Create an instance of {@link GetRequestResponse }
     * 
     */
    public GetRequestResponse createGetRequestResponse() {
        return new GetRequestResponse();
    }

    /**
     * Create an instance of {@link GetQuotesByRequest.Anythings }
     * 
     */
    public GetQuotesByRequest.Anythings createGetQuotesByRequestAnythings() {
        return new GetQuotesByRequest.Anythings();
    }

    /**
     * Create an instance of {@link UpdatePackaging }
     * 
     */
    public UpdatePackaging createUpdatePackaging() {
        return new UpdatePackaging();
    }

    /**
     * Create an instance of {@link GetManifestResponse.Requests }
     * 
     */
    public GetManifestResponse.Requests createGetManifestResponseRequests() {
        return new GetManifestResponse.Requests();
    }

    /**
     * Create an instance of {@link GetItems }
     * 
     */
    public GetItems createGetItems() {
        return new GetItems();
    }

    /**
     * Create an instance of {@link CreateItem }
     * 
     */
    public CreateItem createCreateItem() {
        return new CreateItem();
    }

    /**
     * Create an instance of {@link GetMultipleRequestsResponse }
     * 
     */
    public GetMultipleRequestsResponse createGetMultipleRequestsResponse() {
        return new GetMultipleRequestsResponse();
    }

    /**
     * Create an instance of {@link UpdateClient }
     * 
     */
    public UpdateClient createUpdateClient() {
        return new UpdateClient();
    }

    /**
     * Create an instance of {@link CreateClient }
     * 
     */
    public CreateClient createCreateClient() {
        return new CreateClient();
    }

    /**
     * Create an instance of {@link GetCarriers }
     * 
     */
    public GetCarriers createGetCarriers() {
        return new GetCarriers();
    }

    /**
     * Create an instance of {@link UpdateRequestResponse }
     * 
     */
    public UpdateRequestResponse createUpdateRequestResponse() {
        return new UpdateRequestResponse();
    }

    /**
     * Create an instance of {@link GetZones }
     * 
     */
    public GetZones createGetZones() {
        return new GetZones();
    }

    /**
     * Create an instance of {@link Location.Zones }
     * 
     */
    public Location.Zones createLocationZones() {
        return new Location.Zones();
    }

    /**
     * Create an instance of {@link Anything.UnNumbers }
     * 
     */
    public Anything.UnNumbers createAnythingUnNumbers() {
        return new Anything.UnNumbers();
    }

    /**
     * Create an instance of {@link Anything.Articles }
     * 
     */
    public Anything.Articles createAnythingArticles() {
        return new Anything.Articles();
    }

    /**
     * Create an instance of {@link CarrierPreference.DeliveryMethods }
     * 
     */
    public CarrierPreference.DeliveryMethods createCarrierPreferenceDeliveryMethods() {
        return new CarrierPreference.DeliveryMethods();
    }

    /**
     * Create an instance of {@link AvailableQuote.Articles }
     * 
     */
    public AvailableQuote.Articles createAvailableQuoteArticles() {
        return new AvailableQuote.Articles();
    }

    /**
     * Create an instance of {@link AvailableQuote.TrackingHistories }
     * 
     */
    public AvailableQuote.TrackingHistories createAvailableQuoteTrackingHistories() {
        return new AvailableQuote.TrackingHistories();
    }

    /**
     * Create an instance of {@link AvailableQuote.Adjustments }
     * 
     */
    public AvailableQuote.Adjustments createAvailableQuoteAdjustments() {
        return new AvailableQuote.Adjustments();
    }

    /**
     * Create an instance of {@link AvailableQuote.Inclusions }
     * 
     */
    public AvailableQuote.Inclusions createAvailableQuoteInclusions() {
        return new AvailableQuote.Inclusions();
    }

    /**
     * Create an instance of {@link AvailableQuote.Extras }
     * 
     */
    public AvailableQuote.Extras createAvailableQuoteExtras() {
        return new AvailableQuote.Extras();
    }

    /**
     * Create an instance of {@link Request.Anythings }
     * 
     */
    public Request.Anythings createRequestAnythings() {
        return new Request.Anythings();
    }

    /**
     * Create an instance of {@link Request.Quotes }
     * 
     */
    public Request.Quotes createRequestQuotes() {
        return new Request.Quotes();
    }

    /**
     * Create an instance of {@link BookingQuote.Extras }
     * 
     */
    public BookingQuote.Extras createBookingQuoteExtras() {
        return new BookingQuote.Extras();
    }

    /**
     * Create an instance of {@link QuoteFilter.Carriers }
     * 
     */
    public QuoteFilter.Carriers createQuoteFilterCarriers() {
        return new QuoteFilter.Carriers();
    }

    /**
     * Create an instance of {@link QuoteFilter.Extras }
     * 
     */
    public QuoteFilter.Extras createQuoteFilterExtras() {
        return new QuoteFilter.Extras();
    }

    /**
     * Create an instance of {@link Zone.ZoneRanges }
     * 
     */
    public Zone.ZoneRanges createZoneZoneRanges() {
        return new Zone.ZoneRanges();
    }

    /**
     * Create an instance of {@link Item.ItemStocks }
     * 
     */
    public Item.ItemStocks createItemItemStocks() {
        return new Item.ItemStocks();
    }

    /**
     * Create an instance of {@link Extra.Adjustments }
     * 
     */
    public Extra.Adjustments createExtraAdjustments() {
        return new Extra.Adjustments();
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Object }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://api-demo.temando.com/schema/2009_06/server.xsd", name = "updateTrackingDetailsResponse")
    public JAXBElement<Object> createUpdateTrackingDetailsResponse(Object value) {
        return new JAXBElement<Object>(_UpdateTrackingDetailsResponse_QNAME, Object.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Object }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://api-demo.temando.com/schema/2009_06/server.xsd", name = "updateLocationResponse")
    public JAXBElement<Object> createUpdateLocationResponse(Object value) {
        return new JAXBElement<Object>(_UpdateLocationResponse_QNAME, Object.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Object }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://api-demo.temando.com/schema/2009_06/server.xsd", name = "createLocationResponse")
    public JAXBElement<Object> createCreateLocationResponse(Object value) {
        return new JAXBElement<Object>(_CreateLocationResponse_QNAME, Object.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Object }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://api-demo.temando.com/schema/2009_06/server.xsd", name = "createItemResponse")
    public JAXBElement<Object> createCreateItemResponse(Object value) {
        return new JAXBElement<Object>(_CreateItemResponse_QNAME, Object.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Object }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://api-demo.temando.com/schema/2009_06/server.xsd", name = "cancelRequestResponse")
    public JAXBElement<Object> createCancelRequestResponse(Object value) {
        return new JAXBElement<Object>(_CancelRequestResponse_QNAME, Object.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Object }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://api-demo.temando.com/schema/2009_06/server.xsd", name = "createZoneResponse")
    public JAXBElement<Object> createCreateZoneResponse(Object value) {
        return new JAXBElement<Object>(_CreateZoneResponse_QNAME, Object.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Object }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://api-demo.temando.com/schema/2009_06/server.xsd", name = "updateZoneResponse")
    public JAXBElement<Object> createUpdateZoneResponse(Object value) {
        return new JAXBElement<Object>(_UpdateZoneResponse_QNAME, Object.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Object }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://api-demo.temando.com/schema/2009_06/server.xsd", name = "addBookingDetailsResponse")
    public JAXBElement<Object> createAddBookingDetailsResponse(Object value) {
        return new JAXBElement<Object>(_AddBookingDetailsResponse_QNAME, Object.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Object }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://api-demo.temando.com/schema/2009_06/server.xsd", name = "updateItemResponse")
    public JAXBElement<Object> createUpdateItemResponse(Object value) {
        return new JAXBElement<Object>(_UpdateItemResponse_QNAME, Object.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Object }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://api-demo.temando.com/schema/2009_06/server.xsd", name = "getRequestsRequiringBooking")
    public JAXBElement<Object> createGetRequestsRequiringBooking(Object value) {
        return new JAXBElement<Object>(_GetRequestsRequiringBooking_QNAME, Object.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Object }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://api-demo.temando.com/schema/2009_06/server.xsd", name = "lodgeDispatchResponse")
    public JAXBElement<Object> createLodgeDispatchResponse(Object value) {
        return new JAXBElement<Object>(_LodgeDispatchResponse_QNAME, Object.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Object }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://api-demo.temando.com/schema/2009_06/server.xsd", name = "updatePackagingResponse")
    public JAXBElement<Object> createUpdatePackagingResponse(Object value) {
        return new JAXBElement<Object>(_UpdatePackagingResponse_QNAME, Object.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Object }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://api-demo.temando.com/schema/2009_06/server.xsd", name = "createPackagingResponse")
    public JAXBElement<Object> createCreatePackagingResponse(Object value) {
        return new JAXBElement<Object>(_CreatePackagingResponse_QNAME, Object.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Object }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://api-demo.temando.com/schema/2009_06/server.xsd", name = "updateClientResponse")
    public JAXBElement<Object> createUpdateClientResponse(Object value) {
        return new JAXBElement<Object>(_UpdateClientResponse_QNAME, Object.class, null, value);
    }

}
