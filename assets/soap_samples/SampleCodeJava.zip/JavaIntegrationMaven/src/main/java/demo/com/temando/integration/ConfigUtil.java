package demo.com.temando.integration;

import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

import demo.com.temando.api.QuotingService;

public class ConfigUtil {
	private static Properties configProperties;

	static {
		configProperties = new Properties();
		String propFilePath = "demo/com/temando/integration/config/config.properties";
		InputStream inputStream = QuotingService.class.getClassLoader()
				.getResourceAsStream(propFilePath);

		if (inputStream != null) {
			try {
				configProperties.load(inputStream);
			} catch (IOException e) {
				e.printStackTrace();
			}
		} else {
			java.util.logging.Logger
					.getLogger(QuotingService.class.getName())
					.log(java.util.logging.Level.INFO,
							"Config property file {0} not found in the classpath",
							propFilePath);
		}
	}
	
	public static String getWsdlLocation() {
		return configProperties.getProperty("wsdlLocation");
	}
	
	public static String getNamespaceUri() {
		return configProperties.getProperty("namespaceUri");
	}
	
	public static String getUsernameTokenUsername() {
		return configProperties.getProperty("usernameTokenUsername");
	}
	
	public static String getUsernameTokenPassword() {
		return configProperties.getProperty("usernameTokenPassword");
	}
}
