
package demo.com.temando.api;

import java.math.BigDecimal;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for DispatchDetails complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="DispatchDetails">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;all>
 *         &lt;element name="reference" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}CarrierReference" minOccurs="0"/>
 *         &lt;element name="carrierName" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}CompanyName" minOccurs="0"/>
 *         &lt;element name="carrierId" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}CarrierId" minOccurs="0"/>
 *         &lt;element name="accountNo" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}CarrierAccountNumber" minOccurs="0"/>
 *         &lt;element name="creatorId" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}CarrierCreatorId" minOccurs="0"/>
 *         &lt;element name="currency" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}CurrencyType" minOccurs="0"/>
 *         &lt;element name="changedCarrier" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}YesNoOption" minOccurs="0"/>
 *         &lt;element name="consignmentEdited" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}YesNoOption" minOccurs="0"/>
 *         &lt;element name="consignmentNumber" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}ConsignmentNumber" minOccurs="0"/>
 *         &lt;element name="consignmentDate" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}Date" minOccurs="0"/>
 *         &lt;element name="deliveryMethod" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}DeliveryMethod" minOccurs="0"/>
 *         &lt;element name="rateName" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}RateName" minOccurs="0"/>
 *         &lt;element name="description" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}ItemDescription" minOccurs="0"/>
 *         &lt;element name="distanceMeasurementType" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}DistanceMeasurementType" minOccurs="0"/>
 *         &lt;element name="weightMeasurementType" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}WeightMeasurementType" minOccurs="0"/>
 *         &lt;element name="length" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}Length" minOccurs="0"/>
 *         &lt;element name="width" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}Width" minOccurs="0"/>
 *         &lt;element name="height" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}Height" minOccurs="0"/>
 *         &lt;element name="actualWeight" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}Weight" minOccurs="0"/>
 *         &lt;element name="chargeableWeight" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}Weight" minOccurs="0"/>
 *         &lt;element name="actualCubic" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}Cubic" minOccurs="0"/>
 *         &lt;element name="chargeableCubic" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}Cubic" minOccurs="0"/>
 *         &lt;element name="actualQuantity" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}Quantity" minOccurs="0"/>
 *         &lt;element name="chargeableQuantity" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}Quantity" minOccurs="0"/>
 *         &lt;element name="basePrice" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}CurrencyAmount" minOccurs="0"/>
 *         &lt;element name="surcharges" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}CurrencyAmount" minOccurs="0"/>
 *         &lt;element name="tax" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}CurrencyAmount" minOccurs="0"/>
 *         &lt;element name="totalPrice" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}CurrencyAmount" minOccurs="0"/>
 *         &lt;element name="originZoneName" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}ZoneName" minOccurs="0"/>
 *         &lt;element name="originContactName" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}ContactName" minOccurs="0"/>
 *         &lt;element name="originCompanyName" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}CompanyName" minOccurs="0"/>
 *         &lt;element name="originStreet" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}Address" minOccurs="0"/>
 *         &lt;element name="originSuburb" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}Suburb" minOccurs="0"/>
 *         &lt;element name="originState" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}State" minOccurs="0"/>
 *         &lt;element name="originCode" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}PostalCode" minOccurs="0"/>
 *         &lt;element name="originCountry" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}CountryCode" minOccurs="0"/>
 *         &lt;element name="originPhone1" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}Phone" minOccurs="0"/>
 *         &lt;element name="originPhone2" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}Phone" minOccurs="0"/>
 *         &lt;element name="originFax" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}Fax" minOccurs="0"/>
 *         &lt;element name="originEmail" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}Email" minOccurs="0"/>
 *         &lt;element name="destinationZoneName" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}ZoneName" minOccurs="0"/>
 *         &lt;element name="destinationContactName" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}ContactName" minOccurs="0"/>
 *         &lt;element name="destinationCompanyName" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}CompanyName" minOccurs="0"/>
 *         &lt;element name="destinationStreet" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}Address" minOccurs="0"/>
 *         &lt;element name="destinationSuburb" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}Suburb" minOccurs="0"/>
 *         &lt;element name="destinationState" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}State" minOccurs="0"/>
 *         &lt;element name="destinationCode" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}PostalCode" minOccurs="0"/>
 *         &lt;element name="destinationCountry" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}CountryCode" minOccurs="0"/>
 *         &lt;element name="destinationPhone1" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}Phone" minOccurs="0"/>
 *         &lt;element name="destinationPhone2" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}Phone" minOccurs="0"/>
 *         &lt;element name="destinationFax" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}Fax" minOccurs="0"/>
 *         &lt;element name="destinationEmail" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}Email" minOccurs="0"/>
 *       &lt;/all>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "DispatchDetails", namespace = "http://api-demo.temando.com/schema/2009_06/common.xsd", propOrder = {

})
public class DispatchDetails {

    protected String reference;
    protected String carrierName;
    protected Integer carrierId;
    protected String accountNo;
    protected String creatorId;
    protected CurrencyType currency;
    protected YesNoOption changedCarrier;
    protected YesNoOption consignmentEdited;
    protected String consignmentNumber;
    protected String consignmentDate;
    protected String deliveryMethod;
    protected String rateName;
    protected String description;
    protected DistanceMeasurementType distanceMeasurementType;
    protected WeightMeasurementType weightMeasurementType;
    protected Integer length;
    protected Integer width;
    protected Integer height;
    protected Integer actualWeight;
    protected Integer chargeableWeight;
    protected BigDecimal actualCubic;
    protected BigDecimal chargeableCubic;
    protected Integer actualQuantity;
    protected Integer chargeableQuantity;
    protected BigDecimal basePrice;
    protected BigDecimal surcharges;
    protected BigDecimal tax;
    protected BigDecimal totalPrice;
    protected String originZoneName;
    protected String originContactName;
    protected String originCompanyName;
    protected String originStreet;
    protected String originSuburb;
    protected String originState;
    protected String originCode;
    protected String originCountry;
    protected String originPhone1;
    protected String originPhone2;
    protected String originFax;
    protected String originEmail;
    protected String destinationZoneName;
    protected String destinationContactName;
    protected String destinationCompanyName;
    protected String destinationStreet;
    protected String destinationSuburb;
    protected String destinationState;
    protected String destinationCode;
    protected String destinationCountry;
    protected String destinationPhone1;
    protected String destinationPhone2;
    protected String destinationFax;
    protected String destinationEmail;

    /**
     * Gets the value of the reference property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getReference() {
        return reference;
    }

    /**
     * Sets the value of the reference property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setReference(String value) {
        this.reference = value;
    }

    /**
     * Gets the value of the carrierName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCarrierName() {
        return carrierName;
    }

    /**
     * Sets the value of the carrierName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCarrierName(String value) {
        this.carrierName = value;
    }

    /**
     * Gets the value of the carrierId property.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getCarrierId() {
        return carrierId;
    }

    /**
     * Sets the value of the carrierId property.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setCarrierId(Integer value) {
        this.carrierId = value;
    }

    /**
     * Gets the value of the accountNo property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAccountNo() {
        return accountNo;
    }

    /**
     * Sets the value of the accountNo property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAccountNo(String value) {
        this.accountNo = value;
    }

    /**
     * Gets the value of the creatorId property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCreatorId() {
        return creatorId;
    }

    /**
     * Sets the value of the creatorId property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCreatorId(String value) {
        this.creatorId = value;
    }

    /**
     * Gets the value of the currency property.
     * 
     * @return
     *     possible object is
     *     {@link CurrencyType }
     *     
     */
    public CurrencyType getCurrency() {
        return currency;
    }

    /**
     * Sets the value of the currency property.
     * 
     * @param value
     *     allowed object is
     *     {@link CurrencyType }
     *     
     */
    public void setCurrency(CurrencyType value) {
        this.currency = value;
    }

    /**
     * Gets the value of the changedCarrier property.
     * 
     * @return
     *     possible object is
     *     {@link YesNoOption }
     *     
     */
    public YesNoOption getChangedCarrier() {
        return changedCarrier;
    }

    /**
     * Sets the value of the changedCarrier property.
     * 
     * @param value
     *     allowed object is
     *     {@link YesNoOption }
     *     
     */
    public void setChangedCarrier(YesNoOption value) {
        this.changedCarrier = value;
    }

    /**
     * Gets the value of the consignmentEdited property.
     * 
     * @return
     *     possible object is
     *     {@link YesNoOption }
     *     
     */
    public YesNoOption getConsignmentEdited() {
        return consignmentEdited;
    }

    /**
     * Sets the value of the consignmentEdited property.
     * 
     * @param value
     *     allowed object is
     *     {@link YesNoOption }
     *     
     */
    public void setConsignmentEdited(YesNoOption value) {
        this.consignmentEdited = value;
    }

    /**
     * Gets the value of the consignmentNumber property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getConsignmentNumber() {
        return consignmentNumber;
    }

    /**
     * Sets the value of the consignmentNumber property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setConsignmentNumber(String value) {
        this.consignmentNumber = value;
    }

    /**
     * Gets the value of the consignmentDate property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getConsignmentDate() {
        return consignmentDate;
    }

    /**
     * Sets the value of the consignmentDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setConsignmentDate(String value) {
        this.consignmentDate = value;
    }

    /**
     * Gets the value of the deliveryMethod property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDeliveryMethod() {
        return deliveryMethod;
    }

    /**
     * Sets the value of the deliveryMethod property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDeliveryMethod(String value) {
        this.deliveryMethod = value;
    }

    /**
     * Gets the value of the rateName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRateName() {
        return rateName;
    }

    /**
     * Sets the value of the rateName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRateName(String value) {
        this.rateName = value;
    }

    /**
     * Gets the value of the description property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDescription() {
        return description;
    }

    /**
     * Sets the value of the description property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDescription(String value) {
        this.description = value;
    }

    /**
     * Gets the value of the distanceMeasurementType property.
     * 
     * @return
     *     possible object is
     *     {@link DistanceMeasurementType }
     *     
     */
    public DistanceMeasurementType getDistanceMeasurementType() {
        return distanceMeasurementType;
    }

    /**
     * Sets the value of the distanceMeasurementType property.
     * 
     * @param value
     *     allowed object is
     *     {@link DistanceMeasurementType }
     *     
     */
    public void setDistanceMeasurementType(DistanceMeasurementType value) {
        this.distanceMeasurementType = value;
    }

    /**
     * Gets the value of the weightMeasurementType property.
     * 
     * @return
     *     possible object is
     *     {@link WeightMeasurementType }
     *     
     */
    public WeightMeasurementType getWeightMeasurementType() {
        return weightMeasurementType;
    }

    /**
     * Sets the value of the weightMeasurementType property.
     * 
     * @param value
     *     allowed object is
     *     {@link WeightMeasurementType }
     *     
     */
    public void setWeightMeasurementType(WeightMeasurementType value) {
        this.weightMeasurementType = value;
    }

    /**
     * Gets the value of the length property.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getLength() {
        return length;
    }

    /**
     * Sets the value of the length property.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setLength(Integer value) {
        this.length = value;
    }

    /**
     * Gets the value of the width property.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getWidth() {
        return width;
    }

    /**
     * Sets the value of the width property.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setWidth(Integer value) {
        this.width = value;
    }

    /**
     * Gets the value of the height property.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getHeight() {
        return height;
    }

    /**
     * Sets the value of the height property.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setHeight(Integer value) {
        this.height = value;
    }

    /**
     * Gets the value of the actualWeight property.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getActualWeight() {
        return actualWeight;
    }

    /**
     * Sets the value of the actualWeight property.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setActualWeight(Integer value) {
        this.actualWeight = value;
    }

    /**
     * Gets the value of the chargeableWeight property.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getChargeableWeight() {
        return chargeableWeight;
    }

    /**
     * Sets the value of the chargeableWeight property.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setChargeableWeight(Integer value) {
        this.chargeableWeight = value;
    }

    /**
     * Gets the value of the actualCubic property.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getActualCubic() {
        return actualCubic;
    }

    /**
     * Sets the value of the actualCubic property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setActualCubic(BigDecimal value) {
        this.actualCubic = value;
    }

    /**
     * Gets the value of the chargeableCubic property.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getChargeableCubic() {
        return chargeableCubic;
    }

    /**
     * Sets the value of the chargeableCubic property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setChargeableCubic(BigDecimal value) {
        this.chargeableCubic = value;
    }

    /**
     * Gets the value of the actualQuantity property.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getActualQuantity() {
        return actualQuantity;
    }

    /**
     * Sets the value of the actualQuantity property.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setActualQuantity(Integer value) {
        this.actualQuantity = value;
    }

    /**
     * Gets the value of the chargeableQuantity property.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getChargeableQuantity() {
        return chargeableQuantity;
    }

    /**
     * Sets the value of the chargeableQuantity property.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setChargeableQuantity(Integer value) {
        this.chargeableQuantity = value;
    }

    /**
     * Gets the value of the basePrice property.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getBasePrice() {
        return basePrice;
    }

    /**
     * Sets the value of the basePrice property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setBasePrice(BigDecimal value) {
        this.basePrice = value;
    }

    /**
     * Gets the value of the surcharges property.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getSurcharges() {
        return surcharges;
    }

    /**
     * Sets the value of the surcharges property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setSurcharges(BigDecimal value) {
        this.surcharges = value;
    }

    /**
     * Gets the value of the tax property.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getTax() {
        return tax;
    }

    /**
     * Sets the value of the tax property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setTax(BigDecimal value) {
        this.tax = value;
    }

    /**
     * Gets the value of the totalPrice property.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getTotalPrice() {
        return totalPrice;
    }

    /**
     * Sets the value of the totalPrice property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setTotalPrice(BigDecimal value) {
        this.totalPrice = value;
    }

    /**
     * Gets the value of the originZoneName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getOriginZoneName() {
        return originZoneName;
    }

    /**
     * Sets the value of the originZoneName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setOriginZoneName(String value) {
        this.originZoneName = value;
    }

    /**
     * Gets the value of the originContactName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getOriginContactName() {
        return originContactName;
    }

    /**
     * Sets the value of the originContactName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setOriginContactName(String value) {
        this.originContactName = value;
    }

    /**
     * Gets the value of the originCompanyName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getOriginCompanyName() {
        return originCompanyName;
    }

    /**
     * Sets the value of the originCompanyName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setOriginCompanyName(String value) {
        this.originCompanyName = value;
    }

    /**
     * Gets the value of the originStreet property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getOriginStreet() {
        return originStreet;
    }

    /**
     * Sets the value of the originStreet property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setOriginStreet(String value) {
        this.originStreet = value;
    }

    /**
     * Gets the value of the originSuburb property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getOriginSuburb() {
        return originSuburb;
    }

    /**
     * Sets the value of the originSuburb property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setOriginSuburb(String value) {
        this.originSuburb = value;
    }

    /**
     * Gets the value of the originState property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getOriginState() {
        return originState;
    }

    /**
     * Sets the value of the originState property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setOriginState(String value) {
        this.originState = value;
    }

    /**
     * Gets the value of the originCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getOriginCode() {
        return originCode;
    }

    /**
     * Sets the value of the originCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setOriginCode(String value) {
        this.originCode = value;
    }

    /**
     * Gets the value of the originCountry property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getOriginCountry() {
        return originCountry;
    }

    /**
     * Sets the value of the originCountry property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setOriginCountry(String value) {
        this.originCountry = value;
    }

    /**
     * Gets the value of the originPhone1 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getOriginPhone1() {
        return originPhone1;
    }

    /**
     * Sets the value of the originPhone1 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setOriginPhone1(String value) {
        this.originPhone1 = value;
    }

    /**
     * Gets the value of the originPhone2 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getOriginPhone2() {
        return originPhone2;
    }

    /**
     * Sets the value of the originPhone2 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setOriginPhone2(String value) {
        this.originPhone2 = value;
    }

    /**
     * Gets the value of the originFax property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getOriginFax() {
        return originFax;
    }

    /**
     * Sets the value of the originFax property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setOriginFax(String value) {
        this.originFax = value;
    }

    /**
     * Gets the value of the originEmail property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getOriginEmail() {
        return originEmail;
    }

    /**
     * Sets the value of the originEmail property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setOriginEmail(String value) {
        this.originEmail = value;
    }

    /**
     * Gets the value of the destinationZoneName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDestinationZoneName() {
        return destinationZoneName;
    }

    /**
     * Sets the value of the destinationZoneName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDestinationZoneName(String value) {
        this.destinationZoneName = value;
    }

    /**
     * Gets the value of the destinationContactName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDestinationContactName() {
        return destinationContactName;
    }

    /**
     * Sets the value of the destinationContactName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDestinationContactName(String value) {
        this.destinationContactName = value;
    }

    /**
     * Gets the value of the destinationCompanyName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDestinationCompanyName() {
        return destinationCompanyName;
    }

    /**
     * Sets the value of the destinationCompanyName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDestinationCompanyName(String value) {
        this.destinationCompanyName = value;
    }

    /**
     * Gets the value of the destinationStreet property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDestinationStreet() {
        return destinationStreet;
    }

    /**
     * Sets the value of the destinationStreet property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDestinationStreet(String value) {
        this.destinationStreet = value;
    }

    /**
     * Gets the value of the destinationSuburb property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDestinationSuburb() {
        return destinationSuburb;
    }

    /**
     * Sets the value of the destinationSuburb property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDestinationSuburb(String value) {
        this.destinationSuburb = value;
    }

    /**
     * Gets the value of the destinationState property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDestinationState() {
        return destinationState;
    }

    /**
     * Sets the value of the destinationState property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDestinationState(String value) {
        this.destinationState = value;
    }

    /**
     * Gets the value of the destinationCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDestinationCode() {
        return destinationCode;
    }

    /**
     * Sets the value of the destinationCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDestinationCode(String value) {
        this.destinationCode = value;
    }

    /**
     * Gets the value of the destinationCountry property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDestinationCountry() {
        return destinationCountry;
    }

    /**
     * Sets the value of the destinationCountry property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDestinationCountry(String value) {
        this.destinationCountry = value;
    }

    /**
     * Gets the value of the destinationPhone1 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDestinationPhone1() {
        return destinationPhone1;
    }

    /**
     * Sets the value of the destinationPhone1 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDestinationPhone1(String value) {
        this.destinationPhone1 = value;
    }

    /**
     * Gets the value of the destinationPhone2 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDestinationPhone2() {
        return destinationPhone2;
    }

    /**
     * Sets the value of the destinationPhone2 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDestinationPhone2(String value) {
        this.destinationPhone2 = value;
    }

    /**
     * Gets the value of the destinationFax property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDestinationFax() {
        return destinationFax;
    }

    /**
     * Sets the value of the destinationFax property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDestinationFax(String value) {
        this.destinationFax = value;
    }

    /**
     * Gets the value of the destinationEmail property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDestinationEmail() {
        return destinationEmail;
    }

    /**
     * Sets the value of the destinationEmail property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDestinationEmail(String value) {
        this.destinationEmail = value;
    }

}
