
package demo.com.temando.api;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for Anywhere complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="Anywhere">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;all>
 *         &lt;element name="itemNature" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}DeliveryNature"/>
 *         &lt;element name="itemMethod" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}DeliveryType"/>
 *         &lt;element name="originDescription" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}LocationName" minOccurs="0"/>
 *         &lt;element name="originCountry" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}CountryCode" minOccurs="0"/>
 *         &lt;element name="originCode" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}PostalCode" minOccurs="0"/>
 *         &lt;element name="originSuburb" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}Suburb" minOccurs="0"/>
 *         &lt;element name="originState" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}State" minOccurs="0"/>
 *         &lt;element name="originCity" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}City" minOccurs="0"/>
 *         &lt;element name="originPort" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}PortName" minOccurs="0"/>
 *         &lt;element name="destinationDescription" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}LocationName" minOccurs="0"/>
 *         &lt;element name="destinationCountry" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}CountryCode" minOccurs="0"/>
 *         &lt;element name="destinationCode" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}PostalCode" minOccurs="0"/>
 *         &lt;element name="destinationSuburb" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}Suburb" minOccurs="0"/>
 *         &lt;element name="destinationState" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}State" minOccurs="0"/>
 *         &lt;element name="destinationCity" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}City" minOccurs="0"/>
 *         &lt;element name="destinationPort" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}PortName" minOccurs="0"/>
 *         &lt;element name="portType" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}PortType" minOccurs="0"/>
 *         &lt;element name="destinationIs" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}LocationType" minOccurs="0"/>
 *         &lt;element name="destinationBusPostalBox" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}YesNoOption" minOccurs="0"/>
 *         &lt;element name="destinationBusUnattended" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}YesNoOption" minOccurs="0"/>
 *         &lt;element name="destinationBusDock" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}YesNoOption" minOccurs="0"/>
 *         &lt;element name="destinationBusForklift" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}YesNoOption" minOccurs="0"/>
 *         &lt;element name="destinationBusLoadingFacilities" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}YesNoOption" minOccurs="0"/>
 *         &lt;element name="destinationBusInside" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}YesNoOption" minOccurs="0"/>
 *         &lt;element name="destinationBusNotifyBefore" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}YesNoOption" minOccurs="0"/>
 *         &lt;element name="destinationBusLimitedAccess" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}YesNoOption" minOccurs="0"/>
 *         &lt;element name="destinationBusHeavyLift" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}YesNoOption" minOccurs="0"/>
 *         &lt;element name="destinationBusTailgateLifter" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}YesNoOption" minOccurs="0"/>
 *         &lt;element name="destinationBusContainerSwingLifter" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}YesNoOption" minOccurs="0"/>
 *         &lt;element name="destinationResPostalBox" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}YesNoOption" minOccurs="0"/>
 *         &lt;element name="destinationResUnattended" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}YesNoOption" minOccurs="0"/>
 *         &lt;element name="destinationResInside" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}YesNoOption" minOccurs="0"/>
 *         &lt;element name="destinationResNotifyBefore" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}YesNoOption" minOccurs="0"/>
 *         &lt;element name="destinationResLimitedAccess" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}YesNoOption" minOccurs="0"/>
 *         &lt;element name="destinationResHeavyLift" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}YesNoOption" minOccurs="0"/>
 *         &lt;element name="destinationResTailgateLifter" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}YesNoOption" minOccurs="0"/>
 *         &lt;element name="originIs" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}LocationType" minOccurs="0"/>
 *         &lt;element name="originBusUnattended" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}YesNoOption" minOccurs="0"/>
 *         &lt;element name="originBusDock" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}YesNoOption" minOccurs="0"/>
 *         &lt;element name="originBusForklift" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}YesNoOption" minOccurs="0"/>
 *         &lt;element name="originBusLoadingFacilities" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}YesNoOption" minOccurs="0"/>
 *         &lt;element name="originBusInside" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}YesNoOption" minOccurs="0"/>
 *         &lt;element name="originBusNotifyBefore" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}YesNoOption" minOccurs="0"/>
 *         &lt;element name="originBusLimitedAccess" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}YesNoOption" minOccurs="0"/>
 *         &lt;element name="originBusHeavyLift" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}YesNoOption" minOccurs="0"/>
 *         &lt;element name="originBusTailgateLifter" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}YesNoOption" minOccurs="0"/>
 *         &lt;element name="originBusContainerSwingLifter" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}YesNoOption" minOccurs="0"/>
 *         &lt;element name="originResUnattended" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}YesNoOption" minOccurs="0"/>
 *         &lt;element name="originResInside" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}YesNoOption" minOccurs="0"/>
 *         &lt;element name="originResNotifyBefore" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}YesNoOption" minOccurs="0"/>
 *         &lt;element name="originResLimitedAccess" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}YesNoOption" minOccurs="0"/>
 *         &lt;element name="originResHeavyLift" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}YesNoOption" minOccurs="0"/>
 *         &lt;element name="originResTailgateLifter" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}YesNoOption" minOccurs="0"/>
 *         &lt;element name="locationSelection" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}LocationSelection" minOccurs="0"/>
 *       &lt;/all>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "Anywhere", namespace = "http://api-demo.temando.com/schema/2009_06/common.xsd", propOrder = {

})
public class Anywhere {

    @XmlElement(required = true)
    protected DeliveryNature itemNature;
    @XmlElement(required = true)
    protected DeliveryType itemMethod;
    protected String originDescription;
    protected String originCountry;
    protected String originCode;
    protected String originSuburb;
    protected String originState;
    protected String originCity;
    protected String originPort;
    protected String destinationDescription;
    protected String destinationCountry;
    protected String destinationCode;
    protected String destinationSuburb;
    protected String destinationState;
    protected String destinationCity;
    protected String destinationPort;
    protected PortType portType;
    protected LocationType destinationIs;
    protected YesNoOption destinationBusPostalBox;
    protected YesNoOption destinationBusUnattended;
    protected YesNoOption destinationBusDock;
    protected YesNoOption destinationBusForklift;
    protected YesNoOption destinationBusLoadingFacilities;
    protected YesNoOption destinationBusInside;
    protected YesNoOption destinationBusNotifyBefore;
    protected YesNoOption destinationBusLimitedAccess;
    protected YesNoOption destinationBusHeavyLift;
    protected YesNoOption destinationBusTailgateLifter;
    protected YesNoOption destinationBusContainerSwingLifter;
    protected YesNoOption destinationResPostalBox;
    protected YesNoOption destinationResUnattended;
    protected YesNoOption destinationResInside;
    protected YesNoOption destinationResNotifyBefore;
    protected YesNoOption destinationResLimitedAccess;
    protected YesNoOption destinationResHeavyLift;
    protected YesNoOption destinationResTailgateLifter;
    protected LocationType originIs;
    protected YesNoOption originBusUnattended;
    protected YesNoOption originBusDock;
    protected YesNoOption originBusForklift;
    protected YesNoOption originBusLoadingFacilities;
    protected YesNoOption originBusInside;
    protected YesNoOption originBusNotifyBefore;
    protected YesNoOption originBusLimitedAccess;
    protected YesNoOption originBusHeavyLift;
    protected YesNoOption originBusTailgateLifter;
    protected YesNoOption originBusContainerSwingLifter;
    protected YesNoOption originResUnattended;
    protected YesNoOption originResInside;
    protected YesNoOption originResNotifyBefore;
    protected YesNoOption originResLimitedAccess;
    protected YesNoOption originResHeavyLift;
    protected YesNoOption originResTailgateLifter;
    protected LocationSelection locationSelection;

    /**
     * Gets the value of the itemNature property.
     * 
     * @return
     *     possible object is
     *     {@link DeliveryNature }
     *     
     */
    public DeliveryNature getItemNature() {
        return itemNature;
    }

    /**
     * Sets the value of the itemNature property.
     * 
     * @param value
     *     allowed object is
     *     {@link DeliveryNature }
     *     
     */
    public void setItemNature(DeliveryNature value) {
        this.itemNature = value;
    }

    /**
     * Gets the value of the itemMethod property.
     * 
     * @return
     *     possible object is
     *     {@link DeliveryType }
     *     
     */
    public DeliveryType getItemMethod() {
        return itemMethod;
    }

    /**
     * Sets the value of the itemMethod property.
     * 
     * @param value
     *     allowed object is
     *     {@link DeliveryType }
     *     
     */
    public void setItemMethod(DeliveryType value) {
        this.itemMethod = value;
    }

    /**
     * Gets the value of the originDescription property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getOriginDescription() {
        return originDescription;
    }

    /**
     * Sets the value of the originDescription property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setOriginDescription(String value) {
        this.originDescription = value;
    }

    /**
     * Gets the value of the originCountry property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getOriginCountry() {
        return originCountry;
    }

    /**
     * Sets the value of the originCountry property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setOriginCountry(String value) {
        this.originCountry = value;
    }

    /**
     * Gets the value of the originCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getOriginCode() {
        return originCode;
    }

    /**
     * Sets the value of the originCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setOriginCode(String value) {
        this.originCode = value;
    }

    /**
     * Gets the value of the originSuburb property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getOriginSuburb() {
        return originSuburb;
    }

    /**
     * Sets the value of the originSuburb property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setOriginSuburb(String value) {
        this.originSuburb = value;
    }

    /**
     * Gets the value of the originState property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getOriginState() {
        return originState;
    }

    /**
     * Sets the value of the originState property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setOriginState(String value) {
        this.originState = value;
    }

    /**
     * Gets the value of the originCity property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getOriginCity() {
        return originCity;
    }

    /**
     * Sets the value of the originCity property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setOriginCity(String value) {
        this.originCity = value;
    }

    /**
     * Gets the value of the originPort property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getOriginPort() {
        return originPort;
    }

    /**
     * Sets the value of the originPort property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setOriginPort(String value) {
        this.originPort = value;
    }

    /**
     * Gets the value of the destinationDescription property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDestinationDescription() {
        return destinationDescription;
    }

    /**
     * Sets the value of the destinationDescription property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDestinationDescription(String value) {
        this.destinationDescription = value;
    }

    /**
     * Gets the value of the destinationCountry property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDestinationCountry() {
        return destinationCountry;
    }

    /**
     * Sets the value of the destinationCountry property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDestinationCountry(String value) {
        this.destinationCountry = value;
    }

    /**
     * Gets the value of the destinationCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDestinationCode() {
        return destinationCode;
    }

    /**
     * Sets the value of the destinationCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDestinationCode(String value) {
        this.destinationCode = value;
    }

    /**
     * Gets the value of the destinationSuburb property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDestinationSuburb() {
        return destinationSuburb;
    }

    /**
     * Sets the value of the destinationSuburb property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDestinationSuburb(String value) {
        this.destinationSuburb = value;
    }

    /**
     * Gets the value of the destinationState property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDestinationState() {
        return destinationState;
    }

    /**
     * Sets the value of the destinationState property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDestinationState(String value) {
        this.destinationState = value;
    }

    /**
     * Gets the value of the destinationCity property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDestinationCity() {
        return destinationCity;
    }

    /**
     * Sets the value of the destinationCity property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDestinationCity(String value) {
        this.destinationCity = value;
    }

    /**
     * Gets the value of the destinationPort property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDestinationPort() {
        return destinationPort;
    }

    /**
     * Sets the value of the destinationPort property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDestinationPort(String value) {
        this.destinationPort = value;
    }

    /**
     * Gets the value of the portType property.
     * 
     * @return
     *     possible object is
     *     {@link PortType }
     *     
     */
    public PortType getPortType() {
        return portType;
    }

    /**
     * Sets the value of the portType property.
     * 
     * @param value
     *     allowed object is
     *     {@link PortType }
     *     
     */
    public void setPortType(PortType value) {
        this.portType = value;
    }

    /**
     * Gets the value of the destinationIs property.
     * 
     * @return
     *     possible object is
     *     {@link LocationType }
     *     
     */
    public LocationType getDestinationIs() {
        return destinationIs;
    }

    /**
     * Sets the value of the destinationIs property.
     * 
     * @param value
     *     allowed object is
     *     {@link LocationType }
     *     
     */
    public void setDestinationIs(LocationType value) {
        this.destinationIs = value;
    }

    /**
     * Gets the value of the destinationBusPostalBox property.
     * 
     * @return
     *     possible object is
     *     {@link YesNoOption }
     *     
     */
    public YesNoOption getDestinationBusPostalBox() {
        return destinationBusPostalBox;
    }

    /**
     * Sets the value of the destinationBusPostalBox property.
     * 
     * @param value
     *     allowed object is
     *     {@link YesNoOption }
     *     
     */
    public void setDestinationBusPostalBox(YesNoOption value) {
        this.destinationBusPostalBox = value;
    }

    /**
     * Gets the value of the destinationBusUnattended property.
     * 
     * @return
     *     possible object is
     *     {@link YesNoOption }
     *     
     */
    public YesNoOption getDestinationBusUnattended() {
        return destinationBusUnattended;
    }

    /**
     * Sets the value of the destinationBusUnattended property.
     * 
     * @param value
     *     allowed object is
     *     {@link YesNoOption }
     *     
     */
    public void setDestinationBusUnattended(YesNoOption value) {
        this.destinationBusUnattended = value;
    }

    /**
     * Gets the value of the destinationBusDock property.
     * 
     * @return
     *     possible object is
     *     {@link YesNoOption }
     *     
     */
    public YesNoOption getDestinationBusDock() {
        return destinationBusDock;
    }

    /**
     * Sets the value of the destinationBusDock property.
     * 
     * @param value
     *     allowed object is
     *     {@link YesNoOption }
     *     
     */
    public void setDestinationBusDock(YesNoOption value) {
        this.destinationBusDock = value;
    }

    /**
     * Gets the value of the destinationBusForklift property.
     * 
     * @return
     *     possible object is
     *     {@link YesNoOption }
     *     
     */
    public YesNoOption getDestinationBusForklift() {
        return destinationBusForklift;
    }

    /**
     * Sets the value of the destinationBusForklift property.
     * 
     * @param value
     *     allowed object is
     *     {@link YesNoOption }
     *     
     */
    public void setDestinationBusForklift(YesNoOption value) {
        this.destinationBusForklift = value;
    }

    /**
     * Gets the value of the destinationBusLoadingFacilities property.
     * 
     * @return
     *     possible object is
     *     {@link YesNoOption }
     *     
     */
    public YesNoOption getDestinationBusLoadingFacilities() {
        return destinationBusLoadingFacilities;
    }

    /**
     * Sets the value of the destinationBusLoadingFacilities property.
     * 
     * @param value
     *     allowed object is
     *     {@link YesNoOption }
     *     
     */
    public void setDestinationBusLoadingFacilities(YesNoOption value) {
        this.destinationBusLoadingFacilities = value;
    }

    /**
     * Gets the value of the destinationBusInside property.
     * 
     * @return
     *     possible object is
     *     {@link YesNoOption }
     *     
     */
    public YesNoOption getDestinationBusInside() {
        return destinationBusInside;
    }

    /**
     * Sets the value of the destinationBusInside property.
     * 
     * @param value
     *     allowed object is
     *     {@link YesNoOption }
     *     
     */
    public void setDestinationBusInside(YesNoOption value) {
        this.destinationBusInside = value;
    }

    /**
     * Gets the value of the destinationBusNotifyBefore property.
     * 
     * @return
     *     possible object is
     *     {@link YesNoOption }
     *     
     */
    public YesNoOption getDestinationBusNotifyBefore() {
        return destinationBusNotifyBefore;
    }

    /**
     * Sets the value of the destinationBusNotifyBefore property.
     * 
     * @param value
     *     allowed object is
     *     {@link YesNoOption }
     *     
     */
    public void setDestinationBusNotifyBefore(YesNoOption value) {
        this.destinationBusNotifyBefore = value;
    }

    /**
     * Gets the value of the destinationBusLimitedAccess property.
     * 
     * @return
     *     possible object is
     *     {@link YesNoOption }
     *     
     */
    public YesNoOption getDestinationBusLimitedAccess() {
        return destinationBusLimitedAccess;
    }

    /**
     * Sets the value of the destinationBusLimitedAccess property.
     * 
     * @param value
     *     allowed object is
     *     {@link YesNoOption }
     *     
     */
    public void setDestinationBusLimitedAccess(YesNoOption value) {
        this.destinationBusLimitedAccess = value;
    }

    /**
     * Gets the value of the destinationBusHeavyLift property.
     * 
     * @return
     *     possible object is
     *     {@link YesNoOption }
     *     
     */
    public YesNoOption getDestinationBusHeavyLift() {
        return destinationBusHeavyLift;
    }

    /**
     * Sets the value of the destinationBusHeavyLift property.
     * 
     * @param value
     *     allowed object is
     *     {@link YesNoOption }
     *     
     */
    public void setDestinationBusHeavyLift(YesNoOption value) {
        this.destinationBusHeavyLift = value;
    }

    /**
     * Gets the value of the destinationBusTailgateLifter property.
     * 
     * @return
     *     possible object is
     *     {@link YesNoOption }
     *     
     */
    public YesNoOption getDestinationBusTailgateLifter() {
        return destinationBusTailgateLifter;
    }

    /**
     * Sets the value of the destinationBusTailgateLifter property.
     * 
     * @param value
     *     allowed object is
     *     {@link YesNoOption }
     *     
     */
    public void setDestinationBusTailgateLifter(YesNoOption value) {
        this.destinationBusTailgateLifter = value;
    }

    /**
     * Gets the value of the destinationBusContainerSwingLifter property.
     * 
     * @return
     *     possible object is
     *     {@link YesNoOption }
     *     
     */
    public YesNoOption getDestinationBusContainerSwingLifter() {
        return destinationBusContainerSwingLifter;
    }

    /**
     * Sets the value of the destinationBusContainerSwingLifter property.
     * 
     * @param value
     *     allowed object is
     *     {@link YesNoOption }
     *     
     */
    public void setDestinationBusContainerSwingLifter(YesNoOption value) {
        this.destinationBusContainerSwingLifter = value;
    }

    /**
     * Gets the value of the destinationResPostalBox property.
     * 
     * @return
     *     possible object is
     *     {@link YesNoOption }
     *     
     */
    public YesNoOption getDestinationResPostalBox() {
        return destinationResPostalBox;
    }

    /**
     * Sets the value of the destinationResPostalBox property.
     * 
     * @param value
     *     allowed object is
     *     {@link YesNoOption }
     *     
     */
    public void setDestinationResPostalBox(YesNoOption value) {
        this.destinationResPostalBox = value;
    }

    /**
     * Gets the value of the destinationResUnattended property.
     * 
     * @return
     *     possible object is
     *     {@link YesNoOption }
     *     
     */
    public YesNoOption getDestinationResUnattended() {
        return destinationResUnattended;
    }

    /**
     * Sets the value of the destinationResUnattended property.
     * 
     * @param value
     *     allowed object is
     *     {@link YesNoOption }
     *     
     */
    public void setDestinationResUnattended(YesNoOption value) {
        this.destinationResUnattended = value;
    }

    /**
     * Gets the value of the destinationResInside property.
     * 
     * @return
     *     possible object is
     *     {@link YesNoOption }
     *     
     */
    public YesNoOption getDestinationResInside() {
        return destinationResInside;
    }

    /**
     * Sets the value of the destinationResInside property.
     * 
     * @param value
     *     allowed object is
     *     {@link YesNoOption }
     *     
     */
    public void setDestinationResInside(YesNoOption value) {
        this.destinationResInside = value;
    }

    /**
     * Gets the value of the destinationResNotifyBefore property.
     * 
     * @return
     *     possible object is
     *     {@link YesNoOption }
     *     
     */
    public YesNoOption getDestinationResNotifyBefore() {
        return destinationResNotifyBefore;
    }

    /**
     * Sets the value of the destinationResNotifyBefore property.
     * 
     * @param value
     *     allowed object is
     *     {@link YesNoOption }
     *     
     */
    public void setDestinationResNotifyBefore(YesNoOption value) {
        this.destinationResNotifyBefore = value;
    }

    /**
     * Gets the value of the destinationResLimitedAccess property.
     * 
     * @return
     *     possible object is
     *     {@link YesNoOption }
     *     
     */
    public YesNoOption getDestinationResLimitedAccess() {
        return destinationResLimitedAccess;
    }

    /**
     * Sets the value of the destinationResLimitedAccess property.
     * 
     * @param value
     *     allowed object is
     *     {@link YesNoOption }
     *     
     */
    public void setDestinationResLimitedAccess(YesNoOption value) {
        this.destinationResLimitedAccess = value;
    }

    /**
     * Gets the value of the destinationResHeavyLift property.
     * 
     * @return
     *     possible object is
     *     {@link YesNoOption }
     *     
     */
    public YesNoOption getDestinationResHeavyLift() {
        return destinationResHeavyLift;
    }

    /**
     * Sets the value of the destinationResHeavyLift property.
     * 
     * @param value
     *     allowed object is
     *     {@link YesNoOption }
     *     
     */
    public void setDestinationResHeavyLift(YesNoOption value) {
        this.destinationResHeavyLift = value;
    }

    /**
     * Gets the value of the destinationResTailgateLifter property.
     * 
     * @return
     *     possible object is
     *     {@link YesNoOption }
     *     
     */
    public YesNoOption getDestinationResTailgateLifter() {
        return destinationResTailgateLifter;
    }

    /**
     * Sets the value of the destinationResTailgateLifter property.
     * 
     * @param value
     *     allowed object is
     *     {@link YesNoOption }
     *     
     */
    public void setDestinationResTailgateLifter(YesNoOption value) {
        this.destinationResTailgateLifter = value;
    }

    /**
     * Gets the value of the originIs property.
     * 
     * @return
     *     possible object is
     *     {@link LocationType }
     *     
     */
    public LocationType getOriginIs() {
        return originIs;
    }

    /**
     * Sets the value of the originIs property.
     * 
     * @param value
     *     allowed object is
     *     {@link LocationType }
     *     
     */
    public void setOriginIs(LocationType value) {
        this.originIs = value;
    }

    /**
     * Gets the value of the originBusUnattended property.
     * 
     * @return
     *     possible object is
     *     {@link YesNoOption }
     *     
     */
    public YesNoOption getOriginBusUnattended() {
        return originBusUnattended;
    }

    /**
     * Sets the value of the originBusUnattended property.
     * 
     * @param value
     *     allowed object is
     *     {@link YesNoOption }
     *     
     */
    public void setOriginBusUnattended(YesNoOption value) {
        this.originBusUnattended = value;
    }

    /**
     * Gets the value of the originBusDock property.
     * 
     * @return
     *     possible object is
     *     {@link YesNoOption }
     *     
     */
    public YesNoOption getOriginBusDock() {
        return originBusDock;
    }

    /**
     * Sets the value of the originBusDock property.
     * 
     * @param value
     *     allowed object is
     *     {@link YesNoOption }
     *     
     */
    public void setOriginBusDock(YesNoOption value) {
        this.originBusDock = value;
    }

    /**
     * Gets the value of the originBusForklift property.
     * 
     * @return
     *     possible object is
     *     {@link YesNoOption }
     *     
     */
    public YesNoOption getOriginBusForklift() {
        return originBusForklift;
    }

    /**
     * Sets the value of the originBusForklift property.
     * 
     * @param value
     *     allowed object is
     *     {@link YesNoOption }
     *     
     */
    public void setOriginBusForklift(YesNoOption value) {
        this.originBusForklift = value;
    }

    /**
     * Gets the value of the originBusLoadingFacilities property.
     * 
     * @return
     *     possible object is
     *     {@link YesNoOption }
     *     
     */
    public YesNoOption getOriginBusLoadingFacilities() {
        return originBusLoadingFacilities;
    }

    /**
     * Sets the value of the originBusLoadingFacilities property.
     * 
     * @param value
     *     allowed object is
     *     {@link YesNoOption }
     *     
     */
    public void setOriginBusLoadingFacilities(YesNoOption value) {
        this.originBusLoadingFacilities = value;
    }

    /**
     * Gets the value of the originBusInside property.
     * 
     * @return
     *     possible object is
     *     {@link YesNoOption }
     *     
     */
    public YesNoOption getOriginBusInside() {
        return originBusInside;
    }

    /**
     * Sets the value of the originBusInside property.
     * 
     * @param value
     *     allowed object is
     *     {@link YesNoOption }
     *     
     */
    public void setOriginBusInside(YesNoOption value) {
        this.originBusInside = value;
    }

    /**
     * Gets the value of the originBusNotifyBefore property.
     * 
     * @return
     *     possible object is
     *     {@link YesNoOption }
     *     
     */
    public YesNoOption getOriginBusNotifyBefore() {
        return originBusNotifyBefore;
    }

    /**
     * Sets the value of the originBusNotifyBefore property.
     * 
     * @param value
     *     allowed object is
     *     {@link YesNoOption }
     *     
     */
    public void setOriginBusNotifyBefore(YesNoOption value) {
        this.originBusNotifyBefore = value;
    }

    /**
     * Gets the value of the originBusLimitedAccess property.
     * 
     * @return
     *     possible object is
     *     {@link YesNoOption }
     *     
     */
    public YesNoOption getOriginBusLimitedAccess() {
        return originBusLimitedAccess;
    }

    /**
     * Sets the value of the originBusLimitedAccess property.
     * 
     * @param value
     *     allowed object is
     *     {@link YesNoOption }
     *     
     */
    public void setOriginBusLimitedAccess(YesNoOption value) {
        this.originBusLimitedAccess = value;
    }

    /**
     * Gets the value of the originBusHeavyLift property.
     * 
     * @return
     *     possible object is
     *     {@link YesNoOption }
     *     
     */
    public YesNoOption getOriginBusHeavyLift() {
        return originBusHeavyLift;
    }

    /**
     * Sets the value of the originBusHeavyLift property.
     * 
     * @param value
     *     allowed object is
     *     {@link YesNoOption }
     *     
     */
    public void setOriginBusHeavyLift(YesNoOption value) {
        this.originBusHeavyLift = value;
    }

    /**
     * Gets the value of the originBusTailgateLifter property.
     * 
     * @return
     *     possible object is
     *     {@link YesNoOption }
     *     
     */
    public YesNoOption getOriginBusTailgateLifter() {
        return originBusTailgateLifter;
    }

    /**
     * Sets the value of the originBusTailgateLifter property.
     * 
     * @param value
     *     allowed object is
     *     {@link YesNoOption }
     *     
     */
    public void setOriginBusTailgateLifter(YesNoOption value) {
        this.originBusTailgateLifter = value;
    }

    /**
     * Gets the value of the originBusContainerSwingLifter property.
     * 
     * @return
     *     possible object is
     *     {@link YesNoOption }
     *     
     */
    public YesNoOption getOriginBusContainerSwingLifter() {
        return originBusContainerSwingLifter;
    }

    /**
     * Sets the value of the originBusContainerSwingLifter property.
     * 
     * @param value
     *     allowed object is
     *     {@link YesNoOption }
     *     
     */
    public void setOriginBusContainerSwingLifter(YesNoOption value) {
        this.originBusContainerSwingLifter = value;
    }

    /**
     * Gets the value of the originResUnattended property.
     * 
     * @return
     *     possible object is
     *     {@link YesNoOption }
     *     
     */
    public YesNoOption getOriginResUnattended() {
        return originResUnattended;
    }

    /**
     * Sets the value of the originResUnattended property.
     * 
     * @param value
     *     allowed object is
     *     {@link YesNoOption }
     *     
     */
    public void setOriginResUnattended(YesNoOption value) {
        this.originResUnattended = value;
    }

    /**
     * Gets the value of the originResInside property.
     * 
     * @return
     *     possible object is
     *     {@link YesNoOption }
     *     
     */
    public YesNoOption getOriginResInside() {
        return originResInside;
    }

    /**
     * Sets the value of the originResInside property.
     * 
     * @param value
     *     allowed object is
     *     {@link YesNoOption }
     *     
     */
    public void setOriginResInside(YesNoOption value) {
        this.originResInside = value;
    }

    /**
     * Gets the value of the originResNotifyBefore property.
     * 
     * @return
     *     possible object is
     *     {@link YesNoOption }
     *     
     */
    public YesNoOption getOriginResNotifyBefore() {
        return originResNotifyBefore;
    }

    /**
     * Sets the value of the originResNotifyBefore property.
     * 
     * @param value
     *     allowed object is
     *     {@link YesNoOption }
     *     
     */
    public void setOriginResNotifyBefore(YesNoOption value) {
        this.originResNotifyBefore = value;
    }

    /**
     * Gets the value of the originResLimitedAccess property.
     * 
     * @return
     *     possible object is
     *     {@link YesNoOption }
     *     
     */
    public YesNoOption getOriginResLimitedAccess() {
        return originResLimitedAccess;
    }

    /**
     * Sets the value of the originResLimitedAccess property.
     * 
     * @param value
     *     allowed object is
     *     {@link YesNoOption }
     *     
     */
    public void setOriginResLimitedAccess(YesNoOption value) {
        this.originResLimitedAccess = value;
    }

    /**
     * Gets the value of the originResHeavyLift property.
     * 
     * @return
     *     possible object is
     *     {@link YesNoOption }
     *     
     */
    public YesNoOption getOriginResHeavyLift() {
        return originResHeavyLift;
    }

    /**
     * Sets the value of the originResHeavyLift property.
     * 
     * @param value
     *     allowed object is
     *     {@link YesNoOption }
     *     
     */
    public void setOriginResHeavyLift(YesNoOption value) {
        this.originResHeavyLift = value;
    }

    /**
     * Gets the value of the originResTailgateLifter property.
     * 
     * @return
     *     possible object is
     *     {@link YesNoOption }
     *     
     */
    public YesNoOption getOriginResTailgateLifter() {
        return originResTailgateLifter;
    }

    /**
     * Sets the value of the originResTailgateLifter property.
     * 
     * @param value
     *     allowed object is
     *     {@link YesNoOption }
     *     
     */
    public void setOriginResTailgateLifter(YesNoOption value) {
        this.originResTailgateLifter = value;
    }

    /**
     * Gets the value of the locationSelection property.
     * 
     * @return
     *     possible object is
     *     {@link LocationSelection }
     *     
     */
    public LocationSelection getLocationSelection() {
        return locationSelection;
    }

    /**
     * Sets the value of the locationSelection property.
     * 
     * @param value
     *     allowed object is
     *     {@link LocationSelection }
     *     
     */
    public void setLocationSelection(LocationSelection value) {
        this.locationSelection = value;
    }

}
