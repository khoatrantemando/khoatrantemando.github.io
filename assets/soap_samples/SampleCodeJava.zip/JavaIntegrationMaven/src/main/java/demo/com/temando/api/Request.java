
package demo.com.temando.api;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for Request complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="Request">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;all>
 *         &lt;element name="status" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}RequestStatus"/>
 *         &lt;element name="anythings" minOccurs="0">
 *           &lt;complexType>
 *             &lt;complexContent>
 *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                 &lt;sequence>
 *                   &lt;element name="anything" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}Anything" maxOccurs="10"/>
 *                 &lt;/sequence>
 *               &lt;/restriction>
 *             &lt;/complexContent>
 *           &lt;/complexType>
 *         &lt;/element>
 *         &lt;element name="anywhere" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}Anywhere" minOccurs="0"/>
 *         &lt;element name="anytime" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}Anytime" minOccurs="0"/>
 *         &lt;element name="general" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}General" minOccurs="0"/>
 *         &lt;element name="origin" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}Location" minOccurs="0"/>
 *         &lt;element name="destination" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}Location" minOccurs="0"/>
 *         &lt;element name="returnto" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}Location" minOccurs="0"/>
 *         &lt;element name="quotes" minOccurs="0">
 *           &lt;complexType>
 *             &lt;complexContent>
 *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                 &lt;sequence>
 *                   &lt;element name="quote" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}AvailableQuote" maxOccurs="unbounded" minOccurs="0"/>
 *                 &lt;/sequence>
 *               &lt;/restriction>
 *             &lt;/complexContent>
 *           &lt;/complexType>
 *         &lt;/element>
 *         &lt;element name="instructions" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}Instructions" minOccurs="0"/>
 *         &lt;element name="comments" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}Comments" minOccurs="0"/>
 *         &lt;element name="reference" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}ClientReference" minOccurs="0"/>
 *       &lt;/all>
 *       &lt;attribute name="id" type="{http://www.w3.org/2001/XMLSchema}positiveInteger" />
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "Request", namespace = "http://api-demo.temando.com/schema/2009_06/common.xsd", propOrder = {

})
public class Request {

    @XmlElement(required = true)
    protected RequestStatus status;
    protected Request.Anythings anythings;
    protected Anywhere anywhere;
    protected Anytime anytime;
    protected General general;
    protected Location origin;
    protected Location destination;
    protected Location returnto;
    protected Request.Quotes quotes;
    protected String instructions;
    protected String comments;
    protected String reference;
    @XmlAttribute(name = "id")
    @XmlSchemaType(name = "positiveInteger")
    protected BigInteger id;

    /**
     * Gets the value of the status property.
     * 
     * @return
     *     possible object is
     *     {@link RequestStatus }
     *     
     */
    public RequestStatus getStatus() {
        return status;
    }

    /**
     * Sets the value of the status property.
     * 
     * @param value
     *     allowed object is
     *     {@link RequestStatus }
     *     
     */
    public void setStatus(RequestStatus value) {
        this.status = value;
    }

    /**
     * Gets the value of the anythings property.
     * 
     * @return
     *     possible object is
     *     {@link Request.Anythings }
     *     
     */
    public Request.Anythings getAnythings() {
        return anythings;
    }

    /**
     * Sets the value of the anythings property.
     * 
     * @param value
     *     allowed object is
     *     {@link Request.Anythings }
     *     
     */
    public void setAnythings(Request.Anythings value) {
        this.anythings = value;
    }

    /**
     * Gets the value of the anywhere property.
     * 
     * @return
     *     possible object is
     *     {@link Anywhere }
     *     
     */
    public Anywhere getAnywhere() {
        return anywhere;
    }

    /**
     * Sets the value of the anywhere property.
     * 
     * @param value
     *     allowed object is
     *     {@link Anywhere }
     *     
     */
    public void setAnywhere(Anywhere value) {
        this.anywhere = value;
    }

    /**
     * Gets the value of the anytime property.
     * 
     * @return
     *     possible object is
     *     {@link Anytime }
     *     
     */
    public Anytime getAnytime() {
        return anytime;
    }

    /**
     * Sets the value of the anytime property.
     * 
     * @param value
     *     allowed object is
     *     {@link Anytime }
     *     
     */
    public void setAnytime(Anytime value) {
        this.anytime = value;
    }

    /**
     * Gets the value of the general property.
     * 
     * @return
     *     possible object is
     *     {@link General }
     *     
     */
    public General getGeneral() {
        return general;
    }

    /**
     * Sets the value of the general property.
     * 
     * @param value
     *     allowed object is
     *     {@link General }
     *     
     */
    public void setGeneral(General value) {
        this.general = value;
    }

    /**
     * Gets the value of the origin property.
     * 
     * @return
     *     possible object is
     *     {@link Location }
     *     
     */
    public Location getOrigin() {
        return origin;
    }

    /**
     * Sets the value of the origin property.
     * 
     * @param value
     *     allowed object is
     *     {@link Location }
     *     
     */
    public void setOrigin(Location value) {
        this.origin = value;
    }

    /**
     * Gets the value of the destination property.
     * 
     * @return
     *     possible object is
     *     {@link Location }
     *     
     */
    public Location getDestination() {
        return destination;
    }

    /**
     * Sets the value of the destination property.
     * 
     * @param value
     *     allowed object is
     *     {@link Location }
     *     
     */
    public void setDestination(Location value) {
        this.destination = value;
    }

    /**
     * Gets the value of the returnto property.
     * 
     * @return
     *     possible object is
     *     {@link Location }
     *     
     */
    public Location getReturnto() {
        return returnto;
    }

    /**
     * Sets the value of the returnto property.
     * 
     * @param value
     *     allowed object is
     *     {@link Location }
     *     
     */
    public void setReturnto(Location value) {
        this.returnto = value;
    }

    /**
     * Gets the value of the quotes property.
     * 
     * @return
     *     possible object is
     *     {@link Request.Quotes }
     *     
     */
    public Request.Quotes getQuotes() {
        return quotes;
    }

    /**
     * Sets the value of the quotes property.
     * 
     * @param value
     *     allowed object is
     *     {@link Request.Quotes }
     *     
     */
    public void setQuotes(Request.Quotes value) {
        this.quotes = value;
    }

    /**
     * Gets the value of the instructions property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getInstructions() {
        return instructions;
    }

    /**
     * Sets the value of the instructions property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setInstructions(String value) {
        this.instructions = value;
    }

    /**
     * Gets the value of the comments property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getComments() {
        return comments;
    }

    /**
     * Sets the value of the comments property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setComments(String value) {
        this.comments = value;
    }

    /**
     * Gets the value of the reference property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getReference() {
        return reference;
    }

    /**
     * Sets the value of the reference property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setReference(String value) {
        this.reference = value;
    }

    /**
     * Gets the value of the id property.
     * 
     * @return
     *     possible object is
     *     {@link BigInteger }
     *     
     */
    public BigInteger getId() {
        return id;
    }

    /**
     * Sets the value of the id property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigInteger }
     *     
     */
    public void setId(BigInteger value) {
        this.id = value;
    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType>
     *   &lt;complexContent>
     *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
     *       &lt;sequence>
     *         &lt;element name="anything" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}Anything" maxOccurs="10"/>
     *       &lt;/sequence>
     *     &lt;/restriction>
     *   &lt;/complexContent>
     * &lt;/complexType>
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "anything"
    })
    public static class Anythings {

        @XmlElement(required = true)
        protected List<Anything> anything;

        /**
         * Gets the value of the anything property.
         * 
         * <p>
         * This accessor method returns a reference to the live list,
         * not a snapshot. Therefore any modification you make to the
         * returned list will be present inside the JAXB object.
         * This is why there is not a <CODE>set</CODE> method for the anything property.
         * 
         * <p>
         * For example, to add a new item, do as follows:
         * <pre>
         *    getAnything().add(newItem);
         * </pre>
         * 
         * 
         * <p>
         * Objects of the following type(s) are allowed in the list
         * {@link Anything }
         * 
         * 
         */
        public List<Anything> getAnything() {
            if (anything == null) {
                anything = new ArrayList<Anything>();
            }
            return this.anything;
        }

    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType>
     *   &lt;complexContent>
     *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
     *       &lt;sequence>
     *         &lt;element name="quote" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}AvailableQuote" maxOccurs="unbounded" minOccurs="0"/>
     *       &lt;/sequence>
     *     &lt;/restriction>
     *   &lt;/complexContent>
     * &lt;/complexType>
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "quote"
    })
    public static class Quotes {

        protected List<AvailableQuote> quote;

        /**
         * Gets the value of the quote property.
         * 
         * <p>
         * This accessor method returns a reference to the live list,
         * not a snapshot. Therefore any modification you make to the
         * returned list will be present inside the JAXB object.
         * This is why there is not a <CODE>set</CODE> method for the quote property.
         * 
         * <p>
         * For example, to add a new item, do as follows:
         * <pre>
         *    getQuote().add(newItem);
         * </pre>
         * 
         * 
         * <p>
         * Objects of the following type(s) are allowed in the list
         * {@link AvailableQuote }
         * 
         * 
         */
        public List<AvailableQuote> getQuote() {
            if (quote == null) {
                quote = new ArrayList<AvailableQuote>();
            }
            return this.quote;
        }

    }

}
