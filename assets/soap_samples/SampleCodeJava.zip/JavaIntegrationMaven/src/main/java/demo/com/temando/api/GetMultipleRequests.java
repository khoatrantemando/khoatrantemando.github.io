
package demo.com.temando.api;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for anonymous complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType>
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;all>
 *         &lt;element name="requests">
 *           &lt;complexType>
 *             &lt;complexContent>
 *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                 &lt;sequence>
 *                   &lt;element name="requestId" type="{http://www.w3.org/2001/XMLSchema}positiveInteger" maxOccurs="500"/>
 *                 &lt;/sequence>
 *               &lt;/restriction>
 *             &lt;/complexContent>
 *           &lt;/complexType>
 *         &lt;/element>
 *         &lt;element name="labelPrinterType" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}LabelPrinterType" minOccurs="0"/>
 *         &lt;element name="clientId" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}ClientId" minOccurs="0"/>
 *       &lt;/all>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {

})
@XmlRootElement(name = "getMultipleRequests")
public class GetMultipleRequests {

    @XmlElement(required = true)
    protected GetMultipleRequests.Requests requests;
    protected LabelPrinterType labelPrinterType;
    protected Integer clientId;

    /**
     * Gets the value of the requests property.
     * 
     * @return
     *     possible object is
     *     {@link GetMultipleRequests.Requests }
     *     
     */
    public GetMultipleRequests.Requests getRequests() {
        return requests;
    }

    /**
     * Sets the value of the requests property.
     * 
     * @param value
     *     allowed object is
     *     {@link GetMultipleRequests.Requests }
     *     
     */
    public void setRequests(GetMultipleRequests.Requests value) {
        this.requests = value;
    }

    /**
     * Gets the value of the labelPrinterType property.
     * 
     * @return
     *     possible object is
     *     {@link LabelPrinterType }
     *     
     */
    public LabelPrinterType getLabelPrinterType() {
        return labelPrinterType;
    }

    /**
     * Sets the value of the labelPrinterType property.
     * 
     * @param value
     *     allowed object is
     *     {@link LabelPrinterType }
     *     
     */
    public void setLabelPrinterType(LabelPrinterType value) {
        this.labelPrinterType = value;
    }

    /**
     * Gets the value of the clientId property.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getClientId() {
        return clientId;
    }

    /**
     * Sets the value of the clientId property.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setClientId(Integer value) {
        this.clientId = value;
    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType>
     *   &lt;complexContent>
     *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
     *       &lt;sequence>
     *         &lt;element name="requestId" type="{http://www.w3.org/2001/XMLSchema}positiveInteger" maxOccurs="500"/>
     *       &lt;/sequence>
     *     &lt;/restriction>
     *   &lt;/complexContent>
     * &lt;/complexType>
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "requestId"
    })
    public static class Requests {

        @XmlElement(required = true)
        @XmlSchemaType(name = "positiveInteger")
        protected List<BigInteger> requestId;

        /**
         * Gets the value of the requestId property.
         * 
         * <p>
         * This accessor method returns a reference to the live list,
         * not a snapshot. Therefore any modification you make to the
         * returned list will be present inside the JAXB object.
         * This is why there is not a <CODE>set</CODE> method for the requestId property.
         * 
         * <p>
         * For example, to add a new item, do as follows:
         * <pre>
         *    getRequestId().add(newItem);
         * </pre>
         * 
         * 
         * <p>
         * Objects of the following type(s) are allowed in the list
         * {@link BigInteger }
         * 
         * 
         */
        public List<BigInteger> getRequestId() {
            if (requestId == null) {
                requestId = new ArrayList<BigInteger>();
            }
            return this.requestId;
        }

    }

}
