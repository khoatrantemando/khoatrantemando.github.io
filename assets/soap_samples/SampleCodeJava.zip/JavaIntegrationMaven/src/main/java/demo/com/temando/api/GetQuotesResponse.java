
package demo.com.temando.api;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for anonymous complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType>
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;all>
 *         &lt;element name="anythings" minOccurs="0">
 *           &lt;complexType>
 *             &lt;complexContent>
 *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                 &lt;sequence>
 *                   &lt;element name="anything" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}Anything" maxOccurs="10"/>
 *                 &lt;/sequence>
 *               &lt;/restriction>
 *             &lt;/complexContent>
 *           &lt;/complexType>
 *         &lt;/element>
 *         &lt;element name="anywhere" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}Anywhere" minOccurs="0"/>
 *         &lt;element name="anytime" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}Anytime" minOccurs="0"/>
 *         &lt;element name="quotes">
 *           &lt;complexType>
 *             &lt;complexContent>
 *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                 &lt;sequence>
 *                   &lt;element name="quote" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}AvailableQuote" maxOccurs="unbounded" minOccurs="0"/>
 *                 &lt;/sequence>
 *               &lt;/restriction>
 *             &lt;/complexContent>
 *           &lt;/complexType>
 *         &lt;/element>
 *       &lt;/all>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {

})
@XmlRootElement(name = "getQuotesResponse")
public class GetQuotesResponse {

    protected GetQuotesResponse.Anythings anythings;
    protected Anywhere anywhere;
    protected Anytime anytime;
    @XmlElement(required = true)
    protected GetQuotesResponse.Quotes quotes;

    /**
     * Gets the value of the anythings property.
     * 
     * @return
     *     possible object is
     *     {@link GetQuotesResponse.Anythings }
     *     
     */
    public GetQuotesResponse.Anythings getAnythings() {
        return anythings;
    }

    /**
     * Sets the value of the anythings property.
     * 
     * @param value
     *     allowed object is
     *     {@link GetQuotesResponse.Anythings }
     *     
     */
    public void setAnythings(GetQuotesResponse.Anythings value) {
        this.anythings = value;
    }

    /**
     * Gets the value of the anywhere property.
     * 
     * @return
     *     possible object is
     *     {@link Anywhere }
     *     
     */
    public Anywhere getAnywhere() {
        return anywhere;
    }

    /**
     * Sets the value of the anywhere property.
     * 
     * @param value
     *     allowed object is
     *     {@link Anywhere }
     *     
     */
    public void setAnywhere(Anywhere value) {
        this.anywhere = value;
    }

    /**
     * Gets the value of the anytime property.
     * 
     * @return
     *     possible object is
     *     {@link Anytime }
     *     
     */
    public Anytime getAnytime() {
        return anytime;
    }

    /**
     * Sets the value of the anytime property.
     * 
     * @param value
     *     allowed object is
     *     {@link Anytime }
     *     
     */
    public void setAnytime(Anytime value) {
        this.anytime = value;
    }

    /**
     * Gets the value of the quotes property.
     * 
     * @return
     *     possible object is
     *     {@link GetQuotesResponse.Quotes }
     *     
     */
    public GetQuotesResponse.Quotes getQuotes() {
        return quotes;
    }

    /**
     * Sets the value of the quotes property.
     * 
     * @param value
     *     allowed object is
     *     {@link GetQuotesResponse.Quotes }
     *     
     */
    public void setQuotes(GetQuotesResponse.Quotes value) {
        this.quotes = value;
    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType>
     *   &lt;complexContent>
     *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
     *       &lt;sequence>
     *         &lt;element name="anything" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}Anything" maxOccurs="10"/>
     *       &lt;/sequence>
     *     &lt;/restriction>
     *   &lt;/complexContent>
     * &lt;/complexType>
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "anything"
    })
    public static class Anythings {

        @XmlElement(required = true)
        protected List<Anything> anything;

        /**
         * Gets the value of the anything property.
         * 
         * <p>
         * This accessor method returns a reference to the live list,
         * not a snapshot. Therefore any modification you make to the
         * returned list will be present inside the JAXB object.
         * This is why there is not a <CODE>set</CODE> method for the anything property.
         * 
         * <p>
         * For example, to add a new item, do as follows:
         * <pre>
         *    getAnything().add(newItem);
         * </pre>
         * 
         * 
         * <p>
         * Objects of the following type(s) are allowed in the list
         * {@link Anything }
         * 
         * 
         */
        public List<Anything> getAnything() {
            if (anything == null) {
                anything = new ArrayList<Anything>();
            }
            return this.anything;
        }

    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType>
     *   &lt;complexContent>
     *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
     *       &lt;sequence>
     *         &lt;element name="quote" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}AvailableQuote" maxOccurs="unbounded" minOccurs="0"/>
     *       &lt;/sequence>
     *     &lt;/restriction>
     *   &lt;/complexContent>
     * &lt;/complexType>
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "quote"
    })
    public static class Quotes {

        protected List<AvailableQuote> quote;

        /**
         * Gets the value of the quote property.
         * 
         * <p>
         * This accessor method returns a reference to the live list,
         * not a snapshot. Therefore any modification you make to the
         * returned list will be present inside the JAXB object.
         * This is why there is not a <CODE>set</CODE> method for the quote property.
         * 
         * <p>
         * For example, to add a new item, do as follows:
         * <pre>
         *    getQuote().add(newItem);
         * </pre>
         * 
         * 
         * <p>
         * Objects of the following type(s) are allowed in the list
         * {@link AvailableQuote }
         * 
         * 
         */
        public List<AvailableQuote> getQuote() {
            if (quote == null) {
                quote = new ArrayList<AvailableQuote>();
            }
            return this.quote;
        }

    }

}
