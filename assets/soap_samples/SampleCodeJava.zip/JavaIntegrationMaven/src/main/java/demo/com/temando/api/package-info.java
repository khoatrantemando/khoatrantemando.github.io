@javax.xml.bind.annotation.XmlSchema(namespace = "http://api-demo.temando.com/schema/2009_06/server.xsd")
package demo.com.temando.api;
