-------------------------------------------
  -  VP-ASP TEMANDO SHIPPING README  -
  Compatitable with VPASP 7.01
-------------------------------------------
Contents:

A. SUMMARY
B. FILES STRUCTURES
C. INSTALLATION INSTRUCTIONS
D. HOW IT WORKS
E. FILES MODIFIED
F. CONFIGURATION SETTINGS CHANGED
G. DATABASE TABLES MODIFIED
H. LANGUAGE SETTINGS CHANGED
I. COPYRIGHT NOTICE
J. TERMS AND CONDITIONS

***********************************************************************************

A. SUMMARY
==========
1. Temando Shipping allowed instantly compare rates and services from a wide range of freight carriers and courier. 
   Customer is able to requests quote at the front store during checkout
   Merchant is able to Re-requset Quote /Make Booking for orders.

***********************************************************************************

B. FILES STRUCTURES
===================

Files included in the zip are:
 - Temando Shipping-readme.txt
 - shop_temando_generatexml.asp
 - shop_temandopostajax.asp
 - shopajaxshippingzipcodecountry_temando.asp
 - shopcountries_temando.asp
 - shopstates_temando.asp
 - shoptemandoincludes.asp
 - shoptemandoshippingajax.asp
 - shoptemandoshippingajaxupdate.asp
 - shoptemandoshippingupdate.asp
 - temando_tracking.asp
 - temando_tracking_ajax.asp
 - temandoshipping.asp
 - shopcreateorder.asp
 - shopcustadmin.asp
 - shopcustomer.asp
 - shopcustomerdesign.asp
 - shopcustomerform.asp
 - shopaddtocart.asp
 - shopaddtocartdesign.asp
 - shopmysqlsubs.asp
 - shop$db.asp 
 - shopcartformatdesign.asp
 - shopupdatecartprices.asp
 - shop_temando_adminsubs.asp
 - shop_temando_checkout_forms.asp
 - js\temando_shopajaxshipping.js
 - images\temando_logo.jpg
 - admin\base64.asp
 - admin\shopa_editdisplaybulk_temando.asp
 - admin\shopa_formatorder_temando.asp
 - admin\shopa_temando_changedefaultsupplier.asp
 - admin\shopa_temando_configure.asp
 - admin\shopa_temando_createclient.asp
 - admin\shopa_temando_packaging.asp
 - admin\shopa_temando_registration_2.asp
 - admin\shopa_temando_regsitration_1.asp
 - admin\shopa_temandoeditshipping.asp
 - admin\shopa_temandosql.asp
 - admin\shopa_temandosql_function.asp
 - admin\shopa_temandosubs.asp
 - admin\temandosetup.asp
 - admin\temandosetupsub.asp
 - admin\adminheaders.asp
 - admin\shopa_addproduct.asp
 - admin\shopa_displayorders.asp
 - shopa_displayorders_temandosubs.asp
 - admin\shopa_editrecord.asp
 - admin\stylesheets\temando-style.css
 - admin\js\temandoupdatedata.js
 - admin\help\shoph_temandoconfig.asp
 - admin\help\shoph_temandosignup.asp
 - admin\help\shoph_editrecord.asp
 - admin\help\shoph_producthelp.asp
 - admin\images\temando_logo.jpg
 - admin\images\bg.png
 - admin\images\footer.png
 - admin\images\install-button.png
 - admin\images\vpasp-logo.png
 - admin\images\temandoloading.gif
 - admin\sqlscripts\$temando-access.txt
 - admin\sqlscripts\$temando-mysql.txt
 - admin\sqlscripts\$temando-sqlserver.txt
 - admin\temandodata\temandodata.csv
 
***********************************************************************************

C. INSTALLATION INSTRUCTIONS
============================
1. Back up the following VPASP files:
 - shopcreateorder.asp
 - shopcustadmin.asp
 - shopcustomer.asp
 - shopcustomerdesign.asp
 - shopcustomerform.asp
 - shopaddtocart.asp
 - shopaddtocartdesign.asp
 - shopmysqlsubs.asp
 - shop$db.asp 
 - shopcartformatdesign.asp
 - shopupdatecartprices.asp
 - admin\adminheaders.asp
 - admin\shopa_addproduct.asp
 - admin\shopa_displayorders.asp
 - admin\shopa_editrecord.asp
 - admin\help\shoph_editrecord.asp
 - admin\help\shoph_producthelp.asp
 
* If you DO NOT made any changes to the above files, please ignore below section.

   ***********************************************************************************

   If you HAVE made significant changes to your above files, 
   then please use winmerge to compare your codes.

   To do this, please follow these steps.

   1. Download a program called WinMerge (http://winmerge.sourceforge.net/), which will allow you to compare your files with those in the patch.

   2. Unzip the patch files to a folder on your computer

   4. Download the files included in the patch from your live site into another folder on your computer.

   5. Run WinMerge and compare the contents of 2 folders.

   6. Save the patched files.
   
   7. Back up the files to be patched on the server.

   8. Upload the patched files to your server

   9. Test your site to ensure there have been no problems.

   ***********************************************************************************

2. Upload all the files into your shopping cart folder.

3. Log into Super Admin.

4. Run admin/temandosetup.asp, Eg. http://www.yourdomain.com/yourstore/youradminfoldername/temandosetup.asp

5. At Temando Shipping Setup page, click on the Install Now button to start the installation, it may takes 8 - 15 mins.

6. You will see a similar message, once the setup precess is completed :
   "The Temando shipping initial setup has now been completed. Please click here to return to your Control Panel. 
   Then please log out of your Control Panel and log back in to be able to view your new Temando shipping functionality!"

   click on the link back to Admin home & relogin.

7. After relogin, you have to create a new Temando account / login in with your existing Temando account
   First, go to Modules > Temando, then follow the steps below.
7a. For New Temando user , click on the Temando Registration Wizard
    Step 1. At page Temando Registration Wizard - Step 1, Click on Next button to continue.
	Step 2. At page Please read and accept the registration conditions before continuing., you need to read & agree the registration conditions by checking the checkbox beside "Yes, I accept" then click on Continue button to move to next step.
	Step 3. Temando Registration Wizard Step 3, you will see a Temando Login Details section, please enter a value for all the fileds.
	       ** All fields are MANDATORY.
	       - Login ID: Please enter your new Temando Login ID using alphanumeric characters (a-z or A-Z, 0-9)
	       - Password: Please enter your new Temando password using alphanumeric characters (a-z or A-Z, 0-9)
	       - Confirm Password: Please enter your new Temando password again to verify.
	       - Company No: Please enter your company number or ABN.
	       - Company Name: Please enter your full name of your company.
	       - Company Contact: Please enter the name of the person in your company to represent you to Temando.
	       - Email: Please enter your email address.
	       - Phone: Please enter your full phone number including area code.
	       - Country: Please select the name of your country from the list.
	Step 4. Click on Sign Up button after filled up all fileds.
    Step 5. if there is an error, please correct it & click on Sign Up button again. (Skip this step if there is no error occurred.)
	Step 6. System will redirect you to a page Temando configuration and alerts, when your account is successfully created.

7b. For Existing Temando User, 
    Step 1. Go to Modules > Temando
	Step 2. At page Temando Customer Login
    Step 3.	Enter your Temando Login ID in Temando Username
	Step 4.	Enter your Temando Login password in Temando Password
	Step 5. Then click on Continue button
    Step 6. If the login info is invalid, you will see a similar error message: 
            "The client's login details or id you have provided are either not a valid Username and Password combination or an invalid id."	
	        Please enter your login detail & make sure it is correct then click on Continue button.
	Step 7. System will redirect you to a page Temando configuration and alerts, when you are logged in successful.
        
8. After logged in, you are required to configure Temando setting at page Temando Shipping Configuration Settings. 
   Step 1. Go to Modules > Temando
   Step 2. Locate Configure Temando Shipping - For modifying the existing Temando settings.
   Step 3. Click on the link "Configure Temando Shipping" within the sentence.
   Step 4. Enter a value of each field at page Temando ShippingConfiguration Settings
   All the Temando Configurations are showing on this page.
   **All fields are MANDATORY

         Enable Temando ? 
         Please set to Yes if you would like to enable Temando Shipping in your store. Click on the "Change" link to modify setting.

         Temando Live? 
         Please set to Yes if you are using a "Live" Temando account. Click on the "Change" link to modify setting.

         Enable xAjax Shipping? 
         Please set to Yes if you would like to use Ajax Shipping.When the Ajax Shipping is enabled, the shipping methods/options will be displayed at the "Shipping Information" section on "CUSTOMER INFORMATION (shopcustomer.asp). 
         Customers are able to select the shipping methods/options from here & proceed to payment page.
         Click on the "Change" link to modify setting.

         Temando XML 
         XML Transport will be used in Temando Module

         Login ID 
         Please enter your Temando login ID

         Password 
         Please enter your Temando login Password

         Payment Type 
         If choosing "credit", please ensure you have sufficient credit in your Temando account.

         To add credit to your account, please utilise the VPASP Username / Password created for Temando and go to www.temando.com and login. 
         Once logged in, 
         1. select "Details" tab 
         2. Payment Details and enter the credit card (visa or mastercard with PayPal coming soon). 
         3. Select update and the Credit Top up amount appears � where a mimimum deposit of $200 can be deposited off a running balance (please ensure you save all updates). 
         This feature will automatically deduct each freight transaction from your account and recharge your saved credit card details once a minimum of $25 is achieved. 
         Pre-paying Temando waives any credit merchant facilities, as paying ad hoc is a 2% credit card surcharge. 
         Contact Temando via vpasp@temando.com or 1300 66 88 58 for further queries.
		 
         Hide Front Carrier Names 
         Please set to Yes if you do not want carrier names are shown to the customer.

         Insurance Option 
         Not Required - This option is unavailable to users. 
         Optional - The option is presented during checkout. 
         Required - Insurance must be added to all orders.
         
         Carbon Offset Option 
         Not Required - This option is unavailable to users. 
         Optional - The option is presented during checkout. 
         Required - Insurance must be added to all orders.

         Error from Temando processing 
         If you would like to display a Flat Rate to customers when there is an error returned from Temando.

         Pricing Method 
         Free Shipping - No charge to customer. 
         Fixed Price / Flat Rate - Customer always pays the amount set in "Shipping Price" below. 
         Dynamic Pricing 
         - All: All quotes from carriers in "allowed carriers" above are shown for the customer to choose from. 
         - Cheapest: Only the cheapest quote is shown. 
         - Fastest: Only the fastest quote is shown. 
         - Cheapest and Fastest: The customer can choose between the cheapest or the fastest quote.

         Default Supplier 
         You need to create at least 1 supplier & used as Default Supplier(shipping origin).
         Select the supplier you want to set as Default Supplier and Change default supplier button.

         Shipping Price 
         The shipping cost amount for Flat Rate 
         Handling Fee / Markup 
         For fix amount, please enter the amount & select "Fixed" in Handling Fee Calculation filed below. 
         For fix percent, please enter the 10 or 0.1 for 10% & select "Percent" in Handling Fee Calculation filed below.

         Ship to Specific countries 
         Use CTRL + click to select multiple countries

         Carrier Options 
         Use CTRL + click to select multiple carriers

         Packaging: The packaging type used in shipment.

         KGs per Satchel/Bag: If you have chosen 'Satchel/Bag' as your packaging type, please select the maximum weight of the satchel/bag.
         
		 Weight Type: Please enter the appropriate weight type.

         Length: Length of the packaging
         
         Width: Width of the packaging

         Height: Height of the packaging

         Dimension Type : Please enter the appropriate dimension type.

         Fragile: If the product is fragile, please select 'Yes'
		 
         Name: Drop Shippers/Suppliers name.

         Firstname: Contact person of the Drop Shippers/Suppliers first name.

         Lastname: Contact person of the Drop Shippers/Suppliers last name.

         Address: Address of the Drop Shippers/Suppliers.

         City: City of the Drop Shippers/Suppliers.

         State: State of the Drop Shippers/Suppliers.

         Postcode: Zip code of the Drop Shippers/Suppliers.

         Country: Country of the Drop Shippers/Suppliers.

         Company: Company name.

         Phone: Phone number.

         Workphone: Office phone number.

         Fax: Fax number.

         Email: Email of the Drop Shippers/Suppliers.

9. Define Products Weight, you have 2 ways to define the product weight. At Product Setup Page & Bulk Product Update(Temando Fields).
   ** You MUST define a weight for EACH of your product, else system will return error when your customers are making a request to get a quote from Temando.
   Product Setup Page:
   Step 1. Go to Store > Products
   Step 2. Locate the product you want to define the weight & click on the icon under Edit column.
   Step 3. At page Product Setup, locate Weight in Temando Shipping section.
   Step 4. Enter weight in Weight field, e.g. 20
   Step 5. Click on Update Record button to save.
   
   Bulk Product Update(Temando Fields):
   Step 1. Go to Modules > Temando
   Step 2. Locate Bulk Product Update(Temando Fields) then click on it.
   Step 3. Enter weight in Weight column.
   Step 3. Click on Update Record button once done all your changes.

10. Define Temando Fields (Packaging,Weight,Weight Unit,Length,Width,Height,Dimensions,Fragile,KGs per Satchel/Bag) in Product / Supplier
    By default, system will grab Temando Fields from Product level, if ANY ONE of the fields is empty, system will grab from Default Supplier.
	** Please note that ALL the fileds MUST be defined, if you want system to grab Temando Fields from Product level.
   
   Defind Temando Fields for Product   
   Step 1. Go to Store > Products
   Step 2. Locate the product you want to define the Temando Fields & click on the icon under Edit column.
   Step 3. At page Product Setup, locate Temando Shipping section.
   Step 4. Enter a value for all fields (Packaging,Weight,Weight Unit,Length,Width,Height,Dimensions,Fragile,KGs per Satchel/Bag).
   Step 5. Click on Update Record button to save.	
   
   Define Temando Fields for Default Supplier   
   Step 1. Go to Modules > Temando
   Step 2. Locate Configure Temando Shipping then click on it.
   Step 3. Locate Default Value, make your changes.
   Step 3. Click on Submit button once done all your changes.
	
11. Change Default Supplier
    Step 1. Go to Modules > Temando
    Step 2. Locate Configure Temando Shipping then click on it.
    Step 3. Locate Default Supplier
    Step 4. Select the supplier from the supplier drop down list.
    Step 5. Click on the Change default supplier button to change.

** Double Check**
1. Each product has a Weight defined.(refer to 9.)
2. You have sufficient credit in your Temando account,If choosing "credit" OR 
   your payment Account is Enabled in Temando.com if choosing "Account" as Payment Method.(refer to 8.)
3. Default Supplier is defined(refer to 11.)
4. Enable Temando Shipping? is set to Yes (refer to 8.)

Now Temando Shipping is working in your store.

***********************************************************************************

D. HOW IT WORKS
===============
1. How to Enable Temando in the store?
   Step 1. Go to Modules > Temando
   Step 2. Locate Configure Temando Shipping then click on it.
   Step 3. At page Temando Shipping Configuration Settings
   Step 4. Locate Enable Temando Shipping?, click on the link "Change" beside it.
   Step 5. At page Shop Configuration, locate xTemandoEnable
   Step 5. Set to Yes to Enable Temando in the store else set to No.
   Step 6. Press Continue button to save the setting.   
   
2. How to change Temando Shipping environment to Live or Testing mode?
   Step 1. Go to Modules > Temando
   Step 2. Locate Configure Temando Shipping then click on it.
   Step 3. At page Temando Shipping Configuration Settings
   Step 4. Locate Set Temando to Live?, click on the link "Change" beside it.
   Step 5. At page Shop Configuration, locate xTemandolive
   Step 5. Set to No for Testing mode else set to Yes
   Step 6. Press Continue button to save the setting.   
   
3. How to turn Ajax Shipping on / off?
   Step 1. Go to Modules > Temando
   Step 2. Locate Configure Temando Shipping then click on it.
   Step 3. At page Temando Shipping Configuration Settings
   Step 4. Locate Enable xAjax Shipping?, click on the link "Change" beside it.
   Step 5. At page Shop Configuration, locate xAjaxShipping
   Step 5. Set to Yes to turn on Ajax Shipping else set to No
   Step 6. Press Continue button to save the setting.  
   
4. How update my Temando profile ?
   Step 1. Go to Modules > Temando
   Step 2. Locate Configure Temando Shipping then click on it.
   Step 3. At page Temando Shipping Configuration Settings
   Step 4. Locate Login Id, click on the link "[Click here to retrieve / update your Temando profile]" beside it.
   Step 5. Make your changes in section Temando Login Details
   Step 5. Press Update Record button to save your profile.     

5. How to check if all my products have weight defined?
   Step 1. Go to Modules > Temando
   Step 2. At page Set up Temando Shipping
   Step 3. You will see a message similar as below if you have one (or more) item does not has weight:
           "- You have to define the weight for : 
			 23 Items"
   Step 4. Click on the link "23 Items", to define weight.(refer to 9.)
  
6. How to get a Estimated Shipping Cost before checkout.
   Step 1. Go to Front Store, add products to cart.
   Step 2. At page VIEW CART(shopaddtocart.asp), you will see a Shipping Cost box with fields: Ship Country & Ship Zip Code, below Continue / Recalculate / Checkout buttons
   Step 3. Select Country from Ship Country e.g Australia
   Step 4. Enter the zip code in Ship Zip Code e.g. 3000
   Step 5. Click on Get a Quote button to get a estimate shipping cost.
   Step 6. Once the system got the shipping cost, it will shows shipping cost & Total in the shopping cart under Product Cost.
		   e.g.
		   Est. Shipping( clear )	$8.60
 	 	   Total	$188.60
   Step 7. You can click on the link Clear beside Est. Shipping then get another new quote/ directly get a new quote by repeating Step3 - Step 5.

7. How to Checkout & select Temando as a shipping metohd(Ajax):
   Step 1. Go to Front Store, add products to cart & proceed to checkout.
   Step 2. At page Customer Information(shopcustomer.asp)
   Step 3. Enter Zip Code then press the "Tab" on your keyboard / move the mouse pointer out of the Zip Code field. system will auto populate City, State, Country for the select Zip Code.
   Step 4. You can select your City from the City drop down list.
   Step 5. At section Shipping Information
   Step 6. You can select to includes/ excludes Insurance or Carbon Offset to your shipment by checking the Checkbox beside Includes Insurance & Includes Carbon Offset
   Step 7. Select a the carrier option you want & press Continue button to proceed
           *You may see more than one carrier options but only ONE radio button when you have many items in cart, this is because the items are shipping from different 
		    Supplier(Origin), the shipment have to book seperatly in Admin. 
   Step 8. At page ORDER DETAILS, press Order Now!
   Step 9. Select a payment method and complete checkout process.
   
8. How to CheckoutCheckout & select Temando as a shipping metohd(Without Ajax):
   Step 1. Go to Front Store, add products to cart & proceed to checkout.
   Step 2. At page Customer Information(shopcustomer.asp)
   Step 3. Enter Zip Code then press the "Tab"/ "Enter" on your keyboard / move the mouse pointer out of the Zip Code field. system will auto populate City, State, Country for the select Zip Code.
   Step 4. You can select your City from the City drop down list.
   Step 5. At section Shipping Information
   Step 6. Select Temando in Shipping Method drop down list.
   Step 7. At page TEMANDO SHIPPING   
   Step 8. You can select to includes/ excludes Insurance or Carbon Offset to your shipment by checking the Checkbox beside Includes Insurance & Includes Carbon Offset
   Step 9. Select a the carrier option you want & press Continue button to proceed
           *You may see more than one carrier options but only ONE radio button when you have many items in cart, this is because the items are shipping from different 
		    Supplier(Origin), the shipment have to book seperatly. 
   Step 10. At page ORDER DETAILS, press Order Now!
   Step 11. Select a payment method and complete checkout process.
 
9. Make Booking in Admin page.:
   Step 1. Log into your online administration
   Step 2. Go to the Store > Orders
   Step 3. At page Orders, locate for the order orders that you want to make a booking for shipment, click on the Temando logo under Temando column.
   Step 4. Locate Temando Booking & Carrier Information section
   Step 5. You can see Shipment Status,Origin,Destination,Pick-up Date,Items Ordered,Boxes to Ship
   
           Shipment Status, display all information about booking, carrier, cost and etc.
		   Origin, display the Origin(Supplier) info of this shipment.		   
		   Destination, display the destination info of this shipment.		   
		   Pick-up Date, display the shipment date & time.
		   Items Ordered, Item detail in your order
		   Boxes to Ship, Item to ship for this order.
		   
   Step 6. You can make the changes on Destination,Pick-up Date,Items Ordered,Boxes to Ship before place a booking. (Skip if no change is required.)
           **Please make the changes & click on Save changes and get new quotes button to save changes & request a new quote from Temando
   Step 7. Select a Carrier by checking the Radio & click on Book Now! button to make a booking.
   Step 8. After booking has been confirmed. Temando will return Request ID, Booking Number, consignment Number & Consignment Note as below:
           Request ID: 239306 (Track)
           Booking Number: 12252
           Consignment Number: YY003872
           Consignment Document: YY003872.pdf 
   Step 8. If you more than one shipmet in same order, please repeat Step 6 -  Step 8.
   
10. How to check the Shipment status in Admin/ Front End?
    For Admin: 
    Step 1. Log into your online administration
    Step 2. Go to the Store > Orders
    Step 3. At page Orders, locate for the order orders that you want check the shipment status, click on the Temando logo under Temando column.
    Step 4. Locate Request ID in the Shipment Status section
    Step 5. You will see a link (Track) beside the Request ID, click on it
    Step 6. A full shipment info will be displaied on Temando Order Tracking page.
	
	For Customer: 
    Step 1. Log into your account in the front end.
    Step 2. Go to My Account
    Step 3. At page CUSTOMER SERVICE, locate link Order Tracking in Temando Shipping section then click on it.
    Step 4. Locate Order ID from the REVIEW PREVIOUS ORDERS list.
    Step 5. Click on the Supplier Name under Track column to see the Shipment Status.
 
***********************************************************************************

E. FILES MODIFIED
=================
 - shopcreateorder.asp
 - shopcustadmin.asp
 - shopcustomer.asp
 - shopcustomerdesign.asp
 - shopcustomerform.asp
 - shopaddtocart.asp
 - shopaddtocartdesign.asp
 - shopmysqlsubs.asp
 - shop$db.asp 
 - shopcartformatdesign.asp
 - admin\adminheaders.asp
 - admin\shopa_addproduct.asp
 - admin\shopa_displayorders.asp
 - admin\shopa_editrecord.asp
 - admin\help\shoph_editrecord.asp
 - admin\help\shoph_producthelp.asp

***********************************************************************************

F. CONFIGURATION SETTINGS CHANGED
=================================
 - xAjaxShipping : Yes to use Ajax shipping
 - xTemandoEnable : Yes to activate Temando Shipping.
 - xTemandolive : Set to No for Testing mode else set to Yes.
 - xTemandoXML : XML Transport will be used in Temando Module.

 ***********************************************************************************

G. DATABASE TABLES MODIFIED
===========================
1. Orders table:
   - table orders 
     temandoSelectedCarrier

   - table oitems
     temandoitemname
     temandoPackaging
     temandolength
     temandowidth
     temandoheight
     temandofragile
     temandoDimensiontype
     temandoweightunit
     temandoshipqty
     temandoshipweight
     temandoshipuniprice

   - table products
     temandoPackaging
     temandolength
     temandowidth
     temandoheight
     temandofragile
     temandoDimensiontype
     temandoweightunit
     temandosatchelkg

   - table suppliers
     temandoPackaging
     temandolength
     temandowidth
     temandoheight
     temandofragile
     temandounitweight
     temandoDimensiontype
     temandoDefaultsupplier
     temandosatchelkg

2. New Tables:
   - temando_carrier
   - temando_class
   - temando_config
   - temando_getQuotemaster
   - temando_getQuoteItems
   - temando_packaging
   - temando_quote
   - temando_state
   - temando_subclass
   - temando_suburb

***********************************************************************************

H. LANGUAGE SETTINGS CHANGED
============================
 - langPackaging : Packaging
 - langSpecifically : Specifically
 - langclass : Class
 - langtemandoshipping : Temando Shipping
 - langrequestid : Request ID
 - langlocationtype : Location Type
 - langsuburb : Suburb
 - langtemandoshippingcarrier : Temando Booking & Carrier Information
 - langtemandonotincountry : Temando shipping not available for the shipping country you selected.
 - langtemandonotenable : Temando Shipping is not enabled
 - langtemandonobookingdetail : No booking detail found.
 - langtemandoDimensions : Dimensions
 - langtemandolength : length
 - langtemandowidth : width
 - langtemandoheight : height
 - langtemandoContactPerson : Contact Person
 - langtemandoAutoseparateweight : Auto separate weight?
 - langtemandofragile : fragile
 - langtemandocontactdetail : Contact Details
 - langtemandodefaultitemconfiguration : Default Item Configuration
 - langtemandotemandoregistrationwizard : Temando Registration Wizard
 - langtemandologinid : Login Id
 - langtemandooption : Options
 - langtemandproductionlivemode : Production/Live Mode
 - langtemandohidefrontcarriernames : Hide Front Carrier Names
 - langtemandoweightunit : Weight Unit
 - langtemandoinsuranceoption : Insurance Option
 - langtemandocarbonoffsetoption : Carbon Offset Option
 - langtemandoshiptospecificcountries : Ship to Specific countries
 - langtemandocarrieroptions : Carrier Options
 - langtemandoselectmultiplerecord : hold Ctrl to select multiple record
 - langtemandologindetail : Temando Login Details
 - langtemandoclickheretoretrive : Click here to retrieve / update your Temando profile
 - langtemandoclientid : Client ID
 - langtemandocompanyname : Company Name
 - langtemandocompanycontactperson : Company Contact Person
 - langtemandocompanyno : Company No
 - langtemandoindisurname : Individual Surname
 - langtemandoindifirstname : Individual Firstname
 - langtemandoindidob : Individual Date Of Birth
 - langpostaladdress : Postal Address
 - langpostalcity : Postal City
 - langtemandonodefaultsupplier : No default Supplier defined in the system. please contact Administrator.
 - langtemandototalshipping : Total of Shipment Required : 
 - langtemandocustomerselected : Customer Selected
 - langtemandoshipmentdate : Shipment Date
 - langtemandoorigin : Origin
 - langtemandodestination : Destination
 - langtemandosupplier : Supplier
 - langtemandoRecipient : Recipient
 - langtemandoseemultiplecarrier : If you see multiple Carriers in the selection, meaning that items are stored in difference Supplier(Origin). We will send out separately. 
 - langtemandoupdatesql : Update Temando Data
 - langtemandodefaultsupplierconfig : Default Supplier
 - langtemandodefinedefaultsupplier : Please select/add a default supplier.
 - langtemandologout : Logout From Temando
 - langtemandouseexistingaccount : Use My Existing Temando Account
 - langtemandoenable : Enable Temando Shipping?
 - langtemandolive : Set Temando to Live?
 - langtemandobooked : Booked
 - langtemandopastshipmentdate : Shipment date is pass, Please change the Date in ''Pick-up Date'' section and press ''Save changes and get new quotes'' button.
 - langtemandosatchelkg : KGs per Satchel/Bag
 - langtemandobookingexist : Booking is already exist.
 - langtemandobulkupdateproduct : Bulk Product Update(Temando Fields)
 - langtemandochange : Change
 - langtemandochangedefaultsupplier : Change default supplier
 - langtemandoestcountryempty : Country Code is empty.
 - langtemandoestzipempty : Zip/Post Code is empty.
 - langtemandocheckagree : You have to Checked to agree the agreement at Insurance Option
 - langtemandoaddsupplier : <br>Click here to <b>Add New Suppliers</b>
 - langtemandopickupdate : Pick-up Date
 - langtemandovaluemoney : Value ($)
 - langtemandounit : Unit
 - langtemandocarrier : Carrier
 - langtemandodeliverymethod : Delivery Method
 - langtemandoeta : ETA
 - langtemandocost : Cost
 - langtemandonotes : Notes
 - langtemandoinvalinrequestid : Invalid Request/ Booking ID.
 - langtemandoestimatecost : * Estimated Shipping cost
 - langtemandosuburbnotfoundforzip : No City/ suburb found for this post/zip code.
 - langtemandoestshipping : Est. Shipping
 - langtemandoclear : clear
 - langtemandoweighterror : Error:<br>Weight is not defined for item below, please contact administrator or remove from cart.<br>
 - langtemandozeroweight : You have to define the weight for : 
 - langtemandonodefaultsupplieradmin : No Default Supplier found in the suppliers table, please define.
 - langtemandonusedifferentaddress : Use different shipping address to billing
 - langtemandodefaultvalue : Default Value
 - langtemandogeneral : General
 - langtemandoenableaxajaxshipping : Enable xAjax Shipping?
 - langtemandocarbonoffset : Carbon Offset
 - langtemandopricing : Pricing
 - langtemandoerrorprocessing : Error from Temando processing
 - langtemandopricingmethod : Pricing Method
 - langtemandomarkupfee : Handling Fee / Markup
 - langtemandomarkupfeecalc : Handling Fee Calculation
 - langtemandocosttimeofday : Time of Day
 - langtemandoxmltype : Temando XML
 - langtemandonocarrierfound : Error occurred while retrieving carrier info. Please enter Zip/Post Code & press Tab on the keyboard OR move the mouse pointer out from the filed to retrieve carrier again.
 - langtemandoboxestoship : Boxes to Ship
 - langtemandoitemsordered : Items Ordered
 - langtemandoproduct : Product
 - langtemandofreeshipitemremark : is a Free Shipping Item. Shipping cost has not paid by customer.
 - langtemandocarrierselectedbycustomer : Carrier Selected by Customer
 - langtemandoincludedeliveryinsurance : Include Delivery Insurance
 - langtemandoincludecarbonoffset : Include Carbon Offset
 - langtemandoshippingpaidbycustomer : Shipping Paid by Customer
 - langtemandofinalcarrierselected : Final Carrier Selected
 - langtemandofinalshippingamount : Final Shipping Amount
 - langtemandoalert : Temando Setup Alert - PLEASE DEAL WITH THE FOLLOWING ISSUES to make sure Temando Shipping is working properly at the front end:
 - langtemandowheretoship : Where will we send it? Calculate your shipping.
 - langtemandoenterpostcode : Enter Post Code
 - langtemandobooksuccess : Booking Successfully!
 - langtemandobookingnotdone : Booking not done at this time!
 - langtemandopasswordmin : Password length must be at least 6 characters.
 - langtemandopasswordmax : Password lenght can more than 20.
 - langtemandoregistration : Temando Registration Wizard - Step 
 - langtemandoregistrationpage1 : <p align="left">This wizard will assist you in completing the necessary registration requirements to activate and use the Temando from this application.</p><p align="left">If you do not wish to use any of the functions that utilize the Temando, click the Cancel button and those functions will not be enabled. </p><p align="left">If, at a later time, you wish to use the Temando, return to this section and complete the Temando registration process.</p>
 - langtemandoregistrationpage2title : Please read and accept the registration conditions before continuing.
 - langtemandoregistrationaccept : Yes, I accept
 - langtemandosignupmessage : Please enter your details to become a new customer with Temando, then click on the 'Sign Up' button. Place your mouse over the green ? for a detailed explanation on what is required for each of the fields.
 - langtemandobulkproductupdate : Temando Bulk Product Update
 - langtemandosaveandgetnewquotes : Save changes and get new quotes
 - langtemandocustomerlogin : Temando Customer Login
 - langtemandocustomerloginmsg1 : Please enter your Temando username & password to login to Temando.
 - langtemandocustomerloginmsg2 : If you are not registered with Temando please use the
 - langtemandocustomerloginmsg3 :  to create an account.
 - langtemandousername : Temando Username
 - langtemandopassword : Temando Password
 - langtemandoconfigmessage : Please click on the links below to configure or update Temando.
 - langtemandoconfigdesc :   - For modifying the existing Temando settings.
 - langtemandoupdetadatadesc :  - To upload the latest Temando Data.
 - langtemandobulkupdatedesc :  - Quickly update your products with required Temando information.
 - langtemandologoutdesc :  - Logout Temando account from VPASP
 - langtemandoconfigalert : Temando configuration and alerts
 - langtemandowebsite : Temando Website
 - langtemandowebsitedesc :  - To go to the Temando website to add funds.
 - langtemandoconfirmlogout : If you would like to log out of Temando, please click on the OK button, or click on Cancel to close this window. 
 - langtemandocreateordermsg : Please review your customer and shipping information.<br />If you wish to change any of the details please click on the ''Edit'' button in the appropriate section.<br />Once you are happy with the information, please click on the ''Order Now'' button to enter your payment details.
 - langtemandoproductfielderror : Please define either ALL of the ''Temando Shipping'' section fields or leave ALL of the ''Temando Shipping'' section fields empty.
 - langtemandosignuperrorloginid : Login ID not entered.
 - langtemandosignuperrorpassword : Password not entered.');
 - langtemandosignuperrorpassword2 : Confirm password not entered.');
 - langtemandosignuperrorcompanyname : Company name not entered.');
 - langtemandosignuperrorcompanyno : Company number not entered.');
 - langtemandosignuperrorcompanycontact : Company contact not entered.');
 - langtemandosignuperroremail : Email not entered.');
 - langtemandosignuperrorphone : Phone not entered.');
 - langtemandosignuperrorcountry : Country not entered.');
 - langtemandosignuperrorpasswordnotmatch : The passwords do not match, please reenter both passwords.');
 - langtemandobulkupdatemessage : Please ensure that you have entered information into ALL of the fields on the row/s that you are updating, or the default in the configuration page will be used.

***********************************************************************************

I. COPYRIGHT NOTICE 
============================

Copyright (c) 1999-2011 Rocksalt International Pty. Ltd.
All rights reserved.

This software and documentation constitute a published work and 
contains valuable trade secrets and proprietary information
belonging to Rocksalt International Pty. Ltd. .
None of the foregoing material may be copied, 
duplicated or disclosed without the express written permission
of Rocksalt International Pty. Ltd. .

LICENSEE ACCEPTS VP-ASP Shopping Cart "AS IS" "WITH ALL FAULTS", 
Rocksalt International Pty. Ltd.  accepts no responsibility for the
operation or performance of the VP-ASP Shopping Cart.
The entire risk of use and consequences of use of the
VP-ASP Shopping Cart falls completely on the Licensee
and Rocksalt International Pty. Ltd.  shall not be liable in any respect
for any claims, loss or injury alleged to have resulted
from use of or in reliance on VP-ASP Shopping Cart.

Licensee acknowledges that it has read the foregoing
disclaimers of warranty and limitation of liability 
and understands that Licensee assumes
the entire risk of using VP-ASP Shopping Cart.  

***********************************************************************************

J. TERMS AND CONDITIONS
============================
ROCKSALT INTERNATIONAL GRANTS TO THE LICENSEE A NON-EXCLUSIVE, 
NON-SUB LICENSABLE, NONTRANSFERABLE LICENSE
TO INSTALL AND USE THIS APPLICATION ON A SINGLE DOMAIN FOR
A SINGLE SHOP. 

THE CODE IN THE APPLICATION MAY BE MODIFIED FOR USE IN 
SETTING UP A SINGLE SHOPPING SITE ON THE WORLD WIDE WEB.
 
LICENSEE MAY MAKE A COPY OF THE APPLICATION FOR
BACK-UP AND ARCHIVAL PURPOSES, PROVIDED THAT ANY COPY
MUST CONTAIN ALL PROPRIETARY NOTICES INCLUDED
WITH THE APPLICATION.

LICENSEE IS PROHIBITED FROM SELLING OR DISTRIBUTING 
THE APPLICATION IN ANY MANNER.

LIMITATION OF LIABILITY. 

ROCKSALT INTERNATIONAL AND ITS LICENSORS SHALL
NOT BE LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE OR ANY
THIRD PARTY AS A RESULT OF USING OR DISTRIBUTING THIS
APPLICATION. 

IN NO EVENT WILL ROCKSALT INTERNATIONAL OR ITS LICENSORS
BE LIABLE FOR ANY LOST REVENUE, PROFIT OR DATA,
OR FOR DIRECT, INDIRECT, SPECIAL,
CONSEQUENTIAL, INCIDENTAL OR PUNITIVE DAMAGES,
HOWEVER CAUSED AND REGARDLESS OF THE THEORY OF LI
ARISING OUT OF THE USE OF OR INABILITY TO USE THE SOFTWARE,
EVEN IF ROCKSALT INTERNATIONAL HAS BEEN ADVISED OF THE 
POSSIBILITY OF SUCH DAMAGES.