
package demo.com.temando.api;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for anonymous complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType>
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;all>
 *         &lt;element name="anythings">
 *           &lt;complexType>
 *             &lt;complexContent>
 *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                 &lt;sequence>
 *                   &lt;element name="anything" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}Anything" maxOccurs="10"/>
 *                 &lt;/sequence>
 *               &lt;/restriction>
 *             &lt;/complexContent>
 *           &lt;/complexType>
 *         &lt;/element>
 *         &lt;element name="anywhere" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}Anywhere"/>
 *         &lt;element name="anytime" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}Anytime" minOccurs="0"/>
 *         &lt;element name="general" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}General" minOccurs="0"/>
 *         &lt;element name="origin" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}Location" minOccurs="0"/>
 *         &lt;element name="destination" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}Location" minOccurs="0"/>
 *         &lt;element name="quoteFilter" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}QuoteFilter" minOccurs="0"/>
 *         &lt;element name="clientId" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}ClientId" minOccurs="0"/>
 *       &lt;/all>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {

})
@XmlRootElement(name = "getQuotes")
public class GetQuotes {

    @XmlElement(required = true)
    protected GetQuotes.Anythings anythings;
    @XmlElement(required = true)
    protected Anywhere anywhere;
    protected Anytime anytime;
    protected General general;
    protected Location origin;
    protected Location destination;
    protected QuoteFilter quoteFilter;
    protected Integer clientId;

    /**
     * Gets the value of the anythings property.
     * 
     * @return
     *     possible object is
     *     {@link GetQuotes.Anythings }
     *     
     */
    public GetQuotes.Anythings getAnythings() {
        return anythings;
    }

    /**
     * Sets the value of the anythings property.
     * 
     * @param value
     *     allowed object is
     *     {@link GetQuotes.Anythings }
     *     
     */
    public void setAnythings(GetQuotes.Anythings value) {
        this.anythings = value;
    }

    /**
     * Gets the value of the anywhere property.
     * 
     * @return
     *     possible object is
     *     {@link Anywhere }
     *     
     */
    public Anywhere getAnywhere() {
        return anywhere;
    }

    /**
     * Sets the value of the anywhere property.
     * 
     * @param value
     *     allowed object is
     *     {@link Anywhere }
     *     
     */
    public void setAnywhere(Anywhere value) {
        this.anywhere = value;
    }

    /**
     * Gets the value of the anytime property.
     * 
     * @return
     *     possible object is
     *     {@link Anytime }
     *     
     */
    public Anytime getAnytime() {
        return anytime;
    }

    /**
     * Sets the value of the anytime property.
     * 
     * @param value
     *     allowed object is
     *     {@link Anytime }
     *     
     */
    public void setAnytime(Anytime value) {
        this.anytime = value;
    }

    /**
     * Gets the value of the general property.
     * 
     * @return
     *     possible object is
     *     {@link General }
     *     
     */
    public General getGeneral() {
        return general;
    }

    /**
     * Sets the value of the general property.
     * 
     * @param value
     *     allowed object is
     *     {@link General }
     *     
     */
    public void setGeneral(General value) {
        this.general = value;
    }

    /**
     * Gets the value of the origin property.
     * 
     * @return
     *     possible object is
     *     {@link Location }
     *     
     */
    public Location getOrigin() {
        return origin;
    }

    /**
     * Sets the value of the origin property.
     * 
     * @param value
     *     allowed object is
     *     {@link Location }
     *     
     */
    public void setOrigin(Location value) {
        this.origin = value;
    }

    /**
     * Gets the value of the destination property.
     * 
     * @return
     *     possible object is
     *     {@link Location }
     *     
     */
    public Location getDestination() {
        return destination;
    }

    /**
     * Sets the value of the destination property.
     * 
     * @param value
     *     allowed object is
     *     {@link Location }
     *     
     */
    public void setDestination(Location value) {
        this.destination = value;
    }

    /**
     * Gets the value of the quoteFilter property.
     * 
     * @return
     *     possible object is
     *     {@link QuoteFilter }
     *     
     */
    public QuoteFilter getQuoteFilter() {
        return quoteFilter;
    }

    /**
     * Sets the value of the quoteFilter property.
     * 
     * @param value
     *     allowed object is
     *     {@link QuoteFilter }
     *     
     */
    public void setQuoteFilter(QuoteFilter value) {
        this.quoteFilter = value;
    }

    /**
     * Gets the value of the clientId property.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getClientId() {
        return clientId;
    }

    /**
     * Sets the value of the clientId property.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setClientId(Integer value) {
        this.clientId = value;
    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType>
     *   &lt;complexContent>
     *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
     *       &lt;sequence>
     *         &lt;element name="anything" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}Anything" maxOccurs="10"/>
     *       &lt;/sequence>
     *     &lt;/restriction>
     *   &lt;/complexContent>
     * &lt;/complexType>
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "anything"
    })
    public static class Anythings {

        @XmlElement(required = true)
        protected List<Anything> anything;

        /**
         * Gets the value of the anything property.
         * 
         * <p>
         * This accessor method returns a reference to the live list,
         * not a snapshot. Therefore any modification you make to the
         * returned list will be present inside the JAXB object.
         * This is why there is not a <CODE>set</CODE> method for the anything property.
         * 
         * <p>
         * For example, to add a new item, do as follows:
         * <pre>
         *    getAnything().add(newItem);
         * </pre>
         * 
         * 
         * <p>
         * Objects of the following type(s) are allowed in the list
         * {@link Anything }
         * 
         * 
         */
        public List<Anything> getAnything() {
            if (anything == null) {
                anything = new ArrayList<Anything>();
            }
            return this.anything;
        }

    }

}
