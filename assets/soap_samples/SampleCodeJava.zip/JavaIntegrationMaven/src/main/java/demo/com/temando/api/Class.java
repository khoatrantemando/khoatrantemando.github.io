
package demo.com.temando.api;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for Class.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * <p>
 * <pre>
 * &lt;simpleType name="Class">
 *   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *     &lt;enumeration value="Freight"/>
 *     &lt;enumeration value="General Goods"/>
 *     &lt;enumeration value="Vehicle"/>
 *     &lt;enumeration value="Boat"/>
 *     &lt;enumeration value="Animal"/>
 *     &lt;enumeration value="Refrigerated"/>
 *     &lt;enumeration value="Other"/>
 *   &lt;/restriction>
 * &lt;/simpleType>
 * </pre>
 * 
 */
@XmlType(name = "Class", namespace = "http://api-demo.temando.com/schema/2009_06/common.xsd")
@XmlEnum
public enum Class {

    @XmlEnumValue("Freight")
    FREIGHT("Freight"),
    @XmlEnumValue("General Goods")
    GENERAL_GOODS("General Goods"),
    @XmlEnumValue("Vehicle")
    VEHICLE("Vehicle"),
    @XmlEnumValue("Boat")
    BOAT("Boat"),
    @XmlEnumValue("Animal")
    ANIMAL("Animal"),
    @XmlEnumValue("Refrigerated")
    REFRIGERATED("Refrigerated"),
    @XmlEnumValue("Other")
    OTHER("Other");
    private final String value;

    Class(String v) {
        value = v;
    }

    public String value() {
        return value;
    }

    public static Class fromValue(String v) {
        for (Class c: Class.values()) {
            if (c.value.equals(v)) {
                return c;
            }
        }
        throw new IllegalArgumentException(v);
    }

}
