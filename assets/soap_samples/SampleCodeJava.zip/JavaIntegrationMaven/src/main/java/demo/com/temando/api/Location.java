
package demo.com.temando.api;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for Location complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="Location">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;all>
 *         &lt;element name="description" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}LocationName" minOccurs="0"/>
 *         &lt;element name="clientId" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}ClientId" minOccurs="0"/>
 *         &lt;element name="type" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}LocationPosition" minOccurs="0"/>
 *         &lt;element name="contactName" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}ContactName" minOccurs="0"/>
 *         &lt;element name="companyName" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}CompanyName" minOccurs="0"/>
 *         &lt;element name="street" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}Address" minOccurs="0"/>
 *         &lt;element name="suburb" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}Suburb" minOccurs="0"/>
 *         &lt;element name="state" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}State" minOccurs="0"/>
 *         &lt;element name="code" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}PostalCode" minOccurs="0"/>
 *         &lt;element name="country" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}CountryCode" minOccurs="0"/>
 *         &lt;element name="phone1" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}Phone" minOccurs="0"/>
 *         &lt;element name="phone2" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}Phone" minOccurs="0"/>
 *         &lt;element name="fax" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}Fax" minOccurs="0"/>
 *         &lt;element name="email" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}Email" minOccurs="0"/>
 *         &lt;element name="loadingFacilities" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}YesNoOption" minOccurs="0"/>
 *         &lt;element name="forklift" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}YesNoOption" minOccurs="0"/>
 *         &lt;element name="dock" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}YesNoOption" minOccurs="0"/>
 *         &lt;element name="limitedAccess" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}YesNoOption" minOccurs="0"/>
 *         &lt;element name="postalBox" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}YesNoOption" minOccurs="0"/>
 *         &lt;element name="auspostMerchantLocationId" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}AuspostMerchantLocationId" minOccurs="0"/>
 *         &lt;element name="auspostLodgementFacility" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}AuspostLodgementFacility" minOccurs="0"/>
 *         &lt;element name="manifesting" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}YesNoOption" minOccurs="0"/>
 *         &lt;element name="zones" minOccurs="0">
 *           &lt;complexType>
 *             &lt;complexContent>
 *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                 &lt;sequence>
 *                   &lt;element name="zone" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}LocationZone" maxOccurs="unbounded" minOccurs="0"/>
 *                 &lt;/sequence>
 *               &lt;/restriction>
 *             &lt;/complexContent>
 *           &lt;/complexType>
 *         &lt;/element>
 *       &lt;/all>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "Location", namespace = "http://api-demo.temando.com/schema/2009_06/common.xsd", propOrder = {

})
public class Location {

    protected String description;
    protected Integer clientId;
    protected LocationPosition type;
    protected String contactName;
    protected String companyName;
    protected String street;
    protected String suburb;
    protected String state;
    protected String code;
    protected String country;
    protected String phone1;
    protected String phone2;
    protected String fax;
    protected String email;
    protected YesNoOption loadingFacilities;
    protected YesNoOption forklift;
    protected YesNoOption dock;
    protected YesNoOption limitedAccess;
    protected YesNoOption postalBox;
    protected String auspostMerchantLocationId;
    protected String auspostLodgementFacility;
    protected YesNoOption manifesting;
    protected Location.Zones zones;

    /**
     * Gets the value of the description property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDescription() {
        return description;
    }

    /**
     * Sets the value of the description property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDescription(String value) {
        this.description = value;
    }

    /**
     * Gets the value of the clientId property.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getClientId() {
        return clientId;
    }

    /**
     * Sets the value of the clientId property.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setClientId(Integer value) {
        this.clientId = value;
    }

    /**
     * Gets the value of the type property.
     * 
     * @return
     *     possible object is
     *     {@link LocationPosition }
     *     
     */
    public LocationPosition getType() {
        return type;
    }

    /**
     * Sets the value of the type property.
     * 
     * @param value
     *     allowed object is
     *     {@link LocationPosition }
     *     
     */
    public void setType(LocationPosition value) {
        this.type = value;
    }

    /**
     * Gets the value of the contactName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getContactName() {
        return contactName;
    }

    /**
     * Sets the value of the contactName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setContactName(String value) {
        this.contactName = value;
    }

    /**
     * Gets the value of the companyName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCompanyName() {
        return companyName;
    }

    /**
     * Sets the value of the companyName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCompanyName(String value) {
        this.companyName = value;
    }

    /**
     * Gets the value of the street property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getStreet() {
        return street;
    }

    /**
     * Sets the value of the street property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setStreet(String value) {
        this.street = value;
    }

    /**
     * Gets the value of the suburb property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSuburb() {
        return suburb;
    }

    /**
     * Sets the value of the suburb property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSuburb(String value) {
        this.suburb = value;
    }

    /**
     * Gets the value of the state property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getState() {
        return state;
    }

    /**
     * Sets the value of the state property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setState(String value) {
        this.state = value;
    }

    /**
     * Gets the value of the code property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCode() {
        return code;
    }

    /**
     * Sets the value of the code property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCode(String value) {
        this.code = value;
    }

    /**
     * Gets the value of the country property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCountry() {
        return country;
    }

    /**
     * Sets the value of the country property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCountry(String value) {
        this.country = value;
    }

    /**
     * Gets the value of the phone1 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPhone1() {
        return phone1;
    }

    /**
     * Sets the value of the phone1 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPhone1(String value) {
        this.phone1 = value;
    }

    /**
     * Gets the value of the phone2 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPhone2() {
        return phone2;
    }

    /**
     * Sets the value of the phone2 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPhone2(String value) {
        this.phone2 = value;
    }

    /**
     * Gets the value of the fax property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getFax() {
        return fax;
    }

    /**
     * Sets the value of the fax property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setFax(String value) {
        this.fax = value;
    }

    /**
     * Gets the value of the email property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getEmail() {
        return email;
    }

    /**
     * Sets the value of the email property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setEmail(String value) {
        this.email = value;
    }

    /**
     * Gets the value of the loadingFacilities property.
     * 
     * @return
     *     possible object is
     *     {@link YesNoOption }
     *     
     */
    public YesNoOption getLoadingFacilities() {
        return loadingFacilities;
    }

    /**
     * Sets the value of the loadingFacilities property.
     * 
     * @param value
     *     allowed object is
     *     {@link YesNoOption }
     *     
     */
    public void setLoadingFacilities(YesNoOption value) {
        this.loadingFacilities = value;
    }

    /**
     * Gets the value of the forklift property.
     * 
     * @return
     *     possible object is
     *     {@link YesNoOption }
     *     
     */
    public YesNoOption getForklift() {
        return forklift;
    }

    /**
     * Sets the value of the forklift property.
     * 
     * @param value
     *     allowed object is
     *     {@link YesNoOption }
     *     
     */
    public void setForklift(YesNoOption value) {
        this.forklift = value;
    }

    /**
     * Gets the value of the dock property.
     * 
     * @return
     *     possible object is
     *     {@link YesNoOption }
     *     
     */
    public YesNoOption getDock() {
        return dock;
    }

    /**
     * Sets the value of the dock property.
     * 
     * @param value
     *     allowed object is
     *     {@link YesNoOption }
     *     
     */
    public void setDock(YesNoOption value) {
        this.dock = value;
    }

    /**
     * Gets the value of the limitedAccess property.
     * 
     * @return
     *     possible object is
     *     {@link YesNoOption }
     *     
     */
    public YesNoOption getLimitedAccess() {
        return limitedAccess;
    }

    /**
     * Sets the value of the limitedAccess property.
     * 
     * @param value
     *     allowed object is
     *     {@link YesNoOption }
     *     
     */
    public void setLimitedAccess(YesNoOption value) {
        this.limitedAccess = value;
    }

    /**
     * Gets the value of the postalBox property.
     * 
     * @return
     *     possible object is
     *     {@link YesNoOption }
     *     
     */
    public YesNoOption getPostalBox() {
        return postalBox;
    }

    /**
     * Sets the value of the postalBox property.
     * 
     * @param value
     *     allowed object is
     *     {@link YesNoOption }
     *     
     */
    public void setPostalBox(YesNoOption value) {
        this.postalBox = value;
    }

    /**
     * Gets the value of the auspostMerchantLocationId property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAuspostMerchantLocationId() {
        return auspostMerchantLocationId;
    }

    /**
     * Sets the value of the auspostMerchantLocationId property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAuspostMerchantLocationId(String value) {
        this.auspostMerchantLocationId = value;
    }

    /**
     * Gets the value of the auspostLodgementFacility property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAuspostLodgementFacility() {
        return auspostLodgementFacility;
    }

    /**
     * Sets the value of the auspostLodgementFacility property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAuspostLodgementFacility(String value) {
        this.auspostLodgementFacility = value;
    }

    /**
     * Gets the value of the manifesting property.
     * 
     * @return
     *     possible object is
     *     {@link YesNoOption }
     *     
     */
    public YesNoOption getManifesting() {
        return manifesting;
    }

    /**
     * Sets the value of the manifesting property.
     * 
     * @param value
     *     allowed object is
     *     {@link YesNoOption }
     *     
     */
    public void setManifesting(YesNoOption value) {
        this.manifesting = value;
    }

    /**
     * Gets the value of the zones property.
     * 
     * @return
     *     possible object is
     *     {@link Location.Zones }
     *     
     */
    public Location.Zones getZones() {
        return zones;
    }

    /**
     * Sets the value of the zones property.
     * 
     * @param value
     *     allowed object is
     *     {@link Location.Zones }
     *     
     */
    public void setZones(Location.Zones value) {
        this.zones = value;
    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType>
     *   &lt;complexContent>
     *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
     *       &lt;sequence>
     *         &lt;element name="zone" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}LocationZone" maxOccurs="unbounded" minOccurs="0"/>
     *       &lt;/sequence>
     *     &lt;/restriction>
     *   &lt;/complexContent>
     * &lt;/complexType>
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "zone"
    })
    public static class Zones {

        protected List<LocationZone> zone;

        /**
         * Gets the value of the zone property.
         * 
         * <p>
         * This accessor method returns a reference to the live list,
         * not a snapshot. Therefore any modification you make to the
         * returned list will be present inside the JAXB object.
         * This is why there is not a <CODE>set</CODE> method for the zone property.
         * 
         * <p>
         * For example, to add a new item, do as follows:
         * <pre>
         *    getZone().add(newItem);
         * </pre>
         * 
         * 
         * <p>
         * Objects of the following type(s) are allowed in the list
         * {@link LocationZone }
         * 
         * 
         */
        public List<LocationZone> getZone() {
            if (zone == null) {
                zone = new ArrayList<LocationZone>();
            }
            return this.zone;
        }

    }

}
