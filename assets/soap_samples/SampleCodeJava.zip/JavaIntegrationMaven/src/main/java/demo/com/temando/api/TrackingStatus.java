
package demo.com.temando.api;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for TrackingStatus.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * <p>
 * <pre>
 * &lt;simpleType name="TrackingStatus">
 *   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *     &lt;enumeration value="Unavailable"/>
 *     &lt;enumeration value="Issue"/>
 *     &lt;enumeration value="Awaiting Pickup"/>
 *     &lt;enumeration value="In Transit"/>
 *     &lt;enumeration value="Delivered"/>
 *   &lt;/restriction>
 * &lt;/simpleType>
 * </pre>
 * 
 */
@XmlType(name = "TrackingStatus", namespace = "http://api-demo.temando.com/schema/2009_06/common.xsd")
@XmlEnum
public enum TrackingStatus {

    @XmlEnumValue("Unavailable")
    UNAVAILABLE("Unavailable"),
    @XmlEnumValue("Issue")
    ISSUE("Issue"),
    @XmlEnumValue("Awaiting Pickup")
    AWAITING_PICKUP("Awaiting Pickup"),
    @XmlEnumValue("In Transit")
    IN_TRANSIT("In Transit"),
    @XmlEnumValue("Delivered")
    DELIVERED("Delivered");
    private final String value;

    TrackingStatus(String v) {
        value = v;
    }

    public String value() {
        return value;
    }

    public static TrackingStatus fromValue(String v) {
        for (TrackingStatus c: TrackingStatus.values()) {
            if (c.value.equals(v)) {
                return c;
            }
        }
        throw new IllegalArgumentException(v);
    }

}
