
package demo.com.temando.api;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for anonymous complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType>
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;all>
 *         &lt;element name="requestId" type="{http://www.w3.org/2001/XMLSchema}positiveInteger"/>
 *         &lt;element name="bookingNumber" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}BookingNumber" minOccurs="0"/>
 *         &lt;element name="consignmentNumber" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}ConsignmentNumber" minOccurs="0"/>
 *         &lt;element name="consignmentDocument" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}ConsignmentDocument" minOccurs="0"/>
 *         &lt;element name="consignmentDocumentType" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}ConsignmentDocumentType" minOccurs="0"/>
 *         &lt;element name="labelDocument" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}LabelDocument" minOccurs="0"/>
 *         &lt;element name="labelDocumentType" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}LabelDocumentType" minOccurs="0"/>
 *         &lt;element name="commercialInvoiceDocument" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}CommercialInvoiceDocument" minOccurs="0"/>
 *         &lt;element name="commercialInvoiceDocumentType" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}CommercialInvoiceDocumentType" minOccurs="0"/>
 *         &lt;element name="anythings" minOccurs="0">
 *           &lt;complexType>
 *             &lt;complexContent>
 *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                 &lt;sequence>
 *                   &lt;element name="anything" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}Anything" maxOccurs="10"/>
 *                 &lt;/sequence>
 *               &lt;/restriction>
 *             &lt;/complexContent>
 *           &lt;/complexType>
 *         &lt;/element>
 *         &lt;element name="anytime" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}Anytime" minOccurs="0"/>
 *         &lt;element name="origin" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}Location" minOccurs="0"/>
 *         &lt;element name="quote" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}AvailableQuote" minOccurs="0"/>
 *         &lt;element name="manifestNumber" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}ManifestNumber" minOccurs="0"/>
 *         &lt;element name="articles" minOccurs="0">
 *           &lt;complexType>
 *             &lt;complexContent>
 *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                 &lt;sequence>
 *                   &lt;element name="article" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}Article" maxOccurs="unbounded" minOccurs="0"/>
 *                 &lt;/sequence>
 *               &lt;/restriction>
 *             &lt;/complexContent>
 *           &lt;/complexType>
 *         &lt;/element>
 *       &lt;/all>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {

})
@XmlRootElement(name = "makeBookingByRequestResponse")
public class MakeBookingByRequestResponse {

    @XmlElement(required = true)
    @XmlSchemaType(name = "positiveInteger")
    protected BigInteger requestId;
    protected String bookingNumber;
    protected String consignmentNumber;
    protected String consignmentDocument;
    protected ConsignmentDocumentType consignmentDocumentType;
    protected String labelDocument;
    protected LabelDocumentType labelDocumentType;
    protected String commercialInvoiceDocument;
    protected CommercialInvoiceDocumentType commercialInvoiceDocumentType;
    protected MakeBookingByRequestResponse.Anythings anythings;
    protected Anytime anytime;
    protected Location origin;
    protected AvailableQuote quote;
    protected String manifestNumber;
    protected MakeBookingByRequestResponse.Articles articles;

    /**
     * Gets the value of the requestId property.
     * 
     * @return
     *     possible object is
     *     {@link BigInteger }
     *     
     */
    public BigInteger getRequestId() {
        return requestId;
    }

    /**
     * Sets the value of the requestId property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigInteger }
     *     
     */
    public void setRequestId(BigInteger value) {
        this.requestId = value;
    }

    /**
     * Gets the value of the bookingNumber property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getBookingNumber() {
        return bookingNumber;
    }

    /**
     * Sets the value of the bookingNumber property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setBookingNumber(String value) {
        this.bookingNumber = value;
    }

    /**
     * Gets the value of the consignmentNumber property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getConsignmentNumber() {
        return consignmentNumber;
    }

    /**
     * Sets the value of the consignmentNumber property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setConsignmentNumber(String value) {
        this.consignmentNumber = value;
    }

    /**
     * Gets the value of the consignmentDocument property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getConsignmentDocument() {
        return consignmentDocument;
    }

    /**
     * Sets the value of the consignmentDocument property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setConsignmentDocument(String value) {
        this.consignmentDocument = value;
    }

    /**
     * Gets the value of the consignmentDocumentType property.
     * 
     * @return
     *     possible object is
     *     {@link ConsignmentDocumentType }
     *     
     */
    public ConsignmentDocumentType getConsignmentDocumentType() {
        return consignmentDocumentType;
    }

    /**
     * Sets the value of the consignmentDocumentType property.
     * 
     * @param value
     *     allowed object is
     *     {@link ConsignmentDocumentType }
     *     
     */
    public void setConsignmentDocumentType(ConsignmentDocumentType value) {
        this.consignmentDocumentType = value;
    }

    /**
     * Gets the value of the labelDocument property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLabelDocument() {
        return labelDocument;
    }

    /**
     * Sets the value of the labelDocument property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLabelDocument(String value) {
        this.labelDocument = value;
    }

    /**
     * Gets the value of the labelDocumentType property.
     * 
     * @return
     *     possible object is
     *     {@link LabelDocumentType }
     *     
     */
    public LabelDocumentType getLabelDocumentType() {
        return labelDocumentType;
    }

    /**
     * Sets the value of the labelDocumentType property.
     * 
     * @param value
     *     allowed object is
     *     {@link LabelDocumentType }
     *     
     */
    public void setLabelDocumentType(LabelDocumentType value) {
        this.labelDocumentType = value;
    }

    /**
     * Gets the value of the commercialInvoiceDocument property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCommercialInvoiceDocument() {
        return commercialInvoiceDocument;
    }

    /**
     * Sets the value of the commercialInvoiceDocument property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCommercialInvoiceDocument(String value) {
        this.commercialInvoiceDocument = value;
    }

    /**
     * Gets the value of the commercialInvoiceDocumentType property.
     * 
     * @return
     *     possible object is
     *     {@link CommercialInvoiceDocumentType }
     *     
     */
    public CommercialInvoiceDocumentType getCommercialInvoiceDocumentType() {
        return commercialInvoiceDocumentType;
    }

    /**
     * Sets the value of the commercialInvoiceDocumentType property.
     * 
     * @param value
     *     allowed object is
     *     {@link CommercialInvoiceDocumentType }
     *     
     */
    public void setCommercialInvoiceDocumentType(CommercialInvoiceDocumentType value) {
        this.commercialInvoiceDocumentType = value;
    }

    /**
     * Gets the value of the anythings property.
     * 
     * @return
     *     possible object is
     *     {@link MakeBookingByRequestResponse.Anythings }
     *     
     */
    public MakeBookingByRequestResponse.Anythings getAnythings() {
        return anythings;
    }

    /**
     * Sets the value of the anythings property.
     * 
     * @param value
     *     allowed object is
     *     {@link MakeBookingByRequestResponse.Anythings }
     *     
     */
    public void setAnythings(MakeBookingByRequestResponse.Anythings value) {
        this.anythings = value;
    }

    /**
     * Gets the value of the anytime property.
     * 
     * @return
     *     possible object is
     *     {@link Anytime }
     *     
     */
    public Anytime getAnytime() {
        return anytime;
    }

    /**
     * Sets the value of the anytime property.
     * 
     * @param value
     *     allowed object is
     *     {@link Anytime }
     *     
     */
    public void setAnytime(Anytime value) {
        this.anytime = value;
    }

    /**
     * Gets the value of the origin property.
     * 
     * @return
     *     possible object is
     *     {@link Location }
     *     
     */
    public Location getOrigin() {
        return origin;
    }

    /**
     * Sets the value of the origin property.
     * 
     * @param value
     *     allowed object is
     *     {@link Location }
     *     
     */
    public void setOrigin(Location value) {
        this.origin = value;
    }

    /**
     * Gets the value of the quote property.
     * 
     * @return
     *     possible object is
     *     {@link AvailableQuote }
     *     
     */
    public AvailableQuote getQuote() {
        return quote;
    }

    /**
     * Sets the value of the quote property.
     * 
     * @param value
     *     allowed object is
     *     {@link AvailableQuote }
     *     
     */
    public void setQuote(AvailableQuote value) {
        this.quote = value;
    }

    /**
     * Gets the value of the manifestNumber property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getManifestNumber() {
        return manifestNumber;
    }

    /**
     * Sets the value of the manifestNumber property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setManifestNumber(String value) {
        this.manifestNumber = value;
    }

    /**
     * Gets the value of the articles property.
     * 
     * @return
     *     possible object is
     *     {@link MakeBookingByRequestResponse.Articles }
     *     
     */
    public MakeBookingByRequestResponse.Articles getArticles() {
        return articles;
    }

    /**
     * Sets the value of the articles property.
     * 
     * @param value
     *     allowed object is
     *     {@link MakeBookingByRequestResponse.Articles }
     *     
     */
    public void setArticles(MakeBookingByRequestResponse.Articles value) {
        this.articles = value;
    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType>
     *   &lt;complexContent>
     *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
     *       &lt;sequence>
     *         &lt;element name="anything" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}Anything" maxOccurs="10"/>
     *       &lt;/sequence>
     *     &lt;/restriction>
     *   &lt;/complexContent>
     * &lt;/complexType>
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "anything"
    })
    public static class Anythings {

        @XmlElement(required = true)
        protected List<Anything> anything;

        /**
         * Gets the value of the anything property.
         * 
         * <p>
         * This accessor method returns a reference to the live list,
         * not a snapshot. Therefore any modification you make to the
         * returned list will be present inside the JAXB object.
         * This is why there is not a <CODE>set</CODE> method for the anything property.
         * 
         * <p>
         * For example, to add a new item, do as follows:
         * <pre>
         *    getAnything().add(newItem);
         * </pre>
         * 
         * 
         * <p>
         * Objects of the following type(s) are allowed in the list
         * {@link Anything }
         * 
         * 
         */
        public List<Anything> getAnything() {
            if (anything == null) {
                anything = new ArrayList<Anything>();
            }
            return this.anything;
        }

    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType>
     *   &lt;complexContent>
     *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
     *       &lt;sequence>
     *         &lt;element name="article" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}Article" maxOccurs="unbounded" minOccurs="0"/>
     *       &lt;/sequence>
     *     &lt;/restriction>
     *   &lt;/complexContent>
     * &lt;/complexType>
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "article"
    })
    public static class Articles {

        protected List<Article> article;

        /**
         * Gets the value of the article property.
         * 
         * <p>
         * This accessor method returns a reference to the live list,
         * not a snapshot. Therefore any modification you make to the
         * returned list will be present inside the JAXB object.
         * This is why there is not a <CODE>set</CODE> method for the article property.
         * 
         * <p>
         * For example, to add a new item, do as follows:
         * <pre>
         *    getArticle().add(newItem);
         * </pre>
         * 
         * 
         * <p>
         * Objects of the following type(s) are allowed in the list
         * {@link Article }
         * 
         * 
         */
        public List<Article> getArticle() {
            if (article == null) {
                article = new ArrayList<Article>();
            }
            return this.article;
        }

    }

}
