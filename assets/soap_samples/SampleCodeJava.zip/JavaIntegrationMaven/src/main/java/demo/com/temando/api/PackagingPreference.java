
package demo.com.temando.api;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for PackagingPreference complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="PackagingPreference">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;all>
 *         &lt;element name="description" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}PackagingDescription"/>
 *         &lt;element name="class" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}Class"/>
 *         &lt;element name="subclass" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}Subclass" minOccurs="0"/>
 *         &lt;element name="mode" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}Mode" minOccurs="0"/>
 *         &lt;element name="tlSubclass" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}TlSubclass" minOccurs="0"/>
 *         &lt;element name="packaging" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}Packaging" minOccurs="0"/>
 *         &lt;element name="palletType" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}PalletType" minOccurs="0"/>
 *         &lt;element name="palletNature" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}PalletNature" minOccurs="0"/>
 *         &lt;element name="containerDimensions" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}ContainerDimensions" minOccurs="0"/>
 *         &lt;element name="containerNature" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}ContainerNature" minOccurs="0"/>
 *         &lt;element name="containerRegistered" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}YesNoOption" minOccurs="0"/>
 *         &lt;element name="distanceMeasurementType" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}DistanceMeasurementType" minOccurs="0"/>
 *         &lt;element name="weightMeasurementType" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}WeightMeasurementType" minOccurs="0"/>
 *         &lt;element name="comparisonLength" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}Length" minOccurs="0"/>
 *         &lt;element name="comparisonWidth" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}Width" minOccurs="0"/>
 *         &lt;element name="comparisonHeight" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}Height" minOccurs="0"/>
 *         &lt;element name="comparisonWeight" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}Weight" minOccurs="0"/>
 *         &lt;element name="actualLength" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}Length" minOccurs="0"/>
 *         &lt;element name="actualWidth" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}Width" minOccurs="0"/>
 *         &lt;element name="actualHeight" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}Height" minOccurs="0"/>
 *         &lt;element name="actualWeight" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}Weight" minOccurs="0"/>
 *         &lt;element name="priority" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}Priority" minOccurs="0"/>
 *         &lt;element name="enable" type="{http://api-demo.temando.com/schema/2009_06/common.xsd}YesNoOption" minOccurs="0"/>
 *       &lt;/all>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "PackagingPreference", namespace = "http://api-demo.temando.com/schema/2009_06/common.xsd", propOrder = {

})
public class PackagingPreference {

    @XmlElement(required = true)
    protected String description;
    @XmlElement(name = "class", required = true)
    protected Class clazz;
    protected String subclass;
    protected Mode mode;
    protected Integer tlSubclass;
    protected Packaging packaging;
    protected PalletType palletType;
    protected PalletNature palletNature;
    protected String containerDimensions;
    protected ContainerNature containerNature;
    protected YesNoOption containerRegistered;
    protected DistanceMeasurementType distanceMeasurementType;
    protected WeightMeasurementType weightMeasurementType;
    protected Integer comparisonLength;
    protected Integer comparisonWidth;
    protected Integer comparisonHeight;
    protected Integer comparisonWeight;
    protected Integer actualLength;
    protected Integer actualWidth;
    protected Integer actualHeight;
    protected Integer actualWeight;
    protected Integer priority;
    protected YesNoOption enable;

    /**
     * Gets the value of the description property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDescription() {
        return description;
    }

    /**
     * Sets the value of the description property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDescription(String value) {
        this.description = value;
    }

    /**
     * Gets the value of the clazz property.
     * 
     * @return
     *     possible object is
     *     {@link Class }
     *     
     */
    public Class getClazz() {
        return clazz;
    }

    /**
     * Sets the value of the clazz property.
     * 
     * @param value
     *     allowed object is
     *     {@link Class }
     *     
     */
    public void setClazz(Class value) {
        this.clazz = value;
    }

    /**
     * Gets the value of the subclass property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSubclass() {
        return subclass;
    }

    /**
     * Sets the value of the subclass property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSubclass(String value) {
        this.subclass = value;
    }

    /**
     * Gets the value of the mode property.
     * 
     * @return
     *     possible object is
     *     {@link Mode }
     *     
     */
    public Mode getMode() {
        return mode;
    }

    /**
     * Sets the value of the mode property.
     * 
     * @param value
     *     allowed object is
     *     {@link Mode }
     *     
     */
    public void setMode(Mode value) {
        this.mode = value;
    }

    /**
     * Gets the value of the tlSubclass property.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getTlSubclass() {
        return tlSubclass;
    }

    /**
     * Sets the value of the tlSubclass property.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setTlSubclass(Integer value) {
        this.tlSubclass = value;
    }

    /**
     * Gets the value of the packaging property.
     * 
     * @return
     *     possible object is
     *     {@link Packaging }
     *     
     */
    public Packaging getPackaging() {
        return packaging;
    }

    /**
     * Sets the value of the packaging property.
     * 
     * @param value
     *     allowed object is
     *     {@link Packaging }
     *     
     */
    public void setPackaging(Packaging value) {
        this.packaging = value;
    }

    /**
     * Gets the value of the palletType property.
     * 
     * @return
     *     possible object is
     *     {@link PalletType }
     *     
     */
    public PalletType getPalletType() {
        return palletType;
    }

    /**
     * Sets the value of the palletType property.
     * 
     * @param value
     *     allowed object is
     *     {@link PalletType }
     *     
     */
    public void setPalletType(PalletType value) {
        this.palletType = value;
    }

    /**
     * Gets the value of the palletNature property.
     * 
     * @return
     *     possible object is
     *     {@link PalletNature }
     *     
     */
    public PalletNature getPalletNature() {
        return palletNature;
    }

    /**
     * Sets the value of the palletNature property.
     * 
     * @param value
     *     allowed object is
     *     {@link PalletNature }
     *     
     */
    public void setPalletNature(PalletNature value) {
        this.palletNature = value;
    }

    /**
     * Gets the value of the containerDimensions property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getContainerDimensions() {
        return containerDimensions;
    }

    /**
     * Sets the value of the containerDimensions property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setContainerDimensions(String value) {
        this.containerDimensions = value;
    }

    /**
     * Gets the value of the containerNature property.
     * 
     * @return
     *     possible object is
     *     {@link ContainerNature }
     *     
     */
    public ContainerNature getContainerNature() {
        return containerNature;
    }

    /**
     * Sets the value of the containerNature property.
     * 
     * @param value
     *     allowed object is
     *     {@link ContainerNature }
     *     
     */
    public void setContainerNature(ContainerNature value) {
        this.containerNature = value;
    }

    /**
     * Gets the value of the containerRegistered property.
     * 
     * @return
     *     possible object is
     *     {@link YesNoOption }
     *     
     */
    public YesNoOption getContainerRegistered() {
        return containerRegistered;
    }

    /**
     * Sets the value of the containerRegistered property.
     * 
     * @param value
     *     allowed object is
     *     {@link YesNoOption }
     *     
     */
    public void setContainerRegistered(YesNoOption value) {
        this.containerRegistered = value;
    }

    /**
     * Gets the value of the distanceMeasurementType property.
     * 
     * @return
     *     possible object is
     *     {@link DistanceMeasurementType }
     *     
     */
    public DistanceMeasurementType getDistanceMeasurementType() {
        return distanceMeasurementType;
    }

    /**
     * Sets the value of the distanceMeasurementType property.
     * 
     * @param value
     *     allowed object is
     *     {@link DistanceMeasurementType }
     *     
     */
    public void setDistanceMeasurementType(DistanceMeasurementType value) {
        this.distanceMeasurementType = value;
    }

    /**
     * Gets the value of the weightMeasurementType property.
     * 
     * @return
     *     possible object is
     *     {@link WeightMeasurementType }
     *     
     */
    public WeightMeasurementType getWeightMeasurementType() {
        return weightMeasurementType;
    }

    /**
     * Sets the value of the weightMeasurementType property.
     * 
     * @param value
     *     allowed object is
     *     {@link WeightMeasurementType }
     *     
     */
    public void setWeightMeasurementType(WeightMeasurementType value) {
        this.weightMeasurementType = value;
    }

    /**
     * Gets the value of the comparisonLength property.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getComparisonLength() {
        return comparisonLength;
    }

    /**
     * Sets the value of the comparisonLength property.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setComparisonLength(Integer value) {
        this.comparisonLength = value;
    }

    /**
     * Gets the value of the comparisonWidth property.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getComparisonWidth() {
        return comparisonWidth;
    }

    /**
     * Sets the value of the comparisonWidth property.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setComparisonWidth(Integer value) {
        this.comparisonWidth = value;
    }

    /**
     * Gets the value of the comparisonHeight property.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getComparisonHeight() {
        return comparisonHeight;
    }

    /**
     * Sets the value of the comparisonHeight property.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setComparisonHeight(Integer value) {
        this.comparisonHeight = value;
    }

    /**
     * Gets the value of the comparisonWeight property.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getComparisonWeight() {
        return comparisonWeight;
    }

    /**
     * Sets the value of the comparisonWeight property.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setComparisonWeight(Integer value) {
        this.comparisonWeight = value;
    }

    /**
     * Gets the value of the actualLength property.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getActualLength() {
        return actualLength;
    }

    /**
     * Sets the value of the actualLength property.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setActualLength(Integer value) {
        this.actualLength = value;
    }

    /**
     * Gets the value of the actualWidth property.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getActualWidth() {
        return actualWidth;
    }

    /**
     * Sets the value of the actualWidth property.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setActualWidth(Integer value) {
        this.actualWidth = value;
    }

    /**
     * Gets the value of the actualHeight property.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getActualHeight() {
        return actualHeight;
    }

    /**
     * Sets the value of the actualHeight property.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setActualHeight(Integer value) {
        this.actualHeight = value;
    }

    /**
     * Gets the value of the actualWeight property.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getActualWeight() {
        return actualWeight;
    }

    /**
     * Sets the value of the actualWeight property.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setActualWeight(Integer value) {
        this.actualWeight = value;
    }

    /**
     * Gets the value of the priority property.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getPriority() {
        return priority;
    }

    /**
     * Sets the value of the priority property.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setPriority(Integer value) {
        this.priority = value;
    }

    /**
     * Gets the value of the enable property.
     * 
     * @return
     *     possible object is
     *     {@link YesNoOption }
     *     
     */
    public YesNoOption getEnable() {
        return enable;
    }

    /**
     * Sets the value of the enable property.
     * 
     * @param value
     *     allowed object is
     *     {@link YesNoOption }
     *     
     */
    public void setEnable(YesNoOption value) {
        this.enable = value;
    }

}
